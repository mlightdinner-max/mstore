import express, { Request, Response, NextFunction } from "express";
// NOTE: vite is intentionally NOT imported at the top level.
// It is loaded dynamically inside the dev-only block below so that the
// production build (dist/server.js) has zero dependency on vite at runtime.
import * as path from "path";
import { fileURLToPath } from "url";
import * as fs from "fs";
import multer from "multer";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import morgan from "morgan";
import { rateLimit } from "express-rate-limit";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import nodemailer from "nodemailer";
import twilio from "twilio";
import { WebSocketServer, WebSocket } from "ws";

import { createAuthRouter } from './src/server/routes/auth.js';
import { createProductsRouter } from './src/server/routes/products.js';
import { createUsersRouter } from './src/server/routes/users.js';
import { createOrdersRouter } from './src/server/routes/orders.js';
import { createConfigRouter } from './src/server/routes/config.js';
import { createMediaRouter } from './src/server/routes/media.js';
import { createVisitorsRouter } from './src/server/routes/visitors.js';
import { createCustomersRouter } from './src/server/routes/customers.js';
import { createAffiliatesRouter } from './src/server/routes/affiliates.js';
import { createAlertsRouter } from './src/server/routes/alerts.js';
import { createSystemRouter } from './src/server/routes/system.js';
import { createAuditLogsRouter } from './src/server/routes/auditLogs.js';
import { createNotificationsRouter } from './src/server/routes/notifications.js';
import { createAgentRouter } from './src/server/routes/agent.js';
import { createNewsletterRouter } from './src/server/routes/newsletter.js';
import { createSupportRouter } from './src/server/routes/support.js';
import { createCouponsRouter } from './src/server/routes/coupons.js';
import { createAIRouter } from './src/server/routes/ai.js';

import { db, getContext, initialProducts, initialUsers, initialConfig } from './src/server/db.js';
import { OrderService } from './src/server/services/orderService.js';
import { generateId } from './src/server/dataStore.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// JWT secret — required in all environments. No silent fallback.
if (!process.env.JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    console.error('FATAL: JWT_SECRET environment variable is not set. Refusing to start.');
    process.exit(1);
  } else {
    console.warn('WARNING: JWT_SECRET is not set. Using an insecure development default. Set JWT_SECRET before deploying.');
  }
}
const ACTUAL_JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key-change-this-in-production';

if (process.env.NODE_ENV === 'production') {
  const missing = ['SUPER_ADMIN_PASSWORD', 'SYSTEM_RESET_PASSWORD'].filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error(`FATAL: Required environment variable(s) not set in production: ${missing.join(', ')}. Refusing to start.`);
    process.exit(1);
  }
} else if (!process.env.SUPER_ADMIN_PASSWORD || !process.env.SYSTEM_RESET_PASSWORD) {
  console.warn('WARNING: SUPER_ADMIN_PASSWORD / SYSTEM_RESET_PASSWORD not set. Using insecure defaults for development ONLY.');
}

// --- Data Persistence ---
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

// These paths are still needed for some routers that take them as arguments
const PRODUCTS_FILE = path.join(process.cwd(), "data", "products.json");
const USERS_FILE = path.join(process.cwd(), "data", "users.json");
const ORDERS_FILE = path.join(process.cwd(), "data", "orders.json");
const CONFIG_FILE = path.join(process.cwd(), "data", "config.json");
const ALERTS_FILE = path.join(process.cwd(), "data", "alerts.json");
const NOTIFICATIONS_LOG_FILE = path.join(process.cwd(), "data", "notifications_log.json");
const AUDIT_LOG_FILE = path.join(process.cwd(), "data", "audit_logs.json");
const AFFILIATE_PAYOUTS_FILE = path.join(process.cwd(), "data", "affiliate_payouts.json");
const AFFILIATE_GROUPS_FILE = path.join(process.cwd(), "data", "affiliate_groups.json");

if (!fs.existsSync(path.join(process.cwd(), "public"))) fs.mkdirSync(path.join(process.cwd(), "public"));
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);

// Create essential preloaded folders
const essentialFolders = ['branding', 'homepage', 'quality', 'blog', 'products', 'categories'];
essentialFolders.forEach(folder => {
  const folderPath = path.join(UPLOADS_DIR, folder);
  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath, { recursive: true });
  }
});

// Configure Multer
const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
  'image/avif'
  // SVG intentionally excluded: SVG files can contain <script> tags and cause
  // stored XSS when served from the same origin. If SVG uploads are required in
  // the future, serve them with Content-Disposition: attachment.
]);
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE_BYTES },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MIME_TYPES.has(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`File type not allowed: ${file.mimetype}. Only images are accepted.`));
    }
  }
});

// --- Helpers ---
const calculateOrderFinancials = (orderData: any, products: any[], config: any, users: any[]) => {
  return OrderService.calculateFinancials(orderData, products, config, users);
};

const updateAffiliateStats = (affiliateId: string | null, revenueDelta: number, commissionDelta: number, usersArray: any[]) => {
  if (!affiliateId) return;
  const affIndex = usersArray.findIndex(u => u.role === 'Affiliate' && u.affiliateId === affiliateId);
  if (affIndex !== -1) {
    usersArray[affIndex] = {
      ...usersArray[affIndex],
      totalRevenue: Math.max(0, (usersArray[affIndex].totalRevenue || 0) + revenueDelta),
      totalCommission: Math.max(0, (usersArray[affIndex].totalCommission || 0) + commissionDelta)
    };
  }
};

// Legacy writeData/readData compatibility for some routers
function writeData(file: string, data: any) {
  // Map files to their respective stores
  if (file.endsWith('products.json')) db.products.set(data);
  else if (file.endsWith('users.json')) db.users.set(data);
  else if (file.endsWith('orders.json')) db.orders.set(data);
  else if (file.endsWith('config.json')) db.config.set(data);
  else if (file.endsWith('alerts.json')) db.alerts.set(data);
  else if (file.endsWith('notifications_log.json')) db.notificationLogs.set(data);
  else if (file.endsWith('audit_logs.json')) db.auditLogs.set(data);
  else if (file.endsWith('system_logs.json')) db.systemLogs.set(data);
  else if (file.endsWith('affiliate_payouts.json')) db.affiliatePayouts.set(data);
  else if (file.endsWith('customers.json')) db.customers.set(data);
  else if (file.endsWith('affiliate_groups.json')) db.affiliateGroups.set(data);
  else {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  }
}

function logAction(user: any, action: string, details: any) {
  db.auditLogs.update(logs => [
    ...logs,
    {
      id: generateId(),
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action,
      details
    }
  ]);
}

function systemLog(type: string, message: string) {
  db.systemLogs.update(logs => {
    const newLogs = [...logs, {
      id: generateId(),
      type,
      message,
      timestamp: new Date().toISOString()
    }];
    return newLogs.slice(-100);
  });
}


// --- Real-time Visitor Tracking ---
interface VisitorInfo {
  ip: string;
  lastSeen: number;
  sessionStart: number;
  currentPage: string;
  deviceType: string;
  userAgent: string;
}
const visitors = new Map<string, VisitorInfo>();
const VISITOR_TIMEOUT = 5 * 60 * 1000; // 5 minutes

let wss: WebSocketServer | null = null;

const broadcastVisitors = () => {
  if (!wss) return;
  const visitorData = Array.from(visitors.values());
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'visitors_update', data: visitorData }));
    }
  });
};

setInterval(() => {
  const now = Date.now();
  let changed = false;
  for (const [ip, info] of visitors.entries()) {
    if (now - info.lastSeen > VISITOR_TIMEOUT) {
      visitors.delete(ip);
      changed = true;
    }
  }
  if (changed) broadcastVisitors();
}, 60000); // Clean up every minute

// --- Authentication Middleware ---
const authenticateToken = (req: any, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token || token === 'null' || token === 'undefined') {
    return res.status(401).json({ error: "Unauthorized: No token provided" });
  }

  jwt.verify(token, ACTUAL_JWT_SECRET, (err: any, user: any) => {
    if (err) {
      const message = err.name === 'TokenExpiredError' ? "Session Expired" : "Invalid Token";
      return res.status(401).json({ error: `Unauthorized: ${message}` });
    }
    req.user = user;
    next();
  });
};

const checkRole = (roles: string[]) => {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: `Forbidden: Requires one of these roles: ${roles.join(', ')}` });
    }
    next();
  };
};

// --- Notification Helpers ---
async function sendEmailNotification(order: any, status: string) {
  const config = db.config.get();
  const settings = config.notificationSettings?.email;
  if (!settings || !settings.enabled) return;
  
  // Check if this status has notifications disabled
  if (config.notificationSettings?.disabledStatuses?.includes(status)) return;

  const template = (settings.templates?.[status]) || `Order ${order.id} status updated to ${status}`;
  const message = template
    .replace('{customerName}', order.customerName)
    .replace('{orderId}', order.id)
    .replace('{status}', status);

  const transporter = nodemailer.createTransport({
    // Env vars take priority; DB settings act as a UI-configurable fallback
    host: process.env.SMTP_HOST || settings.smtpHost,
    port: parseInt(process.env.SMTP_PORT || String(settings.smtpPort || 587)),
    secure: (parseInt(process.env.SMTP_PORT || String(settings.smtpPort || 587))) === 465,
    auth: {
      user: process.env.SMTP_USER || settings.smtpUser,
      pass: process.env.SMTP_PASS || settings.smtpPass,
    },
  });

  try {
    await transporter.sendMail({
      from: settings.senderEmail || config.contactEmail,
      to: order.email,
      subject: `Order Status Update: ${status} [${order.id}]`,
      text: message,
    });
    
    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'email',
      recipient: order.email,
      status: 'sent',
      message,
      timestamp: new Date().toISOString()
    };
    db.notificationLogs.update(logs => [...logs, log]);
  } catch (error: any) {
    console.error("Email notification failed:", error);
    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'email',
      recipient: order.email,
      status: 'failed',
      message,
      timestamp: new Date().toISOString(),
      error: error.message
    };
    db.notificationLogs.update(logs => [...logs, log]);
  }
}

async function sendWhatsAppNotification(order: any, status: string) {
  const config = db.config.get();
  const settings = config.notificationSettings?.whatsapp;
  if (!settings || !settings.enabled) return;
  
  // Prefer env vars; fall back to DB-stored values
  const accountSid = process.env.TWILIO_ACCOUNT_SID || settings.accountSid;
  const authToken = process.env.TWILIO_AUTH_TOKEN || settings.apiKey;
  const fromNumber = process.env.TWILIO_WHATSAPP_FROM || settings.fromNumber;
  if (!accountSid) return;

  if (config.notificationSettings?.disabledStatuses?.includes(status)) return;

  const template = (settings.templates?.[status]) || `Order ${order.id} status updated to ${status}`;
  const message = template
    .replace('{customerName}', order.customerName)
    .replace('{orderId}', order.id)
    .replace('{status}', status);

  const client = twilio(accountSid, authToken);

  try {
    await client.messages.create({
      body: message,
      from: `whatsapp:${fromNumber}`,
      to: `whatsapp:${order.phone}`
    });

    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'whatsapp',
      recipient: order.phone,
      status: 'sent',
      message,
      timestamp: new Date().toISOString()
    };
    db.notificationLogs.update(logs => [...logs, log]);
  } catch (error: any) {
    console.error("WhatsApp notification failed:", error);
    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'whatsapp',
      recipient: order.phone,
      status: 'failed',
      message,
      timestamp: new Date().toISOString(),
      error: error.message
    };
    db.notificationLogs.update(logs => [...logs, log]);
  }
}

async function sendWebhookNotification(order: any, status: string) {
  const config = db.config.get();
  const settings = config.notificationSettings?.webhook;
  if (!settings || !settings.enabled || !settings.url) return;
  
  if (config.notificationSettings?.disabledStatuses?.includes(status)) return;

  const template = (settings.templates?.[status]) || `Order ${order.id} status updated to ${status}`;
  const message = template
    .replace('{customerName}', order.customerName)
    .replace('{orderId}', order.id)
    .replace('{status}', status)
    .replace('{total}', order.total.toString())
    .replace('{items}', order.items.map((i: any) => `${i.quantity}x ${i.name}`).join(', '));

  try {
    // Basic SSRF guard: reject requests to loopback, link-local or private ranges
    const targetUrl = new URL(settings.url);
    const hostname = targetUrl.hostname.toLowerCase();
    const isPrivate =
      hostname === 'localhost' ||
      hostname === '0.0.0.0' ||
      /^127\./.test(hostname) ||
      /^10\./.test(hostname) ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(hostname) ||
      /^192\.168\./.test(hostname) ||
      /^::1$/.test(hostname) ||
      /^fe80:/i.test(hostname);
    if (isPrivate) {
      console.warn(`Webhook blocked: private/loopback target ${settings.url}`);
      return;
    }
  } catch {
    console.warn('Webhook skipped: invalid URL');
    return;
  }

  try {
    const response = await fetch(settings.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Secret': process.env.WEBHOOK_SECRET || settings.secret || '',
      },
      body: JSON.stringify({
        event: 'order.status_updated',
        orderId: order.id,
        status,
        customerName: order.customerName,
        email: order.email,
        phone: order.phone,
        message,
        timestamp: new Date().toISOString()
      }),
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'webhook',
      recipient: settings.url,
      status: 'sent',
      message,
      timestamp: new Date().toISOString()
    };
    db.notificationLogs.update(logs => [...logs, log]);
  } catch (error: any) {
    console.error("Webhook notification failed:", error);
    const log: import('./src/types.js').NotificationLog = {
      id: generateId(),
      orderId: order.id,
      type: 'webhook',
      recipient: settings.url,
      status: 'failed',
      message,
      timestamp: new Date().toISOString(),
      error: error.message
    };
    db.notificationLogs.update(logs => [...logs, log]);
  }
}


async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;
  console.log(`Starting server in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}...`);

  // Trust the first hop of a reverse proxy (Nginx, Caddy, load balancer).
  // This makes req.ip reliable and allows express-rate-limit to work correctly.
  app.set('trust proxy', 1);

  systemLog('info', `Intelligence Hub boot sequence initiated in ${process.env.NODE_ENV || 'development'} mode.`);
  systemLog('info', 'Inventory cache synchronization completed.');
  systemLog('info', 'Security audit subsystem online.');

  // --- Production Middleware ---
  if (process.env.NODE_ENV === "production") {
    // Redirect HTTP → HTTPS when running behind a reverse proxy that sets X-Forwarded-Proto.
    // If your host terminates TLS before the request reaches Node, this handles the redirect.
    app.use((req: Request, res: Response, next: NextFunction) => {
      if (req.headers['x-forwarded-proto'] === 'http') {
        return res.redirect(301, `https://${req.headers.host}${req.url}`);
      }
      next();
    });

    app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          ...helmet.contentSecurityPolicy.getDefaultDirectives(),
          "img-src": ["'self'", "data:", "https://picsum.photos", "https://fastly.picsum.photos", "*"],
          // React 19 does not require unsafe-inline or unsafe-eval.
          // If a future library requires one of these, pin it to a nonce instead.
          "script-src": ["'self'"],
          "connect-src": ["'self'", "https://generativelanguage.googleapis.com", "*"],
        },
      },
      crossOriginEmbedderPolicy: false,
      // Enforce HTTPS for 1 year, including sub-domains
      hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    }));
    app.use(compression());
    app.use(morgan("combined"));
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 1000,
      standardHeaders: true,
      legacyHeaders: false,
      message: { error: "Too many requests from this IP, please try again after 15 minutes" }
    });
    app.use("/api/", limiter);
  } else {
    app.use(morgan("dev", {
      skip: (req) => {
        const isStatic = /\.(js|ts|tsx|jsx|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|otf|map|json)$/.test(req.path);
        const isVite = req.url.startsWith('/@') || req.url.includes('node_modules') || req.url.includes('?v=');
        return isStatic || isVite;
      }
    }));
  }

  // CORS — only applied to /api routes, never to static assets
  const rawOrigin = (process.env.APP_URL || '').replace(/\/$/, '');
  app.use('/api', cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (server-to-server, curl, etc.)
      if (!origin) return callback(null, true);
      // Allow if APP_URL not set (open during testing) or origin matches
      if (!rawOrigin || origin.replace(/\/$/, '') === rawOrigin) return callback(null, true);
      callback(new Error('Not allowed by CORS'));
    },
    credentials: true
  }));
  
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ limit: '2mb', extended: true }));
  app.use("/uploads", express.static(UPLOADS_DIR));

  app.get("/ping", (_req, res) => {
    res.send("pong");
  });

  app.get("/api/v1/health", (_req, res) => {
    // Verify the data directory is writable — catches misconfigured deployments early
    const DATA_DIR = process.env.PERSISTENT_DATA_PATH
      ? path.resolve(process.env.PERSISTENT_DATA_PATH)
      : path.join(process.cwd(), 'data');
    const testFile = path.join(DATA_DIR, '.healthcheck');
    try {
      fs.writeFileSync(testFile, '1');
      fs.unlinkSync(testFile);
      res.json({ status: "ok", env: process.env.NODE_ENV || 'development', storage: "writable" });
    } catch {
      res.status(503).json({ status: "error", env: process.env.NODE_ENV || 'development', storage: "not writable" });
    }
  });

  // --- AI Routes ---
  app.use('/api/v1/ai', createAIRouter(
    getContext,
    authenticateToken
  ));

  // --- API Routes ---
  app.use('/api/v1', createAuthRouter(() => db.users.get(), ACTUAL_JWT_SECRET));
  app.use('/api/v1/products', createProductsRouter(getContext, writeData, PRODUCTS_FILE, logAction, authenticateToken, checkRole, ACTUAL_JWT_SECRET, UPLOADS_DIR));
  app.use('/api/v1/users', createUsersRouter(getContext, writeData, USERS_FILE, logAction, authenticateToken, checkRole));
  // Fulfilment agent API — must be mounted BEFORE the orders router so that
  // PATCH /api/v1/orders/:id/agent is not captured by the orders PATCH /:id handler.
  app.use('/api/v1', createAgentRouter(
    getContext,
    authenticateToken,
    checkRole,
    logAction
  ));

  app.use('/api/v1/orders', await createOrdersRouter(
    getContext,
    calculateOrderFinancials,
    sendEmailNotification,
    sendWhatsAppNotification,
    sendWebhookNotification,
    updateAffiliateStats,
    logAction,
    authenticateToken,
    checkRole,
    ACTUAL_JWT_SECRET
  ));
  app.use('/api/v1/config', createConfigRouter(
    getContext,
    writeData,
    CONFIG_FILE,
    logAction,
    authenticateToken,
    checkRole,
    visitors
  ));
  app.use('/api/v1/media', createMediaRouter(
    UPLOADS_DIR,
    upload,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/visitors', createVisitorsRouter(
    visitors,
    broadcastVisitors,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/customers', createCustomersRouter(
    getContext,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/affiliates', createAffiliatesRouter(
    getContext,
    writeData,
    AFFILIATE_GROUPS_FILE,
    AFFILIATE_PAYOUTS_FILE,
    USERS_FILE,
    logAction,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/alerts', createAlertsRouter(
    getContext,
    writeData,
    ALERTS_FILE,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/dashboard/metrics', createSystemRouter(
    getContext,
    writeData,
    PRODUCTS_FILE,
    USERS_FILE,
    ORDERS_FILE,
    CONFIG_FILE,
    ALERTS_FILE,
    NOTIFICATIONS_LOG_FILE,
    AUDIT_LOG_FILE,
    AFFILIATE_PAYOUTS_FILE,
    UPLOADS_DIR,
    initialProducts,
    initialUsers,
    initialConfig,
    authenticateToken,
    checkRole,
    bcrypt,
    fs,
    path,
    visitors
  ));
  app.use('/api/v1/audit-logs', createAuditLogsRouter(
    getContext,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/notifications', createNotificationsRouter(
    getContext,
    authenticateToken,
    checkRole
  ));
  app.use('/api/v1/newsletter', createNewsletterRouter(
    getContext,
    writeData,
    CONFIG_FILE,
    authenticateToken,
    checkRole,
    nodemailer,
    logAction
  ));
  app.use('/api/v1/support', createSupportRouter(
    getContext,
    writeData,
    CONFIG_FILE,
    authenticateToken,
    checkRole,
    nodemailer,
    logAction
  ));
  app.use('/api/v1/coupons', createCouponsRouter(
    getContext
  ));

  // Catch-all for API routes that don't match to prevent returning HTML
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // --- Error Handling ---
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err.stack);
    res.status(err.status || 500).json({
      error: process.env.NODE_ENV === "production" ? "Internal Server Error" : err.message
    });
  });

  // Vite dev middleware — only in development, loaded dynamically so the
  // production bundle (dist/server.js) never imports vite at runtime.
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Resolve the dist directory reliably across all hosting platforms.
    // process.cwd() is the project root where "node dist/server.js" is invoked.
    // __dirname is dist/ when bundled by esbuild — but some platforms change cwd,
    // so we try both and use whichever has index.html.
    const distFromCwd = path.join(process.cwd(), 'dist');
    const distFromDirname = __dirname;
    const resolvedDist = fs.existsSync(path.join(distFromCwd, 'index.html'))
      ? distFromCwd
      : distFromDirname;

    // Serve static assets with explicit MIME types to prevent miscategorisation
    app.use(express.static(resolvedDist, {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.js')) res.setHeader('Content-Type', 'application/javascript');
        if (filePath.endsWith('.css')) res.setHeader('Content-Type', 'text/css');
      }
    }));

    // SPA fallback — only for non-asset, non-API routes
    app.get('*', (req, res) => {
      if (req.path.startsWith('/assets/') || req.path.startsWith('/uploads/')) {
        return res.status(404).send('Not found');
      }
      res.sendFile(path.join(resolvedDist, 'index.html'));
    });
  }

  const server = app.listen(Number(PORT), "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  });

  process.on('uncaughtException', (err) => {
    console.error('UNCAUGHT EXCEPTION! 💥 Shutting down...');
    console.error(err.name, err.message, err.stack);
    process.exit(1);
  });

  process.on('unhandledRejection', (err: any) => {
    console.error('UNHANDLED REJECTION! 💥 Shutting down...');
    console.error(err.name, err.message);
    server.close(() => {
      process.exit(1);
    });
  });

  // Initialize WebSocket server
  wss = new WebSocketServer({ server });

  wss.on('connection', (ws, req) => {
    // Authenticate via token passed as a query parameter: ws://host?token=<jwt>
    // This avoids sending credentials in headers, which WebSocket doesn't support natively.
    try {
      const url = new URL(req.url || '', `http://${req.headers.host}`);
      const token = url.searchParams.get('token');
      if (!token) {
        ws.close(4001, 'Unauthorized: no token');
        return;
      }
      jwt.verify(token, ACTUAL_JWT_SECRET, (err: any, decoded: any) => {
        if (err || !decoded) {
          ws.close(4001, 'Unauthorized: invalid token');
          return;
        }
        const role = decoded.role;
        if (!['Admin', 'Super Admin'].includes(role)) {
          ws.close(4003, 'Forbidden: insufficient role');
          return;
        }
        // Auth passed — send initial visitor snapshot
        ws.send(JSON.stringify({ type: 'visitors_update', data: Array.from(visitors.values()) }));
      });
    } catch {
      ws.close(4001, 'Unauthorized: bad request');
    }
  });
}

startServer();
