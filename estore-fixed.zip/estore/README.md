# My Store — Full-Stack E-Commerce Platform

A high-performance, AI-integrated e-commerce platform with a React storefront and Node.js/Express backend. Everything is managed from a single admin panel after deployment.

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + Tailwind CSS v4 + React Router v7 |
| Backend | Node.js 20 + Express 4 |
| Data | SQLite (better-sqlite3, WAL mode) |
| AI | Google Gemini (optional) |
| Real-time | WebSockets (live visitor tracking) |
| Auth | JWT (24h) + bcryptjs + HMAC-signed CAPTCHA |
| Notifications | Nodemailer (email) + Twilio (WhatsApp) + Webhooks |

---

## First-Time Setup

### 1. Set Environment Variables

Copy `.env.example` to `.env` and fill in every value:

```bash
cp .env.example .env
```

Generate a strong JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

The server **refuses to start in production** if `JWT_SECRET`, `SUPER_ADMIN_PASSWORD`, or `SYSTEM_RESET_PASSWORD` are missing.

### 2. Build

```bash
npm install
npm run build
```

This produces a `dist/` folder containing:
- `dist/index.html` + all frontend assets (from Vite)
- `dist/server.js` (bundled Node.js server from esbuild)

### 3. Deploy

Upload to your server:
- `dist/` folder
- `data/` folder (you do not need to create this — the server creates `store.db` here on first boot)
- `public/` folder (for uploaded images)
- `package.json`
- `.env`

### 4. Start

```bash
NODE_ENV=production node dist/server.js
```

Or with a process manager:
```bash
npm install -g pm2
pm2 start dist/server.js --name mystore
pm2 save
pm2 startup
```

---

## Reverse Proxy (Required for HTTPS)

The Node.js server speaks HTTP on port 3000. You **must** put Nginx or Caddy in front for TLS. The app automatically redirects HTTP → HTTPS when it detects the `X-Forwarded-Proto: http` header from the proxy.

### Nginx example

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Caddy example (automatic HTTPS)

```
yourdomain.com {
    reverse_proxy localhost:3000
}
```

---

## Hostinger Deployment Guide

### Which plan to choose

| Plan | Works? | Notes |
|---|---|---|
| **Business Web Hosting** | ⚠️ Limited | Node.js via Passenger — WebSockets do NOT work. Live Traffic dashboard will not function. Order volume limit ~20/day before memory issues. Only use if you cannot afford VPS. |
| **VPS KVM 1** (1 vCPU, 4GB RAM) | ✅ Good for launch | Handles up to ~200 orders/day comfortably |
| **VPS KVM 2** (2 vCPU, 8GB RAM) | ✅ Recommended | Run the fulfilment agent alongside the store |

**Use VPS.** Business Web Hosting will break WebSockets (Live Traffic, real-time admin updates) because Phusion Passenger does not support the WebSocket protocol upgrade.

---

### VPS Setup (Step by Step)

#### Step 1 — SSH into your VPS

Hostinger emails you the root password when you create the VPS. Connect via:

```bash
ssh root@YOUR_VPS_IP
```

#### Step 2 — Install Node.js 20 and PM2

```bash
# Install Node.js 20 via nvm (recommended — avoids system package conflicts)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
nvm alias default 20

# Install PM2 globally (process manager — keeps your store running after logout)
npm install -g pm2
```

#### Step 3 — Upload your project files

On your **local machine** (not the VPS), build the project first:

```bash
npm install
npm run build
```

Then upload to the VPS. You only need these files/folders — do NOT upload `node_modules/`:

```
dist/            ← built server and client
public/          ← uploaded images go here
src/             ← source files (needed for TypeScript imports at runtime if any)
package.json
package-lock.json
.env             ← your secrets (create this from .env.example)
```

Upload via SFTP (FileZilla, Cyberduck, or VS Code SFTP extension):
- Host: `YOUR_VPS_IP`
- Username: `root`
- Password: (your VPS root password)
- Upload to: `/var/www/mystore/`

Or use rsync from your local machine terminal:
```bash
rsync -avz --exclude node_modules --exclude .git --exclude dist/client/assets   ./ root@YOUR_VPS_IP:/var/www/mystore/
```

#### Step 4 — Install production dependencies on the VPS

```bash
cd /var/www/mystore
npm install --omit=dev
```

#### Step 5 — Create your `.env` file on the VPS

```bash
cp .env.example .env
nano .env   # or: vi .env
```

Set at minimum:
```
NODE_ENV=production
PORT=3000
JWT_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))">
SUPER_ADMIN_PASSWORD=<your strong password>
SYSTEM_RESET_PASSWORD=<another strong password>
PERSISTENT_DATA_PATH=/var/www/mystore/data
```

#### Step 6 — Create the data directory

```bash
mkdir -p /var/www/mystore/data
mkdir -p /var/www/mystore/public/uploads
```

#### Step 7 — Start with PM2

```bash
cd /var/www/mystore
pm2 start dist/server.js --name mystore --env production
pm2 save
pm2 startup   # Follow the printed instructions to auto-start on reboot
```

Verify it is running:
```bash
pm2 status
pm2 logs mystore --lines 50
```

Visit `http://YOUR_VPS_IP:3000` — you should see your store.

#### Step 8 — Point your domain and enable HTTPS

In Hostinger hPanel → **DNS** → set an A record pointing your domain to `YOUR_VPS_IP`.

Then install Nginx and Certbot:

```bash
apt update && apt install -y nginx certbot python3-certbot-nginx

# Create Nginx config
cat > /etc/nginx/sites-available/mystore << 'EOF'
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    # Max upload size for product images
    client_max_body_size 15M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;

        # WebSocket support (required for Live Traffic and real-time admin updates)
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts for long-running requests
        proxy_read_timeout 60s;
        proxy_send_timeout 60s;
    }
}
EOF

ln -s /etc/nginx/sites-available/mystore /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# Get free SSL certificate
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Certbot auto-renews. Done — your store is live at `https://yourdomain.com`.

#### Step 9 — Set your store domain in the app

```bash
# Add APP_URL to your .env
echo "APP_URL=https://yourdomain.com" >> /var/www/mystore/.env
pm2 restart mystore
```

---

### Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `NODE_ENV` | ✅ | Must be `production` |
| `PORT` | ✅ | Port to listen on (default 3000) |
| `JWT_SECRET` | ✅ | 64-byte hex secret for JWT and CAPTCHA signing |
| `SUPER_ADMIN_PASSWORD` | ✅ | Password for the Super Admin login |
| `SYSTEM_RESET_PASSWORD` | ✅ | Password required to reset all data |
| `APP_URL` | ✅ | Your full domain e.g. `https://yourdomain.com` |
| `PERSISTENT_DATA_PATH` | ✅ on VPS | Absolute path to your data folder |
| `GEMINI_API_KEY` | Optional | For AI features (fraud detection, descriptions) |
| `SMTP_HOST` | Optional | For order confirmation emails |
| `TWILIO_ACCOUNT_SID` | Optional | For WhatsApp order notifications |
| `TELEGRAM_BOT_TOKEN` | Optional | For the fulfilment agent |
| `MEESHO_EMAIL` | Optional | For the fulfilment agent |

---

### Updating the store after changes

```bash
# On your local machine
npm run build

# Upload only the changed files
rsync -avz dist/ root@YOUR_VPS_IP:/var/www/mystore/dist/

# Restart
ssh root@YOUR_VPS_IP "pm2 restart mystore"
```

---

### Running the fulfilment agent (optional)

The agent is a separate process. On VPS KVM 2+:

```bash
cd /var/www/mystore

# Install Playwright (one-time, ~300MB)
npm run agent:install

# Add agent env vars to .env, then start
pm2 start agent/index.ts --name agent --interpreter npx --interpreter-args tsx
pm2 save
```

---

### Monitoring

```bash
pm2 status          # process health
pm2 logs mystore    # live logs
pm2 monit           # CPU + memory dashboard
```

Uptime monitoring: use `GET https://yourdomain.com/api/v1/health` — returns `200 { status: "ok" }` when healthy. Plug this URL into UptimeRobot (free) to get alerts if your store goes down.

---

### Backups

```bash
# Run this daily via cron
crontab -e
# Add:
# 0 2 * * * tar -czf /root/backups/mystore-$(date +%Y%m%d).tar.gz /var/www/mystore/data /var/www/mystore/public/uploads
```

Download backups via SFTP to your local machine weekly.

---

## Admin Login

URL: `yourdomain.com/logintosft`  
Email: `super@example.com`  
Password: the value you set for `SUPER_ADMIN_PASSWORD`

All products, categories, orders, affiliates, and store settings are configured from the admin panel after login. The data files start empty — nothing needs to be pre-loaded.

---

## Data & Backups

All store data lives in `data/store.db` — a single SQLite database file. To back up:

1. Download `data/store.db` from your server (weekly recommended). A simple file copy is a valid backup since SQLite is a single self-contained file.
2. Download `public/uploads/` for product images.

To restore: stop the server, replace `data/store.db` and `public/uploads/` with your backup copies, then restart.

For automated backups, see the cron example in the [Hostinger Deployment Guide](#backups) above.

---

## API Pagination

All list endpoints support pagination:

| Parameter | Default | Max | Description |
|---|---|---|---|
| `page` | 1 | — | Page number |
| `limit` | 50 | 200 | Records per page |
| `limit=0` | — | — | Return all records |

Response shape:
```json
{ "data": [...], "total": 150, "page": 2, "pages": 3 }
```

---

## Health Check

```
GET /api/v1/health
```

Returns `200` with `{ "status": "ok", "storage": "writable" }` when the server is running and the data directory is writable. Returns `503` if storage is unavailable — useful for uptime monitors.

---

## FAQ

**Why is my site showing "Cannot GET /"?**  
Make sure the Startup File is `dist/server.js` (not `server.ts`) and that you ran `npm run build` before deploying.

**How do I change the admin password?**  
From the admin panel → System Configuration → Change Password. Or update `SUPER_ADMIN_PASSWORD` in your `.env` and restart.

**Can I run this on shared hosting?**  
Only if the host supports Node.js 20+. Standard shared Linux hosting (cPanel without Node.js) will not work.

---

## Database & Storage

### Current Storage: SQLite (via better-sqlite3)

All data is stored in a single SQLite file: `<DATA_DIR>/store.db`.

SQLite with WAL (Write-Ahead Logging) mode provides:
- **Concurrent reads** — multiple requests read simultaneously without blocking
- **Serialised writes** — SQLite queues writes automatically, no race conditions
- **ACID transactions** — data is never partially written even if the server crashes
- **In-memory cache** — reads are served from memory, writes go to disk synchronously
- **Single file** — easy to backup (`cp store.db store.db.backup`), no separate DB server

### Single-Process Constraint
SQLite is an embedded database. **Do not run more than one Node.js process pointing at the same `store.db` file.** This means:

- **PM2 cluster mode is unsafe.** Use `instances: 1` in your `ecosystem.config.js`.
- **Horizontal scaling (multiple servers) is not supported.** Each server would have its own SQLite file and would not share data.

### Upgrading to PostgreSQL (when you need it)
The `SQLiteStore` class has the same interface as a PostgreSQL repository would. When you are processing 10,000+ orders/month or need multiple servers:

| Scale | Recommended upgrade |
|---|---|
| Single server, high throughput | Already on SQLite — you're fine |
| Multi-server / high availability | PostgreSQL with connection pool (pg + drizzle-orm) |
| Session / cache data | Redis alongside PostgreSQL |

### Migrating from JSON files (existing deployments)

If you are upgrading from a previous version that used JSON files:

```bash
npm run db:migrate
```

This reads all existing `.json` files in your data directory and imports them into SQLite. The JSON files are kept as backup. Run the app, place a test order, then archive the JSON files once confirmed.

### Version Control
A `.git` repository and `.gitignore` are included. The `.gitignore` excludes:
- `.env` — contains secrets
- `data/` — contains customer data; back up separately
- `public/uploads/` — serve from object storage (S3/R2) in production
