/**
 * Route integration tests
 *
 * These tests exercise the HTTP layer directly using a lightweight in-memory
 * server so no real filesystem or network I/O is required.
 *
 * Covers:
 *  - POST /api/v1/orders/action/:id  — rate limit, allowlist, note cap, minimal response
 *  - POST /api/v1/orders/track       — captcha verification gate
 *  - POST /api/v1/newsletter/unsubscribe — always returns 200 (no enumeration)
 *  - Zod order schema validation      — rejects bad payloads before business logic
 */

import { describe, it, expect, beforeAll } from 'vitest';
import express from 'express';
import request from 'supertest';
import { signCaptchaToken } from '../src/server/utils/captcha';

// ── Minimal in-memory DataStore stub ─────────────────────────────────────────

const SECRET = 'test-secret-for-route-tests';

const makeOrder = (overrides: any = {}) => ({
  id: 'ORD-TEST-001',
  status: 'OPEN',
  email: 'customer@example.com',
  phone: '9876543210',
  zip: '400001',
  statusHistory: [],
  items: [],
  ...overrides,
});

function makeContext(orders: any[] = [makeOrder()], subscribers: any[] = []) {
  let _orders = [...orders];
  let _subscribers = [...subscribers];
  return {
    get orders()      { return _orders; },
    get subscribers() { return _subscribers; },
    get config()      { return { orderStatuses: [], coupons: [] }; },
    get products()    { return []; },
    get customers()   { return []; },
    get users()       { return []; },
    setOrders:      (v: any[]) => { _orders = v; },
    setSubscribers: (v: any[]) => { _subscribers = v; },
  };
}

// ── Build a minimal Express app with just the routes we want to test ──────────

async function buildApp(ctx: ReturnType<typeof makeContext>) {
  const app = express();
  app.use(express.json());

  // Inject JWT_SECRET so captcha utils work
  process.env.JWT_SECRET = SECRET;

  const { createOrdersRouter } = await import('../src/server/routes/orders');
  const { createNewsletterRouter } = await import('../src/server/routes/newsletter');

  const dummyAuth = (_req: any, _res: any, next: any) => next();
  const dummyRole = () => (_req: any, _res: any, next: any) => next();
  const noop = async () => {};

  // createOrdersRouter's full signature (must match server.ts's real call site
  // exactly, in order, or downstream middleware silently receives the wrong
  // argument in each slot):
  //   (getContext, calculateOrderFinancials, sendEmailNotification,
  //    sendWhatsAppNotification, sendWebhookNotification, updateAffiliateStats,
  //    logAction, authenticateToken, checkRole, ACTUAL_JWT_SECRET)
  app.use('/api/v1/orders', await createOrdersRouter(
    () => ctx,           // getContext
    noop,                 // calculateOrderFinancials (not exercised by these tests)
    noop,                 // sendEmailNotification
    noop,                 // sendWhatsAppNotification
    noop,                 // sendWebhookNotification
    noop,                 // updateAffiliateStats
    noop,                 // logAction
    dummyAuth,             // authenticateToken
    dummyRole,             // checkRole
    SECRET                // ACTUAL_JWT_SECRET
  ));
  app.use('/api/v1/newsletter', createNewsletterRouter(
    () => ctx,    // getContext
    noop,          // writeData (legacy JSON-file bridge, unused by these tests)
    'config.json', // CONFIG_FILE (placeholder path, unused by these tests)
    dummyAuth,     // authenticateToken
    dummyRole,     // checkRole
    null,          // nodemailer (not exercised by these tests)
    noop           // logAction
  ));

  return app;
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('POST /api/v1/orders/action/:id', () => {
  it('rejects an unknown action string', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/action/ORD-TEST-001')
      .send({ action: 'hack_the_planet', note: '' });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Invalid action/i);
  });

  it('rejects a note longer than 500 characters', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/action/ORD-TEST-001')
      .send({ action: 'inquiry', note: 'x'.repeat(501) });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/500 characters/i);
  });

  it('returns { success: true } without leaking order data', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/action/ORD-TEST-001')
      .send({ action: 'inquiry', note: 'Where is my order?' });

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ success: true });
    // Must NOT include customerName, email, phone, etc.
    expect(res.body.email).toBeUndefined();
    expect(res.body.items).toBeUndefined();
  });

  it('returns 400 for a CLOSED order', async () => {
    const ctx = makeContext([makeOrder({ status: 'CLOSED' })]);
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/action/ORD-TEST-001')
      .send({ action: 'inquiry', note: 'test' });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/CLOSED/i);
  });

  it('returns 404 for an unknown order ID', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/action/ORD-DOES-NOT-EXIST')
      .send({ action: 'inquiry', note: '' });

    expect(res.status).toBe(404);
  });
});

describe('POST /api/v1/orders/track', () => {
  it('returns 400 when no captcha token is provided', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders/track')
      .send({
        orderId: 'ORD-TEST-001',
        contact: 'customer@example.com',
        zip: '400001',
        // captchaToken and captchaAnswer intentionally omitted
      });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Security verification/i);
  });

  it('returns 400 for a wrong captcha answer', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);
    const token = signCaptchaToken('ABCDEF', SECRET);

    const res = await request(app)
      .post('/api/v1/orders/track')
      .send({
        orderId: 'ORD-TEST-001',
        contact: 'customer@example.com',
        zip: '400001',
        captchaToken: token,
        captchaAnswer: 'XXXXXX', // wrong answer
      });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Security verification/i);
  });

  it('returns the order on correct captcha + matching credentials', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);
    const token = signCaptchaToken('ABCDEF', SECRET);

    const res = await request(app)
      .post('/api/v1/orders/track')
      .send({
        orderId: 'ORD-TEST-001',
        contact: 'customer@example.com',
        zip: '400001',
        captchaToken: token,
        captchaAnswer: 'ABCDEF',
      });

    expect(res.status).toBe(200);
    expect(res.body.id).toBe('ORD-TEST-001');
  });

  it('rejects a replayed captcha token', async () => {
    const ctx = makeContext([makeOrder(), makeOrder({ id: 'ORD-TEST-002', zip: '400001' })]);
    const app = await buildApp(ctx);
    const token = signCaptchaToken('ZZZZZZ', SECRET);

    // First use — should succeed
    await request(app).post('/api/v1/orders/track').send({
      orderId: 'ORD-TEST-001', contact: 'customer@example.com', zip: '400001',
      captchaToken: token, captchaAnswer: 'ZZZZZZ',
    });

    // Second use of the same token — should fail
    const res = await request(app).post('/api/v1/orders/track').send({
      orderId: 'ORD-TEST-001', contact: 'customer@example.com', zip: '400001',
      captchaToken: token, captchaAnswer: 'ZZZZZZ',
    });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Security verification/i);
  });
});

describe('POST /api/v1/newsletter/unsubscribe', () => {
  it('returns 200 for a known subscriber (and marks as unsubscribed)', async () => {
    const ctx = makeContext([], [{ email: 'user@example.com', status: 'Subscribed' }]);
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/newsletter/unsubscribe')
      .send({ email: 'user@example.com' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(ctx.subscribers[0].status).toBe('Unsubscribed');
  });

  it('returns 200 even for an unknown email (prevents enumeration)', async () => {
    const ctx = makeContext([], []);
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/newsletter/unsubscribe')
      .send({ email: 'nobody@example.com' });

    // Must NOT return 404 — that would reveal whether the email exists
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });
});

describe('Zod order schema validation', () => {
  it('rejects an order with a non-Indian phone number', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);

    const res = await request(app)
      .post('/api/v1/orders')
      .send({
        customerName: 'Test User',
        email: 'test@example.com',
        phone: '12345',          // not a valid Indian mobile
        address: '123 Main Street, Building A',
        city: 'Mumbai',
        state: 'Maharashtra',
        zip: '400001',
        items: [{ id: 'p1', quantity: 1 }],
        captchaToken: 'x',
        captchaAnswer: 'y',
      });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Indian mobile/i);
  });

  it('rejects an order with more than 50 items', async () => {
    const ctx = makeContext();
    const app = await buildApp(ctx);
    const items = Array.from({ length: 51 }, (_, i) => ({ id: `p${i}`, quantity: 1 }));

    const res = await request(app)
      .post('/api/v1/orders')
      .send({
        customerName: 'Test User',
        email: 'test@example.com',
        phone: '9876543210',
        address: '123 Main Street, Building A',
        city: 'Mumbai',
        state: 'Maharashtra',
        zip: '400001',
        items,
        captchaToken: 'x',
        captchaAnswer: 'y',
      });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Too many items/i);
  });
});
