/**
 * DataStore unit tests
 *
 * Covers:
 *  - Initial load creates file if missing
 *  - get() returns a deep clone (no shared references)
 *  - set() updates cache immediately
 *  - update() applies transform correctly
 *  - Atomic write: tmp file is cleaned up on success
 *  - Corrupted file falls back to initial data
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { DataStore, generateId, generateOrderId } from '../src/server/dataStore';

let tmpDir: string;

beforeEach(() => {
  tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'datastore-test-'));
});

afterEach(() => {
  fs.rmSync(tmpDir, { recursive: true, force: true });
});

describe('DataStore', () => {
  it('creates file with initial data when file does not exist', () => {
    const filePath = path.join(tmpDir, 'store.json');
    const initial = [{ id: '1', name: 'Alice' }];
    new DataStore(filePath, initial);
    expect(fs.existsSync(filePath)).toBe(true);
    const saved = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    expect(saved).toEqual(initial);
  });

  it('loads existing data from file', () => {
    const filePath = path.join(tmpDir, 'store.json');
    const existing = [{ id: '2', name: 'Bob' }];
    fs.writeFileSync(filePath, JSON.stringify(existing));
    const store = new DataStore(filePath, []);
    expect(store.get()).toEqual(existing);
  });

  it('get() returns a deep clone — mutations do not affect internal cache', () => {
    const filePath = path.join(tmpDir, 'store.json');
    const store = new DataStore(filePath, [{ id: '1' }]);
    const a = store.get() as any[];
    a[0].id = 'MUTATED';
    const b = store.get() as any[];
    expect(b[0].id).toBe('1'); // unchanged
  });

  it('set() updates cache synchronously', () => {
    const filePath = path.join(tmpDir, 'store.json');
    const store = new DataStore(filePath, []);
    store.set([{ id: '99' }]);
    expect(store.get()).toEqual([{ id: '99' }]);
  });

  it('update() applies the transform and returns new value', () => {
    const filePath = path.join(tmpDir, 'store.json');
    const store = new DataStore<number[]>(filePath, [1, 2, 3]);
    store.update(arr => [...arr, 4]);
    expect(store.get()).toEqual([1, 2, 3, 4]);
  });

  it('falls back to initial data when file contains invalid JSON', async () => {
    const filePath = path.join(tmpDir, 'corrupt.json');
    fs.writeFileSync(filePath, 'NOT JSON {{{{');
    const store = new DataStore(filePath, { fallback: true });
    expect((store.get() as any).fallback).toBe(true);
  });

  it('falls back to initial data when file is empty', () => {
    const filePath = path.join(tmpDir, 'empty.json');
    fs.writeFileSync(filePath, '');
    const store = new DataStore(filePath, { empty: false });
    expect((store.get() as any).empty).toBe(false);
  });

  it('tmp file is removed after a successful atomic write', async () => {
    const filePath = path.join(tmpDir, 'atomic.json');
    const store = new DataStore(filePath, []);
    store.set([{ id: 'x' }]);
    // Allow the async write queue to flush
    await new Promise(r => setTimeout(r, 50));
    expect(fs.existsSync(`${filePath}.tmp`)).toBe(false);
    const saved = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    expect(saved).toEqual([{ id: 'x' }]);
  });
});

// ── ID helpers ────────────────────────────────────────────────────────────────

describe('generateId', () => {
  it('returns a non-empty string', () => {
    expect(generateId()).toBeTruthy();
  });
  it('generates unique values', () => {
    const ids = new Set(Array.from({ length: 100 }, generateId));
    expect(ids.size).toBe(100);
  });
});

describe('generateOrderId', () => {
  it('starts with ORD-', () => {
    expect(generateOrderId().startsWith('ORD-')).toBe(true);
  });
  it('generates unique order IDs', () => {
    const ids = new Set(Array.from({ length: 100 }, generateOrderId));
    expect(ids.size).toBe(100);
  });
});
