/**
 * CAPTCHA signing and verification tests
 *
 * Duplicates the helper functions from auth.ts so they can be tested in isolation.
 */

import { describe, it, expect } from 'vitest';
import crypto from 'crypto';

const CAPTCHA_EXPIRY_MS = 5 * 60 * 1000;
const SECRET = 'test-secret-key-32chars-xxxxxxxxxxxx';

function signCaptchaToken(code: string, secret: string): string {
  const payload = Buffer.from(
    JSON.stringify({ code: code.toUpperCase(), exp: Date.now() + CAPTCHA_EXPIRY_MS })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyCaptchaToken(token: string, answer: string, secret: string): boolean {
  try {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return false;
    const expectedSig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) return false;
    const { code, exp } = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (Date.now() > exp) return false;
    return answer.toUpperCase() === code;
  } catch {
    return false;
  }
}

describe('CAPTCHA token lifecycle', () => {
  it('verifies a freshly signed token with the correct answer', () => {
    const token = signCaptchaToken('ABC123', SECRET);
    expect(verifyCaptchaToken(token, 'ABC123', SECRET)).toBe(true);
  });

  it('is case-insensitive on answer', () => {
    const token = signCaptchaToken('XYZ', SECRET);
    expect(verifyCaptchaToken(token, 'xyz', SECRET)).toBe(true);
  });

  it('rejects wrong answer', () => {
    const token = signCaptchaToken('ABC', SECRET);
    expect(verifyCaptchaToken(token, 'XYZ', SECRET)).toBe(false);
  });

  it('rejects token signed with different secret', () => {
    const token = signCaptchaToken('ABC', 'other-secret');
    expect(verifyCaptchaToken(token, 'ABC', SECRET)).toBe(false);
  });

  it('rejects an expired token', () => {
    // Build a token with exp in the past
    const payload = Buffer.from(
      JSON.stringify({ code: 'TEST', exp: Date.now() - 1000 })
    ).toString('base64url');
    const sig = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
    const token = `${payload}.${sig}`;
    expect(verifyCaptchaToken(token, 'TEST', SECRET)).toBe(false);
  });

  it('rejects a malformed token (no dot separator)', () => {
    expect(verifyCaptchaToken('nodot', 'TEST', SECRET)).toBe(false);
  });

  it('rejects an empty token', () => {
    expect(verifyCaptchaToken('', 'TEST', SECRET)).toBe(false);
  });

  it('rejects token with tampered payload', () => {
    const token = signCaptchaToken('ABC', SECRET);
    const [_payload, sig] = token.split('.');
    const tampered = Buffer.from(
      JSON.stringify({ code: 'XYZ', exp: Date.now() + CAPTCHA_EXPIRY_MS })
    ).toString('base64url');
    const tamperedToken = `${tampered}.${sig}`;
    expect(verifyCaptchaToken(tamperedToken, 'XYZ', SECRET)).toBe(false);
  });
});
