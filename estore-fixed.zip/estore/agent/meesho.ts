/**
 * meesho.ts
 *
 * Playwright-based automation for placing, cancelling, and initiating returns
 * on Meesho. Uses Gemini vision as a fallback when CSS selectors fail due to
 * Meesho UI changes.
 *
 * Session persistence:
 *  - Cookies are saved to data/meesho_session.json after every successful action
 *  - On startup the session is loaded and a lightweight check is done to verify
 *    it is still valid before placing any orders
 *  - On session expiry, the agent emits a 'session_expired' event so the
 *    Telegram bot can alert the admin
 *
 * OTP handling:
 *  - If login triggers an OTP screen, the agent emits 'otp_required' and pauses
 *    The Telegram bot prompts the admin to log in manually on their phone,
 *    then sends a 'session_resume' callback which calls resumeAfterManualLogin()
 */

import * as fs   from 'fs';
import * as path from 'path';
import { EventEmitter } from 'events';
import { Order } from '../src/types.js';

// Playwright is an optional peer dependency — loaded lazily so the main server
// starts even if the agent is not installed yet.
let playwright: typeof import('playwright') | null = null;
async function getPlaywright() {
  if (!playwright) {
    try {
      playwright = await import('playwright');
    } catch {
      throw new Error(
        'Playwright is not installed. Run: npm install playwright && npx playwright install chromium'
      );
    }
  }
  return playwright;
}

const SESSION_FILE = path.join(process.cwd(), 'data', 'meesho_session.json');
const MEESHO_BASE  = 'https://meesho.com';

export interface PlacementResult {
  success:       boolean;
  meeshoOrderId: string | null;
  meeshoOrderUrl: string | null;
  error?:        string;
  screenshot?:   string;   // base64 PNG — sent to Telegram on failure
}

export class MeeshoAgent extends EventEmitter {
  private email:    string;
  private password: string;
  private geminiKey: string | null;
  private browser:  any = null;
  private context:  any = null;
  private page:     any = null;
  private sessionValid = false;
  private sessionPaused = false;

  constructor(email: string, password: string, geminiKey?: string) {
    super();
    this.email     = email;
    this.password  = password;
    this.geminiKey = geminiKey ?? process.env.GEMINI_API_KEY ?? null;
  }

  // ── Browser lifecycle ──────────────────────────────────────────────────────

  async launch() {
    const pw = await getPlaywright();
    this.browser = await pw.chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-blink-features=AutomationControlled',
      ],
    });
    const storageState = fs.existsSync(SESSION_FILE)
      ? JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'))
      : undefined;
    this.context = await this.browser.newContext({
      userAgent: 'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      viewport:  { width: 390, height: 844 },
      locale:    'en-IN',
      storageState,
    });
    this.page = await this.context.newPage();
    console.log('[Meesho] Browser launched');
  }

  async close() {
    await this.browser?.close().catch(() => {});
    this.browser = null;
    this.context = null;
    this.page    = null;
  }

  private async saveSession() {
    const state = await this.context.storageState();
    fs.mkdirSync(path.dirname(SESSION_FILE), { recursive: true });
    fs.writeFileSync(SESSION_FILE, JSON.stringify(state));
  }

  // ── Session management ─────────────────────────────────────────────────────

  async verifySession(): Promise<boolean> {
    try {
      await this.page.goto('https://meesho.com/profile', { waitUntil: 'domcontentloaded', timeout: 20000 });
      await this.page.waitForTimeout(2000);
      const url = this.page.url();
      // If we are redirected to login, session is expired
      if (url.includes('/login') || url.includes('/signin')) {
        this.sessionValid = false;
        return false;
      }
      // Check for a profile-related element
      const hasProfile = await this.page.$('[data-testid="profile-name"], .profile-name, [class*="ProfileName"]').catch(() => null);
      this.sessionValid = !!hasProfile;
      return this.sessionValid;
    } catch {
      this.sessionValid = false;
      return false;
    }
  }

  async login(): Promise<boolean> {
    try {
      await this.page.goto('https://meesho.com', { waitUntil: 'domcontentloaded', timeout: 20000 });
      await this.page.waitForTimeout(1500);

      // Click login button
      const loginBtn = await this.page.$('[data-testid="login-btn"], .login-btn, [class*="LoginButton"]');
      if (!loginBtn) {
        // Try the navigation login link
        await this.page.click('text=Login').catch(() => {});
      } else {
        await loginBtn.click();
      }
      await this.page.waitForTimeout(1500);

      // Fill phone/email
      const phoneInput = await this.page.$('input[type="tel"], input[placeholder*="phone"], input[placeholder*="mobile"]');
      if (phoneInput) {
        await phoneInput.fill(this.email.includes('@') ? this.email : this.email.replace(/^\+91/, ''));
      } else {
        throw new Error('Could not find phone/email input on Meesho login page');
      }

      // Submit
      const continueBtn = await this.page.$('button[type="submit"], button:has-text("Continue"), button:has-text("Send OTP")');
      if (continueBtn) await continueBtn.click();
      await this.page.waitForTimeout(2000);

      // Check if OTP screen appeared
      const otpInput = await this.page.$('input[name="otp"], input[placeholder*="OTP"], input[placeholder*="otp"]');
      if (otpInput) {
        console.log('[Meesho] OTP required — alerting admin');
        this.emit('otp_required');
        this.sessionPaused = true;
        return false;
      }

      // Some accounts go straight to password
      const passInput = await this.page.$('input[type="password"]');
      if (passInput) {
        await passInput.fill(this.password);
        const loginSubmit = await this.page.$('button[type="submit"]');
        if (loginSubmit) await loginSubmit.click();
        await this.page.waitForTimeout(3000);
      }

      await this.saveSession();
      this.sessionValid = true;
      console.log('[Meesho] Login successful');
      return true;
    } catch (e: any) {
      console.error('[Meesho] Login error:', e.message);
      return false;
    }
  }

  /** Called when admin taps "I've logged in — Resume" in Telegram */
  async resumeAfterManualLogin() {
    this.sessionPaused = false;
    await this.saveSession();
    const valid = await this.verifySession();
    if (valid) {
      console.log('[Meesho] Session resumed after manual login');
      this.emit('session_resumed');
    } else {
      this.emit('session_expired');
    }
  }

  private async ensureSession(): Promise<boolean> {
    if (this.sessionPaused) return false;
    if (this.sessionValid) return true;
    const valid = await this.verifySession();
    if (valid) return true;
    // Try logging in
    const loggedIn = await this.login();
    if (!loggedIn && !this.sessionPaused) {
      this.emit('session_expired');
    }
    return loggedIn;
  }

  // ── Order placement ────────────────────────────────────────────────────────

  async placeOrder(order: Order): Promise<PlacementResult> {
    if (!await this.ensureSession()) {
      return { success: false, meeshoOrderId: null, meeshoOrderUrl: null, error: 'Session not available' };
    }

    for (const item of order.items) {
      if (!item.sourceUrl) {
        return { success: false, meeshoOrderId: null, meeshoOrderUrl: null, error: `Item "${item.name}" has no Meesho source URL. Set the sourceUrl on the product.` };
      }
    }

    try {
      // Place each item (for simplicity, we handle the first item; multi-item is handled
      // by placing them in sequence — Meesho doesn't have a cross-product cart)
      let lastOrderId: string | null = null;
      let lastOrderUrl: string | null = null;

      for (const item of order.items) {
        const result = await this.placeItem(order, item);
        if (!result.success) return result;
        lastOrderId  = result.meeshoOrderId;
        lastOrderUrl = result.meeshoOrderUrl;
      }

      await this.saveSession();
      return { success: true, meeshoOrderId: lastOrderId!, meeshoOrderUrl: lastOrderUrl };
    } catch (e: any) {
      const screenshot = await this.captureScreenshot();
      if (e.message?.includes('session') || e.message?.includes('login')) {
        this.sessionValid = false;
        this.emit('session_expired');
      }
      return { success: false, meeshoOrderId: null, meeshoOrderUrl: null, error: e.message, screenshot };
    }
  }

  private async placeItem(order: Order, item: any): Promise<PlacementResult> {
    console.log(`[Meesho] Placing item: ${item.name} from ${item.sourceUrl}`);
    await this.page.goto(item.sourceUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await this.page.waitForTimeout(2000);

    // Select variants using Gemini vision if needed
    if (item.selectedVariants && Object.keys(item.selectedVariants).length > 0) {
      await this.selectVariants(item.selectedVariants);
    }

    // Set quantity
    if (item.quantity > 1) {
      await this.setQuantity(item.quantity);
    }

    // Click "Buy Now" (COD flow — we go directly to checkout)
    const bought = await this.clickBuyNow();
    if (!bought) {
      const screenshot = await this.captureScreenshot();
      return { success: false, meeshoOrderId: null, meeshoOrderUrl: null, error: 'Could not find Buy Now button', screenshot };
    }

    await this.page.waitForTimeout(2000);

    // Fill delivery address
    await this.fillAddress(order);
    await this.page.waitForTimeout(1500);

    // Select COD payment
    await this.selectCOD();
    await this.page.waitForTimeout(1000);

    // Confirm the order
    const confirmed = await this.confirmOrder();
    if (!confirmed) {
      const screenshot = await this.captureScreenshot();
      return { success: false, meeshoOrderId: null, meeshoOrderUrl: null, error: 'Order confirmation failed', screenshot };
    }

    await this.page.waitForTimeout(3000);

    // Extract order ID from confirmation page
    const orderId = await this.extractOrderId();
    const orderUrl = this.page.url();

    return { success: true, meeshoOrderId: orderId, meeshoOrderUrl: orderUrl };
  }

  private async selectVariants(variants: Record<string, string>) {
    for (const [key, value] of Object.entries(variants)) {
      // Try to find and click the right variant option
      const clicked = await this.page.evaluate(({ key, value }: { key: string; value: string }) => {
        const labels = document.querySelectorAll('[class*="variant"], [class*="Variant"], [class*="size"], [class*="Size"], [class*="color"], [class*="Color"]');
        for (const label of labels) {
          if (label.textContent?.trim().toLowerCase() === value.toLowerCase()) {
            (label as HTMLElement).click();
            return true;
          }
        }
        return false;
      }, { key, value });

      if (!clicked && this.geminiKey) {
        // Fallback: use Gemini vision to find the right variant
        await this.selectVariantWithGemini(key, value);
      }
    }
    await this.page.waitForTimeout(500);
  }

  private async selectVariantWithGemini(variantType: string, variantValue: string) {
    const screenshot = await this.page.screenshot({ type: 'jpeg', quality: 60 });
    const base64     = screenshot.toString('base64');

    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': this.geminiKey! },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: 'image/jpeg', data: base64 } },
              { text: `This is a product page. I need to select the variant: ${variantType} = "${variantValue}". What CSS selector or text content should I click? Return JSON only: {"selector": "...", "text": "..."}` },
            ],
          }],
        }),
      });
      const data = await response.json() as any;
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
      const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
      if (parsed.text) {
        await this.page.click(`text=${parsed.text}`).catch(() => {});
      } else if (parsed.selector) {
        await this.page.click(parsed.selector).catch(() => {});
      }
    } catch {
      console.warn(`[Meesho] Gemini variant selection failed for ${variantType}=${variantValue}`);
    }
  }

  private async setQuantity(quantity: number) {
    // Try to find a quantity input or stepper
    try {
      const qtyInput = await this.page.$('input[name="quantity"], input[type="number"]');
      if (qtyInput) {
        await qtyInput.fill(String(quantity));
        return;
      }
      // Try plus button
      const plusBtn = await this.page.$('[class*="increment"], [class*="plus"], button:has-text("+")');
      if (plusBtn) {
        for (let i = 1; i < quantity; i++) {
          await plusBtn.click();
          await this.page.waitForTimeout(200);
        }
      }
    } catch {
      // Quantity selection is non-critical — continue
    }
  }

  private async clickBuyNow(): Promise<boolean> {
    const selectors = [
      '[data-testid="buy-now-btn"]',
      'button:has-text("Buy Now")',
      'button:has-text("Buy now")',
      '[class*="BuyNow"]',
      '[class*="buy-now"]',
    ];
    for (const sel of selectors) {
      const btn = await this.page.$(sel).catch(() => null);
      if (btn) {
        await btn.click();
        return true;
      }
    }
    // Gemini fallback
    if (this.geminiKey) {
      return await this.clickWithGemini('the "Buy Now" button');
    }
    return false;
  }

  private async fillAddress(order: Order) {
    // Check if address is already saved / matching
    try {
      // Look for "Add new address" or "Deliver here" on saved addresses
      const addNewBtn = await this.page.$('button:has-text("Add new address"), [class*="AddAddress"]').catch(() => null);

      if (addNewBtn) {
        await addNewBtn.click();
        await this.page.waitForTimeout(1000);
      }

      // Fill address fields
      const fields: Record<string, string> = {
        'input[placeholder*="Name"], input[name="name"], input[id*="name"]':    order.customerName,
        'input[placeholder*="Phone"], input[type="tel"], input[name="mobile"]': order.phone,
        'input[placeholder*="Pincode"], input[name="pincode"], input[placeholder*="PIN"]': order.zip,
        'input[placeholder*="Address"], input[name="address"], textarea[name="address"]':  order.address,
        'input[placeholder*="City"], input[name="city"]':   order.city,
        'input[placeholder*="State"], select[name="state"]': order.state,
      };

      for (const [selector, value] of Object.entries(fields)) {
        const el = await this.page.$(selector).catch(() => null);
        if (el) {
          await el.fill(value);
          await this.page.waitForTimeout(300);
        }
      }

      // Save address
      const saveBtn = await this.page.$('button:has-text("Save"), button:has-text("Deliver here"), button[type="submit"]').catch(() => null);
      if (saveBtn) await saveBtn.click();
      await this.page.waitForTimeout(1500);
    } catch (e: any) {
      console.warn('[Meesho] Address fill warning:', e.message);
    }
  }

  private async selectCOD() {
    const selectors = [
      '[data-testid="cod-option"]',
      'text=Cash on Delivery',
      'text=COD',
      '[class*="CodOption"]',
      'input[value="COD"]',
    ];
    for (const sel of selectors) {
      const el = await this.page.$(sel).catch(() => null);
      if (el) {
        await el.click().catch(() => {});
        return;
      }
    }
  }

  private async confirmOrder(): Promise<boolean> {
    const selectors = [
      'button:has-text("Place Order")',
      'button:has-text("Confirm Order")',
      'button:has-text("Order Now")',
      '[data-testid="place-order-btn"]',
      '[class*="PlaceOrder"]',
    ];
    for (const sel of selectors) {
      const btn = await this.page.$(sel).catch(() => null);
      if (btn) {
        await btn.click();
        await this.page.waitForTimeout(4000);
        return true;
      }
    }
    if (this.geminiKey) {
      return await this.clickWithGemini('the "Place Order" or "Confirm Order" button');
    }
    return false;
  }

  private async extractOrderId(): Promise<string | null> {
    // Try common confirmation page patterns
    const patterns = [
      /order[- ]id[:\s]+([A-Z0-9-]+)/i,
      /order number[:\s]+([A-Z0-9-]+)/i,
      /#([A-Z0-9-]{8,})/,
    ];
    const pageText = await this.page.innerText('body').catch(() => '');
    for (const re of patterns) {
      const match = pageText.match(re);
      if (match) return match[1];
    }

    // Gemini fallback — screenshot the confirmation page
    if (this.geminiKey) {
      const screenshot = await this.page.screenshot({ type: 'jpeg', quality: 60 });
      const base64     = screenshot.toString('base64');
      try {
        const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': this.geminiKey },
          body: JSON.stringify({
            contents: [{
              parts: [
                { inline_data: { mime_type: 'image/jpeg', data: base64 } },
                { text: 'This is a Meesho order confirmation page. Extract the order ID or order number. Return JSON only: {"orderId": "..."}. If not found, return {"orderId": null}.' },
              ],
            }],
          }),
        });
        const data = await response.json() as any;
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
        const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
        return parsed.orderId ?? null;
      } catch {
        return null;
      }
    }

    return null;
  }

  // ── Cancellation ───────────────────────────────────────────────────────────

  async cancelOrder(meeshoOrderId: string): Promise<{ success: boolean; error?: string }> {
    if (!await this.ensureSession()) {
      return { success: false, error: 'Session not available' };
    }

    try {
      await this.page.goto('https://meesho.com/orders', { waitUntil: 'domcontentloaded', timeout: 30000 });
      await this.page.waitForTimeout(2000);

      // Find the order
      const orderLink = await this.page.$(`text=${meeshoOrderId}, [data-order-id="${meeshoOrderId}"]`).catch(() => null);
      if (!orderLink) {
        return { success: false, error: `Order ${meeshoOrderId} not found on Meesho orders page` };
      }
      await orderLink.click();
      await this.page.waitForTimeout(2000);

      // Click Cancel
      const cancelBtn = await this.page.$('button:has-text("Cancel"), [class*="CancelOrder"]').catch(() => null);
      if (!cancelBtn) {
        return { success: false, error: 'Cancel button not found — order may already be shipped' };
      }
      await cancelBtn.click();
      await this.page.waitForTimeout(1000);

      // Confirm cancellation
      const confirmBtn = await this.page.$('button:has-text("Yes"), button:has-text("Confirm Cancel")').catch(() => null);
      if (confirmBtn) await confirmBtn.click();
      await this.page.waitForTimeout(2000);

      await this.saveSession();
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  // ── Return initiation ──────────────────────────────────────────────────────

  async initiateReturn(meeshoOrderId: string, reason: string): Promise<{ success: boolean; error?: string }> {
    if (!await this.ensureSession()) {
      return { success: false, error: 'Session not available' };
    }

    try {
      await this.page.goto('https://meesho.com/orders', { waitUntil: 'domcontentloaded', timeout: 30000 });
      await this.page.waitForTimeout(2000);

      const orderLink = await this.page.$(`text=${meeshoOrderId}`).catch(() => null);
      if (!orderLink) {
        return { success: false, error: `Order ${meeshoOrderId} not found` };
      }
      await orderLink.click();
      await this.page.waitForTimeout(2000);

      const returnBtn = await this.page.$('button:has-text("Return"), button:has-text("Exchange"), [class*="ReturnOrder"]').catch(() => null);
      if (!returnBtn) {
        return { success: false, error: 'Return button not found — return window may have passed' };
      }
      await returnBtn.click();
      await this.page.waitForTimeout(1000);

      // Select return reason
      const reasonSelect = await this.page.$('select, [class*="ReasonSelect"]').catch(() => null);
      if (reasonSelect) {
        // Pick the closest matching option
        await this.page.evaluate((r: string) => {
          const sel = document.querySelector('select') as HTMLSelectElement;
          if (!sel) return;
          const options = Array.from(sel.options);
          const match = options.find(o => o.text.toLowerCase().includes('defect') || o.text.toLowerCase().includes('wrong'));
          if (match) sel.value = match.value;
        }, reason);
      }

      const submitReturn = await this.page.$('button:has-text("Submit"), button:has-text("Request Return")').catch(() => null);
      if (submitReturn) await submitReturn.click();
      await this.page.waitForTimeout(2000);

      await this.saveSession();
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  // ── Utilities ─────────────────────────────────────────────────────────────

  private async clickWithGemini(description: string): Promise<boolean> {
    if (!this.geminiKey) return false;
    const screenshot = await this.page.screenshot({ type: 'jpeg', quality: 60 });
    const base64     = screenshot.toString('base64');
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': this.geminiKey },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: 'image/jpeg', data: base64 } },
              { text: `This is a webpage screenshot. Find ${description}. Return JSON only: {"selector": "...", "text": "..."} — use whichever is most reliable. If not found, return {"selector": null, "text": null}.` },
            ],
          }],
        }),
      });
      const data = await response.json() as any;
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
      const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
      if (parsed.text) {
        await this.page.click(`text=${parsed.text}`).catch(() => {});
        return true;
      }
      if (parsed.selector) {
        await this.page.click(parsed.selector).catch(() => {});
        return true;
      }
    } catch {
      // Gemini failed — continue with deterministic fallback
    }
    return false;
  }

  async captureScreenshot(): Promise<string | undefined> {
    try {
      const buf = await this.page?.screenshot({ type: 'jpeg', quality: 50 });
      return buf?.toString('base64');
    } catch {
      return undefined;
    }
  }
}
