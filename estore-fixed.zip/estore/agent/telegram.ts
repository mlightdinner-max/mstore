/**
 * telegram.ts
 *
 * Telegram Bot wrapper for the fulfilment agent.
 *
 * Responsibilities:
 *  - Send order notification messages with inline action buttons
 *  - Edit messages in-place when order status changes
 *  - Handle incoming button callbacks (Place / Skip / Manual / Retry / Cancel / Return)
 *  - Send session-expired alerts with resume button
 *  - Send daily summary
 *
 * Uses the Telegram Bot API directly via fetch — no external SDK needed.
 * Bot token is read from process.env.TELEGRAM_BOT_TOKEN at startup.
 */

import { Order } from '../src/types.js';

const BASE = 'https://api.telegram.org/bot';

export type TelegramCallback =
  | { type: 'place';          orderId: string }
  | { type: 'skip';           orderId: string }
  | { type: 'manual';         orderId: string }
  | { type: 'retry';          orderId: string }
  | { type: 'cancel_confirm'; orderId: string }
  | { type: 'cancel_reject';  orderId: string }
  | { type: 'return_confirm'; orderId: string }
  | { type: 'return_reject';  orderId: string }
  | { type: 'session_resume'               }
  | { type: 'summary'                      };

export class TelegramBot {
  private token: string;
  private chatId: string;
  private pollingOffset = 0;
  private onCallback?: (cb: TelegramCallback) => void;
  private polling = false;

  constructor(token: string, chatId: string) {
    this.token  = token;
    this.chatId = chatId;
  }

  private url(method: string) {
    return `${BASE}${this.token}/${method}`;
  }

  private async call(method: string, body: Record<string, any> = {}): Promise<any> {
    try {
      const res = await fetch(this.url(method), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(10_000),
      });
      const json = await res.json() as any;
      if (!json.ok) {
        console.error(`[Telegram] ${method} failed:`, json.description);
        return null;
      }
      return json.result;
    } catch (e: any) {
      console.error(`[Telegram] ${method} error:`, e.message);
      return null;
    }
  }

  /** Verify bot token and connectivity */
  async test(): Promise<boolean> {
    const me = await this.call('getMe');
    if (me) console.log(`[Telegram] Connected as @${me.username}`);
    return !!me;
  }

  // ── Outbound messages ──────────────────────────────────────────────────────

  /** Send new order notification — returns the message_id for later editing */
  async sendNewOrderNotification(order: Order): Promise<number | null> {
    const itemList = order.items
      .map(i => `  • ${i.name}${i.selectedVariants ? ' (' + Object.values(i.selectedVariants).join(', ') + ')' : ''} × ${i.quantity}`)
      .join('\n');

    const text =
      `🛍 *NEW ORDER — ${order.id}*\n` +
      `👤 ${escMd(order.customerName)}\n` +
      `📱 ${escMd(order.phone)}\n` +
      `📦 Items:\n${escMd(itemList)}\n` +
      `💰 Total: ₹${order.total.toLocaleString('en-IN')} \\(COD\\)\n` +
      `📍 ${escMd(order.address)}, ${escMd(order.city)}, ${escMd(order.state)} \\- ${escMd(order.zip)}\n\n` +
      `_Tap Place to let the agent place this order on Meesho automatically\\._`;

    const result = await this.call('sendMessage', {
      chat_id:    this.chatId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: {
        inline_keyboard: [[
          { text: '✅ Place on Meesho', callback_data: `place:${order.id}` },
          { text: '⏭ Skip',            callback_data: `skip:${order.id}`  },
        ], [
          { text: '✋ Place Manually',  callback_data: `manual:${order.id}` },
        ]],
      },
    });
    return result?.message_id ?? null;
  }

  /** Edit an existing message to show placement success */
  async editOrderPlaced(messageId: number, order: Order, meeshoOrderId: string) {
    const text =
      `✅ *ORDER PLACED — ${order.id}*\n` +
      `Meesho Order ID: \`${escMd(meeshoOrderId)}\`\n` +
      `👤 ${escMd(order.customerName)}\n` +
      `💰 ₹${order.total.toLocaleString('en-IN')} \\(COD\\)\n\n` +
      `_Meesho will handle shipping and delivery\\._`;

    await this.call('editMessageText', {
      chat_id:    this.chatId,
      message_id: messageId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: { inline_keyboard: [] },
    });
  }

  /** Edit message to show placement failure with retry option */
  async editOrderFailed(messageId: number, order: Order, error: string, attempts: number, maxAttempts: number) {
    const canRetry = attempts < maxAttempts;
    const text =
      `⚠️ *PLACEMENT FAILED — ${order.id}*\n` +
      `Attempt ${attempts}/${maxAttempts}\n` +
      `Error: ${escMd(error.slice(0, 200))}\n\n` +
      `👤 ${escMd(order.customerName)} — ₹${order.total.toLocaleString('en-IN')}\n\n` +
      (canRetry
        ? `_Tap Retry to try again, or Place Manually to handle it yourself\\._`
        : `_Maximum attempts reached\\. Please place this order manually\\._`);

    const keyboard = canRetry
      ? [[
          { text: '🔄 Retry',          callback_data: `retry:${order.id}`  },
          { text: '✋ Place Manually', callback_data: `manual:${order.id}` },
        ]]
      : [[
          { text: '✋ Place Manually', callback_data: `manual:${order.id}` },
        ]];

    await this.call('editMessageText', {
      chat_id:    this.chatId,
      message_id: messageId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: { inline_keyboard: keyboard },
    });
  }

  /** Send cancellation request notification */
  async sendCancellationRequest(order: Order): Promise<number | null> {
    const reason = order.customerRequest?.note || 'No reason provided';
    const text =
      `❌ *CANCELLATION REQUEST — ${order.id}*\n` +
      `👤 ${escMd(order.customerName)}\n` +
      `Reason: _${escMd(reason)}_\n` +
      `Meesho Order: \`${escMd(order.meeshoOrderId || 'Not placed yet')}\`\n\n` +
      `_Approve to cancel on Meesho, or reject to keep the order active\\._`;

    const result = await this.call('sendMessage', {
      chat_id:    this.chatId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: {
        inline_keyboard: [[
          { text: '✅ Cancel on Meesho', callback_data: `cancel_confirm:${order.id}` },
          { text: '❌ Reject Request',   callback_data: `cancel_reject:${order.id}`  },
        ]],
      },
    });
    return result?.message_id ?? null;
  }

  /** Send return request notification */
  async sendReturnRequest(order: Order): Promise<number | null> {
    const reason = order.customerRequest?.note || 'No reason provided';
    const text =
      `↩️ *RETURN REQUEST — ${order.id}*\n` +
      `👤 ${escMd(order.customerName)}\n` +
      `Reason: _${escMd(reason)}_\n` +
      `Meesho Order: \`${escMd(order.meeshoOrderId || 'Unknown')}\`\n\n` +
      `_Approve to initiate return on Meesho, or reject\\._`;

    const result = await this.call('sendMessage', {
      chat_id:    this.chatId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: {
        inline_keyboard: [[
          { text: '✅ Approve Return', callback_data: `return_confirm:${order.id}` },
          { text: '❌ Reject Return',  callback_data: `return_reject:${order.id}`  },
        ]],
      },
    });
    return result?.message_id ?? null;
  }

  /** Send session-expired alert */
  async sendSessionExpired(): Promise<void> {
    await this.call('sendMessage', {
      chat_id:    this.chatId,
      text:
        `🔐 *Meesho Session Expired*\n\n` +
        `The agent's Meesho login session has expired\\.\n` +
        `Please:\n` +
        `1\\. Open Meesho on your phone\n` +
        `2\\. Log in with your account\n` +
        `3\\. Tap the button below so the agent can resume\n\n` +
        `_New orders will be queued until you resume\\._`,
      parse_mode: 'MarkdownV2',
      reply_markup: {
        inline_keyboard: [[
          { text: '✅ I\'ve logged in — Resume', callback_data: 'session_resume' },
        ]],
      },
    });
  }

  /** Send plain text alert */
  async sendAlert(text: string): Promise<void> {
    await this.call('sendMessage', {
      chat_id:    this.chatId,
      text:       escMd(text),
      parse_mode: 'MarkdownV2',
    });
  }

  /** Send a daily summary */
  async sendSummary(stats: {
    placed: number; pending: number; failed: number;
    cancelled: number; returned: number; total: number;
  }): Promise<void> {
    const text =
      `📊 *Daily Summary*\n\n` +
      `🛍 Total orders today: *${stats.total}*\n` +
      `✅ Placed on Meesho: *${stats.placed}*\n` +
      `⏳ Pending confirmation: *${stats.pending}*\n` +
      `❌ Failed \\(need action\\): *${stats.failed}*\n` +
      `🚫 Cancelled: *${stats.cancelled}*\n` +
      `↩️ Returns initiated: *${stats.returned}*`;

    await this.call('sendMessage', {
      chat_id:    this.chatId,
      text,
      parse_mode: 'MarkdownV2',
    });
  }

  // ── Answer callback queries ───────────────────────────────────────────────

  async answerCallback(callbackQueryId: string, text?: string) {
    await this.call('answerCallbackQuery', {
      callback_query_id: callbackQueryId,
      text:              text ?? '✓',
      show_alert:        false,
    });
  }

  // ── Long-polling loop ─────────────────────────────────────────────────────

  onCallbackQuery(handler: (cb: TelegramCallback) => void) {
    this.onCallback = handler;
  }

  startPolling() {
    if (this.polling) return;
    this.polling = true;
    this.poll();
  }

  stopPolling() {
    this.polling = false;
  }

  private async poll() {
    while (this.polling) {
      try {
        const updates = await this.call('getUpdates', {
          offset:  this.pollingOffset,
          timeout: 25,
          allowed_updates: ['callback_query', 'message'],
        }) as any[];

        if (updates?.length) {
          for (const update of updates) {
            this.pollingOffset = update.update_id + 1;
            await this.handleUpdate(update);
          }
        }
      } catch (e: any) {
        console.error('[Telegram] Poll error:', e.message);
        await sleep(5000);
      }
    }
  }

  private async handleUpdate(update: any) {
    // Handle button presses
    if (update.callback_query) {
      const cq   = update.callback_query;
      const data = cq.data as string;
      await this.answerCallback(cq.id);

      const cb = parseCallback(data);
      if (cb && this.onCallback) this.onCallback(cb);
      return;
    }

    // Handle /summary command
    if (update.message?.text === '/summary' && this.onCallback) {
      this.onCallback({ type: 'summary' });
    }
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Escape special characters for MarkdownV2 */
function escMd(text: string): string {
  return String(text ?? '').replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
}

function parseCallback(data: string): TelegramCallback | null {
  const [type, orderId] = data.split(':');
  switch (type) {
    case 'place':          return { type: 'place',          orderId };
    case 'skip':           return { type: 'skip',           orderId };
    case 'manual':         return { type: 'manual',         orderId };
    case 'retry':          return { type: 'retry',          orderId };
    case 'cancel_confirm': return { type: 'cancel_confirm', orderId };
    case 'cancel_reject':  return { type: 'cancel_reject',  orderId };
    case 'return_confirm': return { type: 'return_confirm', orderId };
    case 'return_reject':  return { type: 'return_reject',  orderId };
    case 'session_resume': return { type: 'session_resume'           };
    case 'summary':        return { type: 'summary'                  };
    default:               return null;
  }
}

function sleep(ms: number) {
  return new Promise(r => setTimeout(r, ms));
}
