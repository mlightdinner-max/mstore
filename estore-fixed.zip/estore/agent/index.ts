/**
 * index.ts — Fulfilment Agent
 *
 * Orchestrates the full dropshipping fulfilment loop:
 *
 *  1. Poll eStore every 60s for new orders
 *  2. Send each new order to Telegram with Place / Skip / Manual buttons
 *  3. When admin taps Place → launch Meesho automation
 *  4. Write Meesho order ID back to eStore order
 *  5. Monitor orders for cancellation / return requests → send Telegram alert
 *  6. When admin approves → run Meesho cancel/return automation
 *  7. Handle session expiry → alert admin, pause queue, resume on confirmation
 *  8. Send daily summary at 9 PM IST
 *
 * Configuration is read from environment variables or from the eStore config
 * via the agent API endpoint (GET /api/v1/agent/config).
 *
 * Run with:
 *   npx tsx agent/index.ts
 * or add to package.json scripts:
 *   "agent": "tsx agent/index.ts"
 */

import { TelegramBot }  from './telegram.js';
import { MeeshoAgent }  from './meesho.js';
import { EstoreClient } from './estoreClient.js';
import { Order }        from '../src/types.js';

// ── Config from environment ────────────────────────────────────────────────

const ESTORE_URL       = process.env.ESTORE_URL       || 'http://localhost:3000';
const AGENT_EMAIL      = process.env.AGENT_EMAIL       || process.env.SUPER_ADMIN_EMAIL || 'super@example.com';
const AGENT_PASSWORD   = process.env.AGENT_PASSWORD    || process.env.SUPER_ADMIN_PASSWORD || '';
const TELEGRAM_TOKEN   = process.env.TELEGRAM_BOT_TOKEN || '';
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID  || '';
const MEESHO_EMAIL     = process.env.MEESHO_EMAIL      || '';
const MEESHO_PASSWORD  = process.env.MEESHO_PASSWORD   || '';
const POLL_INTERVAL_MS = parseInt(process.env.AGENT_POLL_MS || '60000');
const MAX_ATTEMPTS     = parseInt(process.env.AGENT_MAX_ATTEMPTS || '3');
const RETRY_DELAY_MS   = parseInt(process.env.AGENT_RETRY_DELAY_MS || String(15 * 60 * 1000));

// ── Validate required env vars ─────────────────────────────────────────────

function validateConfig() {
  const missing: string[] = [];
  if (!TELEGRAM_TOKEN)   missing.push('TELEGRAM_BOT_TOKEN');
  if (!TELEGRAM_CHAT_ID) missing.push('TELEGRAM_CHAT_ID');
  if (!MEESHO_EMAIL)     missing.push('MEESHO_EMAIL');
  if (!MEESHO_PASSWORD)  missing.push('MEESHO_PASSWORD');
  if (!AGENT_PASSWORD)   missing.push('AGENT_PASSWORD (or SUPER_ADMIN_PASSWORD)');

  if (missing.length > 0) {
    console.error('[Agent] Missing required environment variables:');
    missing.forEach(v => console.error(`  ❌ ${v}`));
    console.error('\nAdd these to your .env file and restart the agent.');
    process.exit(1);
  }
}

// ── Agent state ────────────────────────────────────────────────────────────

/** Orders we have already notified Telegram about — avoid re-sending */
const notifiedOrders = new Set<string>();

/** Orders where cancellation/return has been notified */
const notifiedRequests = new Set<string>();

/** Orders currently being processed — avoid concurrent placement */
const processingOrders = new Set<string>();

/** Whether the Meesho session is currently paused (awaiting admin re-login) */
let sessionPaused = false;

/** Retry timers */
const retryTimers = new Map<string, ReturnType<typeof setTimeout>>();

// ── Initialise services ────────────────────────────────────────────────────

validateConfig();

const telegram = new TelegramBot(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID);
const meesho   = new MeeshoAgent(MEESHO_EMAIL, MEESHO_PASSWORD);
const estore   = new EstoreClient(ESTORE_URL, AGENT_EMAIL, AGENT_PASSWORD);

// ── Meesho session events ──────────────────────────────────────────────────

meesho.on('session_expired', async () => {
  if (sessionPaused) return; // already alerted
  sessionPaused = true;
  console.warn('[Agent] Meesho session expired — alerting admin via Telegram');
  await telegram.sendSessionExpired();
});

meesho.on('otp_required', async () => {
  sessionPaused = true;
  console.warn('[Agent] OTP required — alerting admin via Telegram');
  await telegram.sendSessionExpired();
});

meesho.on('session_resumed', () => {
  sessionPaused = false;
  console.log('[Agent] Session resumed');
  telegram.sendAlert('✅ Meesho session restored. Resuming order fulfilment.').catch(() => {});
});

// ── Telegram callback handler ──────────────────────────────────────────────

telegram.onCallbackQuery(async (cb) => {
  console.log('[Agent] Telegram callback:', cb);

  switch (cb.type) {

    case 'place': {
      await placeOrder(cb.orderId);
      break;
    }

    case 'skip': {
      console.log(`[Agent] Order ${cb.orderId} skipped by admin`);
      await telegram.sendAlert(`⏭ Order ${cb.orderId} skipped. It will not be placed automatically.`);
      break;
    }

    case 'manual': {
      await telegram.sendAlert(
        `✋ Order ${cb.orderId} — Please place it manually on Meesho, then go to Admin Panel → Orders → ${cb.orderId} → enter the Meesho order ID.`
      );
      break;
    }

    case 'retry': {
      const order = await getOrderById(cb.orderId);
      if (order) {
        const attempts = (order.agentAttempts ?? 0);
        if (attempts >= MAX_ATTEMPTS) {
          await telegram.sendAlert(`❌ Order ${cb.orderId} has reached the maximum retry limit (${MAX_ATTEMPTS}). Please place it manually.`);
        } else {
          await placeOrder(cb.orderId);
        }
      }
      break;
    }

    case 'cancel_confirm': {
      await cancelOrder(cb.orderId);
      break;
    }

    case 'cancel_reject': {
      console.log(`[Agent] Cancellation rejected for ${cb.orderId}`);
      await telegram.sendAlert(`❌ Cancellation rejected for order ${cb.orderId}. The order remains active.`);
      break;
    }

    case 'return_confirm': {
      await initiateReturn(cb.orderId);
      break;
    }

    case 'return_reject': {
      console.log(`[Agent] Return rejected for ${cb.orderId}`);
      await telegram.sendAlert(`❌ Return rejected for order ${cb.orderId}.`);
      break;
    }

    case 'session_resume': {
      sessionPaused = false;
      await meesho.resumeAfterManualLogin();
      break;
    }

    case 'summary': {
      const stats = await estore.getTodayStats();
      await telegram.sendSummary(stats);
      break;
    }
  }
});

// ── Core actions ───────────────────────────────────────────────────────────

async function placeOrder(orderId: string) {
  if (processingOrders.has(orderId)) {
    console.log(`[Agent] Order ${orderId} already being processed — skipping`);
    return;
  }
  if (sessionPaused) {
    console.log(`[Agent] Session paused — queuing order ${orderId}`);
    return;
  }

  processingOrders.add(orderId);

  const order = await getOrderById(orderId);
  if (!order) {
    processingOrders.delete(orderId);
    await telegram.sendAlert(`⚠️ Could not find order ${orderId} in eStore.`);
    return;
  }

  const attempts = (order.agentAttempts ?? 0) + 1;
  console.log(`[Agent] Placing order ${orderId} (attempt ${attempts}/${MAX_ATTEMPTS})`);

  await estore.updateAgentFields(orderId, { agentStatus: 'placing', agentAttempts: attempts });

  const result = await meesho.placeOrder(order);
  const msgId  = order.telegramMessageId;

  if (result.success && result.meeshoOrderId) {
    console.log(`[Agent] ✅ Order ${orderId} placed — Meesho ID: ${result.meeshoOrderId}`);
    await estore.markPlaced(orderId, result.meeshoOrderId, result.meeshoOrderUrl, msgId);
    if (msgId) await telegram.editOrderPlaced(msgId, order, result.meeshoOrderId);
    else await telegram.sendAlert(`✅ Order ${orderId} placed on Meesho.\nMeesho Order ID: ${result.meeshoOrderId}`);
  } else {
    console.error(`[Agent] ❌ Order ${orderId} failed: ${result.error}`);
    await estore.markFailed(orderId, result.error ?? 'Unknown error', attempts, msgId);
    if (msgId) await telegram.editOrderFailed(msgId, order, result.error ?? 'Unknown error', attempts, MAX_ATTEMPTS);
    else await telegram.sendAlert(`❌ Failed to place order ${orderId}: ${result.error}`);

    // Schedule retry if attempts remain
    if (attempts < MAX_ATTEMPTS) {
      console.log(`[Agent] Scheduling retry for ${orderId} in ${RETRY_DELAY_MS / 60000} minutes`);
      const timer = setTimeout(() => placeOrder(orderId), RETRY_DELAY_MS);
      retryTimers.set(orderId, timer);
    }
  }

  processingOrders.delete(orderId);
}

async function cancelOrder(orderId: string) {
  const order = await getOrderById(orderId);
  if (!order?.meeshoOrderId) {
    await telegram.sendAlert(`⚠️ Order ${orderId} has no Meesho order ID — cannot cancel automatically. Please cancel manually.`);
    return;
  }

  await estore.updateAgentFields(orderId, { agentStatus: 'cancelling' });
  console.log(`[Agent] Cancelling Meesho order ${order.meeshoOrderId} for eStore order ${orderId}`);

  const result = await meesho.cancelOrder(order.meeshoOrderId);
  if (result.success) {
    await estore.updateAgentFields(orderId, { agentStatus: 'cancelled_on_meesho' });
    await telegram.sendAlert(`✅ Order ${orderId} cancelled on Meesho.`);
  } else {
    await estore.updateAgentFields(orderId, { agentStatus: 'cancel_failed', agentError: result.error });
    await telegram.sendAlert(`❌ Failed to cancel order ${orderId} on Meesho: ${result.error}\nPlease cancel manually.`);
  }
}

async function initiateReturn(orderId: string) {
  const order = await getOrderById(orderId);
  if (!order?.meeshoOrderId) {
    await telegram.sendAlert(`⚠️ Order ${orderId} has no Meesho order ID — cannot initiate return automatically.`);
    return;
  }

  const reason = order.customerRequest?.note ?? 'Customer requested return';
  await estore.updateAgentFields(orderId, { agentStatus: 'returning' });
  console.log(`[Agent] Initiating return for Meesho order ${order.meeshoOrderId}`);

  const result = await meesho.initiateReturn(order.meeshoOrderId, reason);
  if (result.success) {
    await estore.updateAgentFields(orderId, { agentStatus: 'return_initiated' });
    await telegram.sendAlert(`✅ Return initiated on Meesho for order ${orderId}.`);
  } else {
    await estore.updateAgentFields(orderId, { agentStatus: 'return_failed', agentError: result.error });
    await telegram.sendAlert(`❌ Return failed for order ${orderId}: ${result.error}\nPlease initiate manually.`);
  }
}

// ── Poll loop ──────────────────────────────────────────────────────────────

async function pollOrders() {
  try {
    // 1. New orders — notify Telegram
    const pendingOrders = await estore.getPendingOrders();
    for (const order of pendingOrders) {
      if (notifiedOrders.has(order.id)) continue;
      if (order.agentStatus && order.agentStatus !== 'pending_confirmation') continue;

      console.log(`[Agent] New order to notify: ${order.id}`);
      notifiedOrders.add(order.id);

      const msgId = await telegram.sendNewOrderNotification(order);
      if (msgId) {
        await estore.markPendingConfirmation(order.id, msgId);
      }
    }

    // 2. Cancellation / return requests — notify Telegram
    const requestOrders = await estore.getRequestOrders();
    for (const order of requestOrders) {
      const requestKey = `${order.id}-${order.customerRequest?.timestamp ?? 'req'}`;
      if (notifiedRequests.has(requestKey)) continue;
      notifiedRequests.add(requestKey);

      const hasCancelReq = order.items.some(i => i.status === 'Cancellation Requested');
      const hasReturnReq = order.items.some(i => i.status === 'Return Requested');

      if (hasCancelReq) {
        console.log(`[Agent] Cancellation request for order ${order.id}`);
        await telegram.sendCancellationRequest(order);
      } else if (hasReturnReq) {
        console.log(`[Agent] Return request for order ${order.id}`);
        await telegram.sendReturnRequest(order);
      }
    }
  } catch (e: any) {
    console.error('[Agent] Poll error:', e.message);
  }
}

async function getOrderById(orderId: string): Promise<Order | null> {
  const client = estore as any;
  const data = await client.fetch<any>(`/api/v1/orders/${orderId}`);
  return data ?? null;
}

// ── Daily summary at 9 PM IST ──────────────────────────────────────────────

function scheduleDailySummary() {
  const now = new Date();
  const IST_OFFSET = 5.5 * 60 * 60 * 1000;
  const istNow = new Date(now.getTime() + IST_OFFSET);
  const next9PM = new Date(istNow);
  next9PM.setHours(21, 0, 0, 0);
  if (istNow >= next9PM) next9PM.setDate(next9PM.getDate() + 1);
  const msUntil = next9PM.getTime() - istNow.getTime();

  console.log(`[Agent] Daily summary scheduled in ${Math.round(msUntil / 60000)} minutes`);
  setTimeout(async () => {
    const stats = await estore.getTodayStats();
    await telegram.sendSummary(stats);
    scheduleDailySummary(); // reschedule for next day
  }, msUntil);
}

// ── Startup ────────────────────────────────────────────────────────────────

async function main() {
  console.log('[Agent] Starting fulfilment agent...');
  console.log(`[Agent] eStore URL: ${ESTORE_URL}`);

  // 1. Test Telegram connection
  const telegramOk = await telegram.test();
  if (!telegramOk) {
    console.error('[Agent] Telegram connection failed. Check TELEGRAM_BOT_TOKEN.');
    process.exit(1);
  }

  // 2. Authenticate with eStore
  const estoreOk = await estore.login();
  if (!estoreOk) {
    console.error('[Agent] eStore authentication failed. Check AGENT_EMAIL and AGENT_PASSWORD.');
    process.exit(1);
  }

  // 3. Launch Meesho browser
  await meesho.launch();

  // 4. Verify / restore Meesho session
  const sessionOk = await meesho.verifySession();
  if (!sessionOk) {
    console.log('[Agent] No valid Meesho session — will attempt login on first order');
    await meesho.login().catch(() => {});
  } else {
    console.log('[Agent] Meesho session valid');
  }

  // 5. Start Telegram polling
  telegram.startPolling();

  // 6. Start order polling loop
  console.log(`[Agent] Polling eStore every ${POLL_INTERVAL_MS / 1000}s`);
  await telegram.sendAlert('🤖 Fulfilment agent started and ready.');

  await pollOrders();
  setInterval(pollOrders, POLL_INTERVAL_MS);

  // 7. Schedule daily summary
  scheduleDailySummary();

  // Graceful shutdown
  process.on('SIGINT',  shutdown);
  process.on('SIGTERM', shutdown);
}

async function shutdown() {
  console.log('[Agent] Shutting down...');
  telegram.stopPolling();
  await meesho.close();
  process.exit(0);
}

main().catch(e => {
  console.error('[Agent] Fatal error:', e);
  process.exit(1);
});
