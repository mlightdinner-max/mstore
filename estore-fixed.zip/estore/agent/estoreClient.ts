/**
 * estoreClient.ts
 *
 * HTTP client the agent uses to communicate with the main eStore server.
 * All requests are authenticated with the agent's JWT token.
 */

import { Order } from '../src/types.js';

export class EstoreClient {
  private baseUrl: string;
  private token:   string | null = null;
  private email:   string;
  private password: string;

  constructor(baseUrl: string, email: string, password: string) {
    this.baseUrl  = baseUrl.replace(/\/$/, '');
    this.email    = email;
    this.password = password;
  }

  // ── Auth ──────────────────────────────────────────────────────────────────

  async login(): Promise<boolean> {
    try {
      const res  = await fetch(`${this.baseUrl}/api/v1/auth/login`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ email: this.email, password: this.password }),
      });
      const data = await res.json() as any;
      if (data.token) {
        this.token = data.token;
        console.log('[eStore] Agent authenticated');
        return true;
      }
      console.error('[eStore] Login failed:', data.error);
      return false;
    } catch (e: any) {
      console.error('[eStore] Login error:', e.message);
      return false;
    }
  }

  private async fetch<T>(path: string, init: RequestInit = {}): Promise<T | null> {
    if (!this.token) {
      const ok = await this.login();
      if (!ok) return null;
    }

    const res = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        Authorization:  `Bearer ${this.token}`,
        ...init.headers,
      },
    });

    if (res.status === 401) {
      // Token expired — re-login and retry once
      this.token = null;
      const ok = await this.login();
      if (!ok) return null;
      return this.fetch(path, init);
    }

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      console.error(`[eStore] ${path} → ${res.status}: ${text.slice(0, 200)}`);
      return null;
    }

    return res.json() as Promise<T>;
  }

  // ── Orders ────────────────────────────────────────────────────────────────

  /** Fetch all orders that need agent attention */
  async getPendingOrders(): Promise<Order[]> {
    const data = await this.fetch<{ data: Order[] }>('/api/v1/orders?limit=200');
    if (!data) return [];
    return (data.data ?? []).filter(
      (o: Order) =>
        !o.agentStatus ||
        o.agentStatus === 'pending_confirmation' ||
        o.agentStatus === 'failed'
    );
  }

  /** Fetch all orders with cancellation or return requests */
  async getRequestOrders(): Promise<Order[]> {
    const data = await this.fetch<{ data: Order[] }>('/api/v1/orders?limit=200');
    if (!data) return [];
    return (data.data ?? []).filter((o: Order) =>
      o.items.some(i =>
        ['Cancellation Requested', 'Return Requested'].includes(i.status ?? '')
      )
    );
  }

  /** Update agent fields on an order */
  async updateAgentFields(orderId: string, fields: Partial<Order>): Promise<boolean> {
    const result = await this.fetch<any>(`/api/v1/orders/${orderId}/agent`, {
      method: 'PATCH',
      body:   JSON.stringify(fields),
    });
    return !!result;
  }

  /** Mark order as placed — shorthand for updateAgentFields */
  async markPlaced(orderId: string, meeshoOrderId: string, meeshoOrderUrl: string | null, telegramMessageId?: number): Promise<boolean> {
    return this.updateAgentFields(orderId, {
      agentStatus:      'placed',
      meeshoOrderId,
      meeshoOrderUrl:   meeshoOrderUrl ?? undefined,
      telegramMessageId,
      agentError:       undefined,
    });
  }

  async markFailed(orderId: string, error: string, attempts: number, telegramMessageId?: number): Promise<boolean> {
    return this.updateAgentFields(orderId, {
      agentStatus:         'failed',
      agentError:          error,
      agentAttempts:       attempts,
      agentLastAttemptAt:  new Date().toISOString(),
      telegramMessageId,
    });
  }

  async markPendingConfirmation(orderId: string, telegramMessageId: number): Promise<boolean> {
    return this.updateAgentFields(orderId, {
      agentStatus:      'pending_confirmation',
      telegramMessageId,
    });
  }

  async markManuallyPlaced(orderId: string, meeshoOrderId: string): Promise<boolean> {
    return this.updateAgentFields(orderId, {
      agentStatus:    'manually_placed',
      meeshoOrderId,
    });
  }

  /** Get today's stats for the daily summary */
  async getTodayStats(): Promise<{
    placed: number; pending: number; failed: number;
    cancelled: number; returned: number; total: number;
  }> {
    const data = await this.fetch<{ data: Order[] }>('/api/v1/orders?limit=200');
    const orders = data?.data ?? [];
    const today  = new Date().toDateString();
    const todayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === today);
    return {
      total:     todayOrders.length,
      placed:    todayOrders.filter(o => o.agentStatus === 'placed' || o.agentStatus === 'manually_placed').length,
      pending:   todayOrders.filter(o => o.agentStatus === 'pending_confirmation' || !o.agentStatus).length,
      failed:    todayOrders.filter(o => o.agentStatus === 'failed').length,
      cancelled: todayOrders.filter(o => o.agentStatus === 'cancelled_on_meesho').length,
      returned:  todayOrders.filter(o => o.agentStatus === 'return_initiated').length,
    };
  }
}
