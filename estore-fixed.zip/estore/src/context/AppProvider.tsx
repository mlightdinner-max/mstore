import React, { ReactNode } from 'react';
import { AppContext, AppContextType } from './AppContext';

export const AppProvider = ({ children, value }: { children: ReactNode; value: AppContextType }) => {
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
