import { createContext, useContext } from 'react';
import { User, CartItem, Product } from '../types';

export interface AppContextType {
  config: any;
  user: User | null;
  cart: CartItem[];
  token: string | null;
  onAddToCart: (p: Product, selectedVariants?: Record<string, string>) => void;
  onUpdateCart: (id: string, q: number) => void;
  onRemoveFromCart: (id: string) => void;
  onClearCart: () => void;
  onLogin: (u: User, t: string) => void;
  onLogout: () => void;
  onUpdateConfig: (c: any) => void;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
