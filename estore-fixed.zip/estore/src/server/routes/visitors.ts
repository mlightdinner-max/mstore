import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';

export function createVisitorsRouter(
  visitors: Map<string, any>,
  broadcastVisitors: () => void,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  // 1 ping per IP per 30 seconds — normal visitor heartbeats are every 30s anyway
  const pingLimiter = rateLimit({
    windowMs: 30 * 1000,
    max: 1,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests.' },
  });

  // Sanitise a visitor-supplied string: truncate and strip non-printable characters
  const sanitiseField = (val: unknown, maxLen = 200): string => {
    if (typeof val !== 'string') return '';
    return val.replace(/[^\x20-\x7E]/g, '').slice(0, maxLen);
  };

  router.post("/ping", pingLimiter, (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const { currentPage, deviceType, locale, timezone } = req.body;
    const userAgent = req.headers['user-agent'] || 'unknown';

    const existing = visitors.get(ip);
    visitors.set(ip, {
      ip,
      lastSeen: Date.now(),
      sessionStart: existing ? existing.sessionStart : Date.now(),
      currentPage: sanitiseField(currentPage) || '/',
      deviceType: sanitiseField(deviceType) || 'desktop',
      userAgent: sanitiseField(userAgent, 300),
      locale: sanitiseField(locale, 20),
      timezone: sanitiseField(timezone, 60),
    });
    
    broadcastVisitors();
    res.json({ success: true, count: visitors.size });
  });

  router.get("/count", (req, res) => {
    res.json({ count: visitors.size });
  });

  router.get("/list", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    res.json(Array.from(visitors.values()));
  });

  return router;
}
