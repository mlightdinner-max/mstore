import { Router } from 'express';
import crypto from 'crypto';

export function createAlertsRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  ALERTS_FILE: string,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();


  router.get("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { alerts } = getContext();
    const sortedAlerts = [...(alerts || [])].sort((a: any, b: any) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    res.json(sortedAlerts);
  });

  router.post("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { alerts, setAlerts } = getContext();
    const newAlert = { ...req.body, id: req.body.id || crypto.randomUUID(), timestamp: req.body.timestamp || new Date().toISOString() };
    const newAlerts = [...(alerts || []), newAlert];
    setAlerts(newAlerts);
    res.status(201).json(newAlert);
  });

  router.delete("/:id", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { alerts, setAlerts } = getContext();
    const newAlerts = (alerts || []).filter((a: any) => a.id !== req.params.id);
    setAlerts(newAlerts);
    res.status(204).send();
  });

  router.delete("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { setAlerts } = getContext();
    setAlerts([]);
    res.status(204).send();
  });

  return router;
}
