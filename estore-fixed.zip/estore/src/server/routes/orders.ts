import express from 'express';
import { z } from 'zod';
import { OrderService } from '../services/orderService.js';
import { generateOrderId } from '../dataStore.js';
import { verifyCaptchaToken } from '../utils/captcha.js';

// Schema for order creation — validated server-side before any processing
const OrderItemSchema = z.object({
  id: z.string().min(1).max(100),
  quantity: z.number().int().min(1).max(1000),
});

const OrderSchema = z.object({
  customerName: z.string().min(1, 'Name is required').max(120),
  email: z.string().email('Invalid email').max(254),
  // Indian mobile number: 10 digits, first digit 6–9, with optional +91/91/0 prefix
  phone: z.string()
    .transform(v => v.replace(/^(?:\+91|91|0)/, '').replace(/\D/g, ''))
    .refine(v => /^[6-9]\d{9}$/.test(v), { message: 'Please enter a valid 10-digit Indian mobile number.' }),
  address: z.string().min(5, 'Address too short').max(300),
  city: z.string().min(1).max(100),
  state: z.string().min(1).max(100),
  zip: z.string().min(3).max(20),
  items: z.array(OrderItemSchema).min(1, 'At least one item required').max(50, 'Too many items'),
  couponCode: z.string().max(50).optional(),
  affiliateCode: z.string().max(50).optional(),
  // CAPTCHA fields — required but validated separately
  captchaToken: z.string().min(1),
  captchaAnswer: z.string().min(1),
  // Optional AI validation fields
  isAiValidated: z.boolean().optional(),
  isAiFlagged: z.boolean().optional(),
  systemTags: z.array(z.string().max(50)).max(20).optional(),
  couponUsed: z.string().max(50).optional(),
  paymentMethod: z.string().max(50).optional(),
  source: z.string().max(100).optional(),
  affiliateId: z.string().max(100).optional(),
});

// verifyCaptchaToken is imported from '../utils/captcha.js' above

export const createOrdersRouter = async (
  getContext: () => any,
  calculateOrderFinancials: any,
  sendEmailNotification: any,
  sendWhatsAppNotification: any,
  sendWebhookNotification: any,
  updateAffiliateStats: any,
  logAction: any,
  authenticateToken: any,
  checkRole: any,
  ACTUAL_JWT_SECRET: string
) => {
  const router = express.Router();

  router.get('/', authenticateToken, (req: any, res) => {
    const ctx = getContext();
    const { orders } = ctx;
    
    // Auto-transition WAITING TO CLOSE to CLOSED if window expired
    let modified = false;

    const config = ctx.config || {};
    const windowDays = Number(config.returnWindowDays) || 5;
    const windowInMs = windowDays * 24 * 60 * 60 * 1000;

    const updatedOrders = orders.map((order: any) => {
      if (order.status === 'WAITING TO CLOSE' && order.latestDeliveredAt) {
        const lastDelivery = new Date(order.latestDeliveredAt).getTime();
        if (Date.now() - lastDelivery >= windowInMs) {
          modified = true;
          return { ...order, status: 'CLOSED' };
        }
      }
      return order;
    });

    if (modified) {
      ctx.setOrders(updatedOrders);
    }

    // Parse pagination params — default to page 1, 50 per page.
    // Pass ?page=0&limit=0 to get all records (admin exports, etc.)
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? updatedOrders.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const paginate = (arr: any[]) => {
      if (all) return { data: arr, total: arr.length, page: 1, pages: 1 };
      const total = arr.length;
      const pages = Math.ceil(total / pageSize);
      const data = arr.slice((page - 1) * pageSize, page * pageSize);
      return { data, total, page, pages };
    };

    if (req.user.role === 'Affiliate') {
      const affiliateOrders = updatedOrders.filter((o: any) => o.affiliateId === req.user.affiliateId);
      return res.json(paginate(affiliateOrders));
    }
    if (req.user.role === 'Admin' || req.user.role === 'Super Admin' || req.user.role === 'Customer Support') {
      return res.json(paginate(updatedOrders));
    }
    res.status(403).json({ error: "Forbidden" });
  });

  // Stateless rate limiters using express-rate-limit.
  // These survive restarts and work correctly behind a reverse proxy
  // (server.ts sets `trust proxy 1` so req.ip is the real client IP).
  const { rateLimit } = await import('express-rate-limit');
  // Use req.ip directly. express-rate-limit v8 uses req.ip by default when
  // trust proxy is set, and ipKeyGenerator is not a documented v8 export.
  const ipKey = (req: any) => req.ip || req.socket?.remoteAddress || 'unknown';

  const trackLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: ipKey,
    message: { error: 'Too many requests. Please wait a moment.' },
  });

  const orderLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 3,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: ipKey,
    message: { error: 'Too many orders. Please wait a moment.' },
  });

  const publicActionLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: ipKey,
    message: { error: 'Too many requests. Please wait a moment.' },
  });

  router.post('/track', trackLimiter, (req, res) => {
    const ctx = getContext();
    const { orderId, contact, zip, captchaToken, captchaAnswer } = req.body;
    if (!orderId || !contact || !zip)
      return res.status(400).json({ error: 'Order ID, contact, and zip are required.' });

    // Verify CAPTCHA server-side — the client-only check is not sufficient
    if (!captchaToken || !captchaAnswer || !verifyCaptchaToken(captchaToken, captchaAnswer, ACTUAL_JWT_SECRET)) {
      return res.status(400).json({ error: 'Security verification failed. Please refresh and try again.' });
    }

    const order = ctx.orders.find((o: any) =>
      o.id.toLowerCase() === orderId.toLowerCase().trim() &&
      (o.email.toLowerCase() === contact.toLowerCase().trim() || o.phone.trim() === contact.trim()) &&
      o.zip.trim() === zip.trim()
    );
    if (!order) return res.status(404).json({ error: 'Order not found with these credentials.' });
    res.json(order);
  });

  router.post('/action/:id', publicActionLimiter, (req, res) => {
    const ctx = getContext();
    const { action, note } = req.body;

    // Allowlist actions to prevent arbitrary string injection into status history
    const ALLOWED_ACTIONS = ['cancel_request', 'inquiry', 'feedback', 'other'];
    if (!action || !ALLOWED_ACTIONS.includes(action)) {
      return res.status(400).json({ error: `Invalid action. Allowed: ${ALLOWED_ACTIONS.join(', ')}` });
    }
    // Enforce note length to prevent DoS via large payloads
    if (note && (typeof note !== 'string' || note.length > 500)) {
      return res.status(400).json({ error: 'Note must be a string under 500 characters.' });
    }

    const orderIndex = ctx.orders.findIndex((o: any) => o.id === req.params.id);
    if (orderIndex === -1) return res.status(404).json({ error: 'Order not found.' });
    const order = ctx.orders[orderIndex];
    if (order.status === 'CLOSED') return res.status(400).json({ error: 'Cannot perform action on CLOSED order.' });

    const newHistory = {
      status: order.status,
      date: new Date().toISOString(),
      reason: `User requested ${action}: ${note || 'No note'}`,
      updatedBy: 'Customer'
    };

    const updatedOrder = {
      ...order,
      statusHistory: [...(order.statusHistory || []), newHistory],
      customerRequest: { action, note, timestamp: new Date().toISOString() }
    };

    const newOrders = [...ctx.orders];
    newOrders[orderIndex] = updatedOrder;
    ctx.setOrders(newOrders);
    // Return minimal confirmation — do NOT return the full order object to unauthenticated callers
    res.json({ success: true });
  });

  router.post('/', orderLimiter, (req, res) => {
    const ctx = getContext();

    // 0. Schema validation — reject malformed/oversized payloads before any processing
    const parseResult = OrderSchema.safeParse(req.body);
    if (!parseResult.success) {
      const firstError = parseResult.error.errors[0];
      return res.status(400).json({ error: firstError.message || 'Invalid order data.' });
    }
    const orderData = parseResult.data;

    // 1. Verify CAPTCHA server-side
    const { captchaToken, captchaAnswer, ...safeOrderData } = orderData;
    if (!captchaToken || !captchaAnswer || !verifyCaptchaToken(captchaToken, captchaAnswer, ACTUAL_JWT_SECRET)) {
      return res.status(400).json({ error: 'CAPTCHA verification failed. Please refresh the page and try again.' });
    }

    // 3. Stock check FIRST — before any side effects on customers or coupons
    const ip = (req as any).ip || req.headers['x-forwarded-for'] || 'unknown';
    const updatedProducts = [...ctx.products];
    for (const item of safeOrderData.items || []) {
      const productIndex = updatedProducts.findIndex((p: any) => p.id === item.id);
      if (productIndex !== -1) {
        const product = updatedProducts[productIndex];
        if ((product.stock || 0) < item.quantity) {
          return res.status(400).json({ error: `Insufficient stock for ${product.name}` });
        }
        updatedProducts[productIndex] = {
          ...product,
          stock: (product.stock || 0) - item.quantity,
          isOutOfStock: ((product.stock || 0) - item.quantity) <= 0
        };
      }
    }

    // 4. Calculate financials server-side (discountRatio is never trusted from client)
    const financials = OrderService.calculateFinancials(safeOrderData, ctx.products, ctx.config, ctx.users);
    const { enrichedItems, commissionAmount, affiliateId, soldPrice, netMargin, discountRatio, activeTotal } = financials;

    // 5. Validate all products are still active
    const invalidItems = enrichedItems.filter((item: any) => !item.isValid);
    if (invalidItems.length > 0) {
      return res.status(400).json({ error: `Some products are no longer available: ${invalidItems.map((i: any) => i.name).join(', ')}` });
    }

    // 6. Check if order looks fraudulent
    const isDummy = OrderService.detectDummy(safeOrderData);
    if (isDummy) {
      const { alerts, setAlerts } = ctx;
      setAlerts([...(alerts || []), {
        id: `FRAUD-${generateOrderId().split('-')[1]}`,
        type: 'fraud',
        severity: 'high',
        message: `Suspicious COD Checkout: ${safeOrderData.customerName}`,
        timestamp: new Date().toISOString(),
        isRead: false,
        details: { orderData: { ...safeOrderData, items: (safeOrderData.items || []).map((i: any) => i.name) }, ip }
      }]);
    }

    // 7. Build order — safeOrderData already has captchaToken/captchaAnswer stripped
    const newOrder: any = {
      ...safeOrderData,
      items: enrichedItems.map((item: any) => ({
        ...item,
        status: 'Pending',
        statusHistory: [{ status: 'Pending', date: new Date().toISOString(), reason: 'Order placed', updatedBy: 'System' }]
      })),
      id: generateOrderId(),
      status: isDummy ? 'Dummy' : 'OPEN',
      statusHistory: [{ status: isDummy ? 'Dummy' : 'OPEN', date: new Date().toISOString(), reason: 'Order created', updatedBy: 'System' }],
      isDummy,
      createdAt: new Date().toISOString(),
      affiliateId,
      commissionAmount,
      soldPrice,
      total: activeTotal,
      discountRatio,
      discountedPrice: activeTotal,
      affiliatePayout: commissionAmount,
      netMargin,
      isAiValidated: safeOrderData.isAiValidated || false,
      isAiFlagged: (safeOrderData as any).isAiFlagged || false,
      systemTags: safeOrderData.systemTags || []
    };

    // 8. Check if customer is blocked; upsert customer record
    const customer = ctx.customers.find((c: any) =>
      c.email === safeOrderData.email || c.phone === safeOrderData.phone ||
      (c.emails && c.emails.includes(safeOrderData.email)) ||
      (c.phones && c.phones.includes(safeOrderData.phone))
    );
    if (customer && customer.status === 'Blocked') {
      return res.status(403).json({ error: 'Your account has been suspended.' });
    }

    const updatedCustomers = [...ctx.customers];
    const newAddress = { address: safeOrderData.address, city: safeOrderData.city, state: safeOrderData.state, zip: safeOrderData.zip };
    let updatedCustomer: any;

    if (customer) {
      const idx = updatedCustomers.findIndex((c: any) => c.id === customer.id);
      const emails = Array.from(new Set([...(customer.emails || [customer.email]), safeOrderData.email]));
      const phones = Array.from(new Set([...(customer.phones || [customer.phone]), safeOrderData.phone]));
      const existingAddresses = customer.addresses || [{ address: customer.address || '', city: customer.city || '', state: customer.state || '', zip: customer.zip || '' }];
      const addressExists = existingAddresses.some((a: any) => a.address === newAddress.address && a.city === newAddress.city && a.zip === newAddress.zip);
      updatedCustomer = { ...customer, emails, phones, addresses: addressExists ? existingAddresses : [...existingAddresses, newAddress], totalOrders: (customer.totalOrders || 0) + 1, totalSpent: (customer.totalSpent || 0) + activeTotal, lastOrderDate: newOrder.createdAt, name: safeOrderData.customerName, ...newAddress };
      updatedCustomers[idx] = updatedCustomer;
    } else {
      updatedCustomer = { id: `CUST-${generateOrderId().split('-')[1]}`, name: safeOrderData.customerName, email: safeOrderData.email, phone: safeOrderData.phone, emails: [safeOrderData.email], phones: [safeOrderData.phone], addresses: [newAddress], totalOrders: 1, totalSpent: activeTotal, lastOrderDate: newOrder.createdAt, joinedDate: newOrder.createdAt, ...newAddress };
      updatedCustomers.push(updatedCustomer);
    }
    newOrder.customerId = updatedCustomer.id;

    // 9. Increment coupon usage
    if (safeOrderData.couponUsed) {
      const currentConfig = ctx.config;
      const coupons: any[] = currentConfig.coupons || [];
      const couponIndex = coupons.findIndex((c: any) => c.code.toUpperCase() === safeOrderData.couponUsed.toUpperCase());
      if (couponIndex !== -1) {
        const updatedCoupons = [...coupons];
        const coupon = { ...updatedCoupons[couponIndex] };
        coupon.usageCount = (coupon.usageCount || 0) + 1;
        if (coupon.usageLimit > 0 && coupon.usageCount >= coupon.usageLimit) coupon.status = 'inactive';
        updatedCoupons[couponIndex] = coupon;
        ctx.setConfig({ ...currentConfig, coupons: updatedCoupons });
      }
    }

    // 10. Persist everything atomically
    try {
      ctx.setOrders([...ctx.orders, newOrder]);
      ctx.setProducts(updatedProducts);
      ctx.setCustomers(updatedCustomers);
      if (!isDummy) {
        sendEmailNotification(newOrder, 'Pending');
        sendWhatsAppNotification(newOrder, 'Pending');
        sendWebhookNotification(newOrder, 'Pending');
      }
      res.status(201).json(newOrder);
    } catch (error: any) {
      console.error('Order creation failed:', error);
      res.status(500).json({ error: 'Failed to process order', details: error.message });
    }
  });

  router.post('/public-action', publicActionLimiter, (req, res) => {
    const ctx = getContext();
    const { orderId, itemId, action, reason, contact } = req.body;
    if (!orderId || !itemId || !action || !contact)
      return res.status(400).json({ error: 'Missing required fields.' });
    const orderIndex = ctx.orders.findIndex((o: any) =>
      o.id === orderId &&
      (o.email?.toLowerCase() === contact.toLowerCase() || o.phone === contact)
    );
    if (orderIndex === -1) return res.status(403).json({ error: 'Unauthorised.' });
    const order = { ...ctx.orders[orderIndex] };
    const items = [...(order.items || [])];
    const itemIndex = items.findIndex((i: any) => i.id === itemId);
    if (itemIndex === -1) return res.status(404).json({ error: 'Item not found.' });
    const item = items[itemIndex];
    const nowIso = new Date().toISOString();
    if (action === 'cancel') {
      if (item.status !== 'Processing')
        return res.status(400).json({ error: 'Cancellation is only allowed once the item is being processed.' });
      items[itemIndex] = { ...item, status: 'Cancellation Requested', cancellationReason: reason || 'Customer requested', cancellationRequestedAt: nowIso, statusHistory: [...(item.statusHistory || []), { status: 'Cancellation Requested', date: nowIso, reason: reason || 'Customer requested', updatedBy: 'Customer' }] };
    } else if (action === 'return') {
      if (item.status !== 'Delivered')
        return res.status(400).json({ error: 'Returns are only allowed for delivered items.' });
      const returnWindowDays = ctx.config.returnWindowDays || 5;
      const deliveredAt = item.deliveredAt || order.deliveredAt;
      if (!deliveredAt) return res.status(400).json({ error: 'Delivery date not found.' });
      if (Date.now() - new Date(deliveredAt).getTime() > returnWindowDays * 86400000)
        return res.status(400).json({ error: `Return window of ${returnWindowDays} days has expired.` });
      if (order.affiliatePayoutStatus === 'Requested') {
        order.affiliatePayoutStatus = 'On Hold';
        order.affiliatePayoutHoldReason = 'Return requested by customer';
      } else if (order.affiliatePayoutStatus === 'Paid') {
        (order as any).affiliatePayoutClawbackNeeded = true;
      }
      items[itemIndex] = { ...item, status: 'Return Requested', returnReason: reason || 'Customer requested return', returnRequestedAt: nowIso, statusHistory: [...(item.statusHistory || []), { status: 'Return Requested', date: nowIso, reason: reason || 'Customer requested', updatedBy: 'Customer' }] };
    } else {
      return res.status(400).json({ error: 'Invalid action.' });
    }
    const newOrders = [...ctx.orders];
    newOrders[orderIndex] = { ...order, items };
    ctx.setOrders(newOrders);
    ctx.setAlerts([...(ctx.alerts || []), { id: `ALT-${Date.now()}`, type: 'action_required', severity: 'high', message: `${action === 'cancel' ? 'Cancellation' : 'Return'} Requested: Order #${orderId}`, timestamp: new Date().toISOString(), details: { orderId, itemId, reason }, source: 'system' }]);
    res.json({ success: true });
  });

  // GET /orders/:id — fetch a single order by ID (used by agent and admin deep-links)
  router.get('/:id', authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support', 'Affiliate']), (req: any, res: any) => {
    const ctx = getContext();
    const order = ctx.orders.find((o: any) => o.id === req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    // Affiliates can only read their own orders
    if (req.user.role === 'Affiliate' && order.affiliateId !== req.user.affiliateId) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    res.json(order);
  });

    router.patch('/:id', authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support']), (req: any, res: any) => {
    const ctx = getContext();
    const index = ctx.orders.findIndex((o: any) => o.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: "Order not found" });

    const oldOrder = ctx.orders[index];
    const updateData = req.body;
    
    // Process status change with centralized logic
    const { updatedOrder: processedOrder, error } = OrderService.processStatusChange(
      oldOrder, 
      updateData, 
      ctx.config, 
      req.user.role
    );

    if (error) {
      return res.status(403).json({ error });
    }

    const newOrder = { ...processedOrder };

    const blueprints = ctx.config.orderStatuses || [];
    const payoutStatuses = blueprints.filter((b: any) => b.triggersPayout).map((b: any) => b.label);

    // Do NOT recalculate financials here — prices may have changed since the order was placed.
    // The financials (soldPrice, netMargin, commissionAmount, discountRatio) were locked in
    // at order creation time and must remain immutable for accurate reporting.

    // Audit Logging
    logAction(req.user, 'update_order', {
      orderId: oldOrder.id,
      before: {
        status: oldOrder.status,
        itemsStatuses: (oldOrder.items || []).map((i: any) => ({ id: i.id, status: i.status }))
      },
      after: {
        status: newOrder.status,
        itemsStatuses: (newOrder.items || []).map((i: any) => ({ id: i.id, status: i.status })),
        adminNote: updateData.adminNote || 'No note provided',
        effectiveDate: updateData.effectiveDate || 'Current Time'
      }
    });

    // Handle affiliate stats
    const wasPayoutTrigger = payoutStatuses.includes(oldOrder.status);
    const isPayoutTrigger = payoutStatuses.includes(newOrder.status);

    if (!wasPayoutTrigger && isPayoutTrigger) {
      updateAffiliateStats(newOrder.affiliateId, newOrder.total, newOrder.commissionAmount, ctx.users);
      ctx.setUsers([...ctx.users]);
    } else if (wasPayoutTrigger && !isPayoutTrigger) {
      updateAffiliateStats(oldOrder.affiliateId, -oldOrder.total, -(oldOrder.commissionAmount || 0), ctx.users);
      ctx.setUsers([...ctx.users]);
    }

    const updatedOrders = [...ctx.orders];
    updatedOrders[index] = newOrder as any;
    ctx.setOrders(updatedOrders);

    if (oldOrder.status !== newOrder.status && !newOrder.isDummy) {
      const blueprint = blueprints.find((b: any) => b.label === newOrder.status);
      if (blueprint) {
        if (blueprint.triggersEmail) sendEmailNotification(newOrder, newOrder.status);
        if (blueprint.triggersWhatsApp) sendWhatsAppNotification(newOrder, newOrder.status);
        sendWebhookNotification(newOrder, newOrder.status);
      }
    }

    res.json(newOrder);
  });

  return router;
};
