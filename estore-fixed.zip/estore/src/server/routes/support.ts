import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import crypto from 'crypto';

export function createSupportRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  CONFIG_FILE: string,
  authenticateToken: any,
  checkRole: any,
  nodemailer: any,
  logAction: any
) {
  const router = Router();

  // 3 tickets per IP per 10 minutes to prevent ticket queue flooding
  const ticketLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    max: 3,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests. Please wait a moment.' },
  });

  router.get("/tickets", authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support']), (req, res) => {
    const { supportTickets } = getContext();
    const tickets = [...(supportTickets || [])].sort((a: any, b: any) =>
      new Date(b.lastUpdate).getTime() - new Date(a.lastUpdate).getTime()
    );

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? tickets.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const total = tickets.length;
    const pages = all ? 1 : Math.ceil(total / pageSize);
    const data = all ? tickets : tickets.slice((page - 1) * pageSize, page * pageSize);

    res.json({ data, total, page: all ? 1 : page, pages });
  });

  router.post("/tickets", ticketLimiter, (req, res) => {
    const { subject, message, customerName, email } = req.body;
    if (!subject || !message || !customerName || !email) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const { supportTickets, setSupportTickets } = getContext();

    const newTicket = {
      id: `TKT-${crypto.randomUUID().split('-')[0].toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`,
      subject,
      customerName,
      email,
      status: 'New',
      priority: 'Medium',
      createdAt: new Date().toISOString(),
      lastUpdate: new Date().toISOString(),
      metadata: {
        ip: req.ip || req.headers['x-forwarded-for'] || 'Unknown',
        userAgent: req.headers['user-agent'] || 'Unknown'
      },
      messages: [
        {
          id: crypto.randomUUID(),
          sender: 'customer',
          text: message,
          timestamp: new Date().toISOString()
        }
      ]
    };
    
    setSupportTickets([...(supportTickets || []), newTicket]);
    res.status(201).json(newTicket);
  });

  router.patch("/tickets/:id/reply", authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support']), async (req, res) => {
    const { id } = req.params;
    const { message } = req.body;
    const { config, supportTickets, setSupportTickets } = getContext();
    
    const tickets = supportTickets || [];
    const ticketIndex = tickets.findIndex((t: any) => t.id === id);
    if (ticketIndex === -1) return res.status(404).json({ error: "Ticket not found" });

    const ticket = { ...tickets[ticketIndex] };
    const user = (req as any).user;

    const newMessage = {
      id: crypto.randomUUID(),
      sender: 'agent',
      agentName: user.name,
      text: message,
      timestamp: new Date().toISOString()
    };

    ticket.messages = [...ticket.messages, newMessage];
    ticket.status = 'Answered';
    ticket.lastUpdate = new Date().toISOString();

    // Send actual email if SMTP is configured
    const supportEmail = config.integrations?.supportEmail;
    if (supportEmail?.enabled && supportEmail.host && supportEmail.user && supportEmail.pass) {
      try {
        const transporter = nodemailer.createTransport({
          host: supportEmail.host,
          port: supportEmail.port || 587,
          secure: supportEmail.port === 465,
          auth: {
            user: supportEmail.user,
            pass: supportEmail.pass,
          },
        });

        await transporter.sendMail({
          from: supportEmail.from || supportEmail.user,
          to: ticket.email,
          subject: `Re: ${ticket.subject} [${ticket.id}]`,
          text: `Hello ${ticket.customerName},\n\nOur support team has replied to your ticket:\n\n---\n${message}\n---\n\nYou can reply to this email to continue the conversation.`,
          replyTo: supportEmail.from || supportEmail.user
        });
      } catch (error) {
        console.error("Support reply email failed:", error);
      }
    }

    const newTickets = [...tickets];
    newTickets[ticketIndex] = ticket;
    setSupportTickets(newTickets);

    logAction(user, 'SUPPORT_REPLY', `Replied to ticket ${id}`);

    res.json(ticket);
  });

  router.patch("/tickets/:id/status", authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support']), (req: any, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const { supportTickets, setSupportTickets } = getContext();

    const tickets = supportTickets || [];
    const ticketIndex = tickets.findIndex((t: any) => t.id === id);
    if (ticketIndex === -1) return res.status(404).json({ error: "Ticket not found" });

    const newTickets = [...tickets];
    newTickets[ticketIndex] = {
      ...newTickets[ticketIndex],
      status,
      lastUpdate: new Date().toISOString()
    };

    setSupportTickets(newTickets);

    logAction(req.user, 'SUPPORT_STATUS_UPDATE', `Updated ticket ${id} status to ${status}`);
    res.json(newTickets[ticketIndex]);
  });

  router.delete("/tickets/:id", authenticateToken, checkRole(['Admin', 'Super Admin', 'Customer Support']), (req: any, res) => {
    const { id } = req.params;
    const { supportTickets, setSupportTickets } = getContext();

    const tickets = supportTickets || [];
    const newTickets = tickets.filter((t: any) => t.id !== id);

    setSupportTickets(newTickets);

    logAction(req.user, 'SUPPORT_DELETE', `Deleted ticket ${id}`);
    res.status(204).send();
  });

  return router;
}
