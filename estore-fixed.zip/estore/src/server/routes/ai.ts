import { Router } from 'express';
import { GoogleGenAI } from "@google/genai";
import { rateLimit } from 'express-rate-limit';

// AI Health & Circuit Breaker State
const aiHealth = {
  isHealthy: true,
  lastError: null as string | null,
  lastErrorType: null as 'quota' | 'auth' | 'other' | null,
  cooldownUntil: 0,
  isEnabled: true
};

const checkAiAvailability = (config: any, feature?: keyof any) => {
  const aiSettings = config.aiSettings || { enabled: false };
  if (!aiSettings.enabled) return false;
  
  if (feature && !aiSettings[feature]) return false;
  
  // If we are in cooldown but it's passed, reset
  if (!aiHealth.isHealthy && Date.now() >= aiHealth.cooldownUntil) {
    aiHealth.isHealthy = true;
    aiHealth.lastError = null;
    aiHealth.lastErrorType = null;
  }

  if (!aiHealth.isHealthy) return false;
  
  const apiKey = process.env.GEMINI_API_KEY;
  const isPlaceholder = apiKey === 'MY_GEMINI_API_KEY' || !apiKey || apiKey.length < 10;
  return !!apiKey && !isPlaceholder;
};

const handleAiError = (error: any) => {
  console.error("AI API Error:", error);
  
  let status = error?.status || error?.response?.status;
  let message = error?.message?.toLowerCase() || '';

  // If error is a JSON string (sometimes happens with SDK errors)
  if (message.startsWith('{') && message.includes('"error"')) {
    try {
      const parsed = JSON.parse(error.message);
      status = parsed.error?.code || status;
      message = parsed.error?.message?.toLowerCase() || message;
    } catch {
      // ignore
    }
  }

  aiHealth.isHealthy = false;
  
  // 503: Unavailable / Overloaded
  if (status === 503 || message.includes('503') || message.includes('unavailable') || message.includes('high demand') || message.includes('overloaded')) {
    aiHealth.lastError = "AI Model Overloaded (503)";
    aiHealth.lastErrorType = 'other';
    aiHealth.cooldownUntil = Date.now() + 2 * 60 * 1000; // 2 min cooldown for overload
  }
  // 429: Too Many Requests, 403: Quota/Permission
  else if (status === 429 || message.includes('429') || message.includes('quota') || message.includes('limit')) {
    aiHealth.lastError = "API Quota Exceeded";
    aiHealth.lastErrorType = 'quota';
    aiHealth.cooldownUntil = Date.now() + 5 * 60 * 1000; // 5 min cooldown for quota
  } 
  // 401/403: Auth / Invalid Key
  else if (status === 401 || status === 403 || message.includes('api key') || message.includes('invalid') || message.includes('not found')) {
    aiHealth.lastError = "Invalid API Key";
    aiHealth.lastErrorType = 'auth';
    aiHealth.cooldownUntil = Date.now() + 60 * 1000; // 1 min cooldown for auth errors
  }
  else {
    aiHealth.lastError = "Internal AI Error";
    aiHealth.lastErrorType = 'other';
    aiHealth.cooldownUntil = Date.now() + 30 * 1000;
  }
  
  console.warn(`AI entered cooldown mode: ${aiHealth.lastError} until ${new Date(aiHealth.cooldownUntil).toLocaleTimeString()}`);
};

export function createAIRouter(
  getContext: () => any,
  authenticateToken: any
) {
  const router = Router();

  // 5 requests per minute per IP for public (storefront-facing) AI endpoints.
  // This limits Gemini quota drain without affecting normal browsing patterns.
  const publicAiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests. Please wait a moment.' },
  });

  const generateAIContent = async (req: any, prompt: string, config: any, feature?: string, retryCount = 0) => {
    // Check for key in body (POST) or query (GET)
    const apiKey = req.body?.apiKey || req.query?.apiKey || process.env.GEMINI_API_KEY;
    
    if (!apiKey || !checkAiAvailability(config, feature as any)) {
      // If feature is disabled in settings, we should strictly follow that.
      // But if we have an explicit apiKey and it's a test/status check, we allow it.
      if (req.path !== '/status' && req.path !== '/validate-key' && (!config.aiSettings?.enabled || (feature && !config.aiSettings?.[feature]))) {
        return null;
      }
    }

    const isPlaceholder = !apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.length < 10;
    if (isPlaceholder && !req.body?.apiKey && !req.query?.apiKey) return null;

    try {
      const apiKeyString = String(apiKey);
      const ai = new GoogleGenAI({ apiKey: apiKeyString });
      const response = await ai.models.generateContent({
        model: 'gemini-flash-latest',
        contents: prompt
      });
      return response.text;
    } catch (error: any) {
      const status = error?.status || error?.response?.status;
      const message = error?.message?.toLowerCase() || '';
      
      // LOG THE RAW ERROR FOR DEBUGGING:
      console.error("DEBUG - Gemini API Error:", { status, message, error });
      
      // If 503 and we have retries left, wait a bit and retry
      if ((status === 503 || message.includes('503') || message.includes('high demand')) && retryCount < 2) {
        console.warn(`AI 503 detected, retrying (${retryCount + 1}/2)...`);
        await new Promise(resolve => setTimeout(resolve, 2000 * (retryCount + 1))); // Exponential backoff
        return generateAIContent(req, prompt, config, feature, retryCount + 1);
      }

      handleAiError(error);
      return null;
    }
  };

  router.post("/generate-description", authenticateToken, async (req, res) => {
    const { config } = getContext();
    const { name, category, currentDescription } = req.body;

    if (!name) return res.status(400).json({ error: "Product name is required" });

    try {
      const prompt = `Generate a compelling, SEO-friendly e-commerce product description for:
      Name: ${name}
      Category: ${category || 'General'}
      Current Details: ${currentDescription || 'No description provided'}
      
      Return ONLY the description text, no markdown formatting. Max 200 words.`;

      const text = await generateAIContent(req, prompt, config, 'useProductDescriptions');
      if (text === null) {
        return res.json({ text: currentDescription || '', unavailable: true });
      }
      res.json({ text });
    } catch (error: any) {
      res.json({ text: currentDescription || '', error: error.message, unavailable: true });
    }
  });

  router.post("/generate-tags", authenticateToken, async (req, res) => {
    const { config } = getContext();
    const { name, category, description } = req.body;

    if (!name) return res.status(400).json({ error: "Product name is required" });

    try {
      const prompt = `Based on these product details, generate 5-8 relevant, SEO-friendly tags/keywords.
      Name: ${name}
      Category: ${category}
      Description: ${description || 'No description provided'}
      
      Return ONLY a JSON array of strings, nothing else.`;

      const text = await generateAIContent(req, prompt, config, 'useProductDescriptions');
      if (text === null) {
        return res.json({ tags: [], unavailable: true });
      }
      
      const jsonText = text.replace(/```json|```/g, '').trim();
      try {
        const tags = JSON.parse(jsonText);
        res.json({ tags: Array.isArray(tags) ? tags : [] });
      } catch {
        res.json({ tags: [], unavailable: true });
      }
    } catch (error: any) {
      res.json({ tags: [], error: error.message, unavailable: true });
    }
  });

  router.post("/generate-taxonomy", authenticateToken, async (req, res) => {
    const { config, products } = getContext();
    const { type } = req.body; // 'categories' or 'tags'

    try {
      const productNames = (products || []).slice(0, 50).map((p: any) => p.name);
      const prompt = `Based on these products in our store: ${JSON.stringify(productNames)},
      suggest 5 relevant ${type} that we should add to our store taxonomy to improve organization.
      Return ONLY a JSON array of strings.`;

      const text = await generateAIContent(req, prompt, config, 'useRecommendations');
      if (text === null) {
        return res.json({ suggestions: [], unavailable: true });
      }
      
      const jsonText = text.replace(/```json|```/g, '').trim();
      try {
        const suggestions = JSON.parse(jsonText);
        res.json({ suggestions: Array.isArray(suggestions) ? suggestions : [] });
      } catch {
        res.json({ suggestions: [], unavailable: true });
      }
    } catch (error: any) {
      res.json({ suggestions: [], error: error.message, unavailable: true });
    }
  });

  router.post("/validate-checkout", publicAiLimiter, async (req, res) => {
    const { config } = getContext();
    // Support both field name conventions (fullName/customerName, pincode/zip)
    const fullName    = req.body.fullName    || req.body.customerName || '';
    const address     = req.body.address     || '';
    const city        = req.body.city        || '';
    const state       = req.body.state       || '';
    const pincode     = req.body.pincode     || req.body.zip         || '';
    const phone       = req.body.phone       || '';
    const email       = req.body.email       || '';

    try {
      const prompt = `You are a fraud-detection assistant for an Indian e-commerce store that only ships within India and only accepts Cash on Delivery (COD).

Analyze the following order details and return ONLY a valid JSON array of short strings describing specific issues found. Return an empty array [] if everything looks legitimate. Do NOT add any explanation outside the JSON array.

Check for:
- Fake or gibberish name (e.g. "asdfgh", "test user", "abcd efgh")
- Invalid or non-Indian PIN code (must be exactly 6 digits, valid Indian format)
- Non-Indian or obviously fake phone number (must be 10 digits starting with 6, 7, 8, or 9)
- Gibberish or incomplete address (too short, random characters, missing house/flat/street)
- Mismatched city and state for India (e.g. "Mumbai" in "Rajasthan")
- Disposable or clearly fake email addresses
- Any other strong indicators of a fraudulent or test order

Order details:
Name: ${fullName}
Address: ${address}, ${city}, ${state} - ${pincode}
Phone: ${phone}
Email: ${email}`;

      const text = await generateAIContent(req, prompt, config, 'useCheckoutValidation');
      if (text === null) {
        return res.json({ issues: [], unavailable: true });
      }
      const jsonText = text.replace(/```json|```/g, '').trim();
      try {
        const issues = JSON.parse(jsonText);
        res.json({ issues: Array.isArray(issues) ? issues : [] });
      } catch {
        res.json({ issues: [], unavailable: true });
      }
    } catch (error: any) {
      res.json({ issues: [], error: error.message, unavailable: true });
    }
  });

  router.post("/recommendations", publicAiLimiter, async (req, res) => {
    const { config } = getContext();
    const { products, historyNames } = req.body;

    try {
      let prompt = "";
      if (historyNames && historyNames.length > 0) {
        prompt = `Based on the user's browsing history: ${JSON.stringify(historyNames)} 
        and available products: ${JSON.stringify(products.slice(0, 30))}, 
        recommend 3 relevant product names. Return ONLY a JSON array of strings.`;
      } else {
        prompt = `Based on these products: ${JSON.stringify(products.slice(0, 30))}, recommend 3 product names for "Trending". Return ONLY a JSON array of strings.`;
      }

      const text = await generateAIContent(req, prompt, config, 'useRecommendations');
      if (text === null) {
        return res.json({ recommendedNames: [], unavailable: true });
      }
      const jsonText = text.replace(/```json|```/g, '').trim();
      try {
        const recommendedNames = JSON.parse(jsonText);
        res.json({ recommendedNames: Array.isArray(recommendedNames) ? recommendedNames : [] });
      } catch {
        res.json({ recommendedNames: [], unavailable: true });
      }
    } catch (error: any) {
      res.json({ recommendedNames: [], error: error.message, unavailable: true });
    }
  });

  router.post("/generate-blog", authenticateToken, async (req, res) => {
    const { config } = getContext();
    const { title, category } = req.body;

    if (!title) return res.status(400).json({ error: "Title is required" });

    try {
      const prompt = `Write a professional, engaging blog post summary and content for an e-commerce store blog.
      Title: ${title}
      Category: ${category || 'General'}
      
      The content should be at least 300 words. Format it clearly. 
      Return ONLY the blog post content text.`;

      const content = await generateAIContent(req, prompt, config, 'useBlogGeneration');
      if (content === null) {
        return res.json({ content: 'AI generation is currently unavailable. Please try again later.', unavailable: true });
      }
      res.json({ content });
    } catch (error: any) {
      res.json({ content: '', error: error.message, unavailable: true });
    }
  });

  router.post("/validate-key", authenticateToken, async (req, res) => {
    const { apiKey } = req.body;
    
    const keyToUse = apiKey || process.env.GEMINI_API_KEY;
    
    if (!keyToUse || keyToUse === 'MY_GEMINI_API_KEY' || keyToUse.length < 10) {
      return res.status(400).json({ error: "No valid API key provided" });
    }

    try {
      const ai = new GoogleGenAI({ apiKey: keyToUse });
      await ai.models.generateContent({
        model: 'gemini-flash-latest',
        contents: "hi"
      });
      
      // If success, reset health
      aiHealth.isHealthy = true;
      aiHealth.lastError = null;
      aiHealth.lastErrorType = null;
      
      res.json({ success: true, message: "API connection active" });
    } catch (error: any) {
      handleAiError(error);
      res.status(error?.status || 500).json({ 
        success: false, 
        error: aiHealth.lastError,
        type: aiHealth.lastErrorType 
      });
    }
  });

  router.get("/status", authenticateToken, (req, res) => {
    const { config } = getContext();
    const aiSettings = config.aiSettings || { enabled: false };
    
    if (!aiHealth.isHealthy && Date.now() >= aiHealth.cooldownUntil) {
      aiHealth.isHealthy = true;
      aiHealth.lastError = null;
    }

    // Allow checking status for a potential new key without saving it
    const queryKey = req.query.apiKey as string;
    const apiKey = queryKey || process.env.GEMINI_API_KEY;
    const isPlaceholder = apiKey === 'MY_GEMINI_API_KEY' || !apiKey || apiKey.length < 10;
    const hasKey = !!apiKey && !isPlaceholder;
    const isHealthy = aiHealth.isHealthy;
    const masterEnabled = aiSettings.enabled;

    // Feature specific status
    const features = {
      productCopy: masterEnabled && hasKey && isHealthy && !!aiSettings.useProductDescriptions,
      checkoutGuard: masterEnabled && hasKey && isHealthy && !!aiSettings.useCheckoutValidation,
      recommendations: masterEnabled && hasKey && isHealthy && !!aiSettings.useRecommendations,
      blogGen: masterEnabled && hasKey && isHealthy && !!aiSettings.useBlogGeneration
    };

    res.json({
      ...aiHealth,
      isAvailable: masterEnabled && isHealthy && hasKey,
      status: !hasKey ? 'no-key' : (!isHealthy ? aiHealth.lastErrorType : 'healthy'),
      errorMessage: aiHealth.lastError,
      settings: aiSettings,
      features,
      usingConfigKey: !!process.env.GEMINI_API_KEY,
      usingEnvKey: !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY',
      isMisconfigured: masterEnabled && !hasKey,
      isUnsavedKey: false
    });
  });

  return router;
}
