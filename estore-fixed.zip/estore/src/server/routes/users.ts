import express from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

export const createUsersRouter = (
  getContext: () => any, 
  writeData: (file: string, data: any) => void, 
  USERS_FILE: string, 
  logAction: (user: any, action: string, details: any) => void,
  authenticateToken: any,
  checkRole: any
) => {
  const router = express.Router();

  router.get('/', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const { users } = getContext();
    const usersWithoutPasswords = users.map(({ password: _p, ...user }: any) => user);

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? usersWithoutPasswords.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const total = usersWithoutPasswords.length;
    const pages = all ? 1 : Math.ceil(total / pageSize);
    const data = all ? usersWithoutPasswords : usersWithoutPasswords.slice((page - 1) * pageSize, page * pageSize);

    res.json({ data, total, page: all ? 1 : page, pages });
  });

  router.post('/', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const ctx = getContext();

    if (!req.body.password || req.body.password.length < 8) {
      return res.status(400).json({ error: 'Password is required and must be at least 8 characters.' });
    }

    const newUser = {
      ...req.body,
      id: crypto.randomUUID(),
      joined: new Date().toISOString().split('T')[0],
      password: bcrypt.hashSync(req.body.password, 10)
    };

    if (newUser.role === 'Affiliate' && !newUser.affiliateId) {
      newUser.affiliateId = 'AFF-' + crypto.randomUUID().split('-')[0].toUpperCase();
    }

    const updatedUsers = [...ctx.users, newUser];
    ctx.setUsers(updatedUsers);
    logAction(req.user, 'CREATE_USER', { userId: newUser.id, email: newUser.email, role: newUser.role });
    const { password: _p, ...userWithoutPassword } = newUser;
    res.status(201).json(userWithoutPassword);
  });

  router.put('/:id', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const ctx = getContext();
    const index = ctx.users.findIndex((u: any) => u.id === req.params.id);
    if (index !== -1) {
      const updateData = { ...req.body };
      // Don't overwrite password if it's empty in the request
      if (!updateData.password) {
        delete updateData.password;
      } else {
        updateData.password = bcrypt.hashSync(updateData.password, 10);
      }
      const updatedUsers = [...ctx.users];
      updatedUsers[index] = { ...ctx.users[index], ...updateData };
      ctx.setUsers(updatedUsers);
      logAction(req.user, 'UPDATE_USER', { targetUserId: req.params.id, email: updatedUsers[index].email, changes: updateData });
      const { password: _p, ...userWithoutPassword } = updatedUsers[index];
      res.json(userWithoutPassword);
    } else {
      res.status(404).json({ error: "User not found" });
    }
  });

  router.delete('/:id', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const ctx = getContext();
    const index = ctx.users.findIndex((u: any) => u.id === req.params.id);
    if (index !== -1) {
      const updatedUsers = [...ctx.users];
      updatedUsers[index].status = 'deactivated';
      ctx.setUsers(updatedUsers);
      logAction(req.user, 'DEACTIVATE_USER', { targetUserId: req.params.id, email: updatedUsers[index].email });
      res.status(200).json({ success: true });
    } else {
      res.status(404).json({ error: "User not found" });
    }
  });

  return router;
};
