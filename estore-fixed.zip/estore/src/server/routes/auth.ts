import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { signCaptchaToken, verifyCaptchaToken } from '../utils/captcha.js';

export const createAuthRouter = (getUsers: () => any[], ACTUAL_JWT_SECRET: string) => {
  const router = express.Router();

  // Endpoint for the frontend to request a signed CAPTCHA challenge token.
  // The plaintext code is rendered on the client; the signed token is sent back
  // at login so the server can verify without any server-side session storage.
  router.post('/captcha/challenge', (req, res) => {
    const { code } = req.body;
    if (!code || typeof code !== 'string' || code.length < 4) {
      return res.status(400).json({ error: 'Invalid CAPTCHA code' });
    }
    const token = signCaptchaToken(code, ACTUAL_JWT_SECRET);
    res.json({ token });
  });

  // Server-side verification of the admin system-configuration CAPTCHA.
  // Requires a valid JWT (Super Admin only) — prevents anonymous verification attempts.
  router.post('/captcha/admin-verify', (req: any, res) => {
    const authHeader = req.headers['authorization'];
    const jwtToken = authHeader && authHeader.split(' ')[1];
    if (!jwtToken) return res.status(401).json({ error: 'Unauthorized' });

    let decoded: any;
    try {
      decoded = jwt.verify(jwtToken, ACTUAL_JWT_SECRET);
    } catch {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }

    if (decoded.role !== 'Super Admin') {
      return res.status(403).json({ error: 'Forbidden: Super Admin only' });
    }

    const { captchaToken, captchaAnswer } = req.body;
    if (!captchaToken || !captchaAnswer) {
      return res.status(400).json({ error: 'captchaToken and captchaAnswer are required' });
    }

    if (!verifyCaptchaToken(captchaToken, captchaAnswer, ACTUAL_JWT_SECRET)) {
      return res.status(422).json({ error: 'Incorrect or expired CAPTCHA. Please try again.' });
    }

    res.json({ verified: true });
  });

  router.post('/login', (req, res) => {
    const { email, password, captchaToken, captchaAnswer } = req.body;

    if (!captchaToken || !captchaAnswer) {
      return res.status(400).json({ error: "CAPTCHA verification is required" });
    }

    if (!verifyCaptchaToken(captchaToken, captchaAnswer, ACTUAL_JWT_SECRET)) {
      return res.status(400).json({ error: "Incorrect or expired CAPTCHA. Please try again." });
    }

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }

    const users = getUsers();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (user && bcrypt.compareSync(password, user.password)) {
      // Prevent blocked users from logging in
      if (user.isBlocked) {
        return res.status(403).json({ error: 'Your account has been suspended. Please contact the administrator.' });
      }
      const { password: _, ...userWithoutPassword } = user;
      const token = jwt.sign(userWithoutPassword, ACTUAL_JWT_SECRET, { expiresIn: '24h' });
      res.json({ user: userWithoutPassword, token });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  return router;
};
