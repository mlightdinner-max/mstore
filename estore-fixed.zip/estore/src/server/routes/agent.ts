/**
 * agent.ts — Agent API Routes
 *
 * These endpoints are used exclusively by the fulfilment agent process.
 * All routes require authentication (the agent logs in as a Super Admin).
 *
 * PATCH /api/v1/orders/:id/agent  — Update agent-specific fields on an order
 * GET   /api/v1/agent/config      — Read agent-relevant config (credentials masked)
 */

import { Router } from 'express';

export function createAgentRouter(
  getContext: () => any,
  authenticateToken: any,
  checkRole: any,
  logAction: any
) {
  const router = Router();

  /**
   * PATCH /api/v1/orders/:id/agent
   *
   * Updates agent-managed fields on an order: agentStatus, meeshoOrderId,
   * meeshoOrderUrl, agentError, agentAttempts, telegramMessageId.
   *
   * Only agent-specific fields are accepted — all other order fields are
   * ignored to prevent the agent from accidentally overwriting customer data.
   */
  router.patch('/orders/:id/agent', authenticateToken, checkRole(['Super Admin', 'Admin']), (req: any, res: any) => {
    const ctx     = getContext();
    const { id }  = req.params;
    const allowed = [
      'agentStatus', 'meeshoOrderId', 'meeshoOrderUrl',
      'agentError',  'agentAttempts', 'agentLastAttemptAt',
      'telegramMessageId',
    ];

    const updates: Record<string, any> = {};
    for (const key of allowed) {
      if (key in req.body) updates[key] = req.body[key];
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: 'No valid agent fields provided' });
    }

    const orderIndex = ctx.orders.findIndex((o: any) => o.id === id);
    if (orderIndex === -1) return res.status(404).json({ error: 'Order not found' });

    const updatedOrder = {
      ...ctx.orders[orderIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    const newOrders = [...ctx.orders];
    newOrders[orderIndex] = updatedOrder;
    ctx.setOrders(newOrders);

    logAction(req.user, 'AGENT_ORDER_UPDATE', {
      orderId: id,
      updates,
    });

    res.json({ success: true, order: updatedOrder });
  });

  /**
   * GET /api/v1/agent/config
   *
   * Returns agent-relevant configuration with credentials fully masked.
   * The agent reads agentSettings (enabled, autoPlace, maxAttempts, retryDelay)
   * from here so they can be updated from the admin panel without restarting.
   */
  router.get('/agent/config', authenticateToken, checkRole(['Super Admin', 'Admin']), (req: any, res: any) => {
    const ctx    = getContext();
    const config = ctx.config || {};
    res.json({
      agentSettings:   config.agentSettings   ?? { enabled: false, autoPlace: false, maxAttempts: 3, retryDelayMinutes: 15 },
      // Confirm credentials are present without exposing them
      hasTelegramToken:   !!(process.env.TELEGRAM_BOT_TOKEN || config.telegramSettings?.botToken),
      hasTelegramChatId:  !!(process.env.TELEGRAM_CHAT_ID   || config.telegramSettings?.chatId),
      hasMeeshoEmail:     !!(process.env.MEESHO_EMAIL        || config.meeshoSettings?.email),
      hasMeeshoPassword:  !!(process.env.MEESHO_PASSWORD     || config.meeshoSettings?.password),
    });
  });

  return router;
}
