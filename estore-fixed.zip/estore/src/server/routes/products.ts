import express from 'express';
import jwt from 'jsonwebtoken';
import * as fs from 'fs';
import * as path from 'path';
import { randomUUID } from 'crypto';

export const createProductsRouter = (
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  PRODUCTS_FILE: string,
  logAction: (user: any, action: string, details: any) => void,
  authenticateToken: any,
  checkRole: any,
  ACTUAL_JWT_SECRET: string,
  UPLOADS_DIR: string
) => {
  const router = express.Router();

  router.get('/', (req, res) => {
    const { products } = getContext();
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    let userRole = null;
    if (token) {
      try {
        const decoded: any = jwt.verify(token, ACTUAL_JWT_SECRET);
        userRole = decoded.role;
      } catch {
        // ignore invalid token — treat as anonymous
      }
    }

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? products.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const paginate = (arr: any[]) => {
      if (all) return { data: arr, total: arr.length, page: 1, pages: 1 };
      const total = arr.length;
      const pages = Math.ceil(total / pageSize);
      const data = arr.slice((page - 1) * pageSize, page * pageSize);
      return { data, total, page, pages };
    };

    if (userRole === 'Admin' || userRole === 'Super Admin') {
      return res.json(paginate(products));
    }

    // Strip sensitive internal fields and only show active/approved products to customers
    const sanitizedProducts = products
      .filter((p: any) => p.status !== 'deactivated')
      .map(({ originalCost: _oc, sourceUrl: _su, profitPrice: _pp, ...p }: any) => p);

    res.json(paginate(sanitizedProducts));
  });

  router.post('/', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    try {
      const ctx = getContext();

      if (!req.body?.name) {
        return res.status(400).json({ error: 'Product name is required' });
      }

      const folderName = req.body.name.toLowerCase().replace(/[^a-z0-9]/g, '-') || `product-${randomUUID().split('-')[0]}`;
      const folder = req.body.folder || `products/${folderName}`;
      const stock = Math.max(0, Number(req.body.stock) || 0);
      const price = Math.max(0, Number(req.body.price) || 0);

      const newProduct = {
        ...req.body,
        id: randomUUID(),
        stock,
        price,
        isOutOfStock: stock <= 0,
        status: req.body.status || 'active',
        folder,
        createdAt: new Date().toISOString()
      };

      const currentProducts = ctx.products || [];
      ctx.setProducts([...currentProducts, newProduct]);

      try {
        const targetDir = path.join(UPLOADS_DIR, 'products', folderName);
        if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
      } catch {
        // Non-fatal — product is saved; folder creation is best-effort
      }

      logAction(req.user, 'CREATE_PRODUCT', { productId: newProduct.id, name: newProduct.name });
      res.status(201).json(newProduct);
    } catch (error: any) {
      console.error('Product creation error:', error.message);
      res.status(500).json({ error: 'Failed to create product' });
    }
  });

  router.put('/:id', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const ctx = getContext();
    const index = ctx.products.findIndex((p: any) => p.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Product not found' });

    const existingProduct = ctx.products[index];
    const stock = Math.max(0, Number(req.body.stock) || 0);
    const price = Math.max(0, Number(req.body.price) || 0);

    const priceHistory = [...(existingProduct.priceHistory || [])];
    if (price !== existingProduct.price) {
      priceHistory.push({
        previousPrice: existingProduct.price,
        updatedPrice: price,
        timestamp: new Date().toISOString()
      });
    }

    const updatedProducts = [...ctx.products];
    updatedProducts[index] = {
      ...req.body,
      id: req.params.id,
      stock,
      price,
      isOutOfStock: stock <= 0,
      priceHistory
    };
    ctx.setProducts(updatedProducts);
    logAction(req.user, 'UPDATE_PRODUCT', { productId: req.params.id, name: updatedProducts[index].name });
    res.json(updatedProducts[index]);
  });

  router.delete('/:id', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const ctx = getContext();
    const index = ctx.products.findIndex((p: any) => p.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Product not found' });

    const updatedProducts = [...ctx.products];
    const product = updatedProducts[index];
    const newStatus = product.status === 'deactivated' ? 'active' : 'deactivated';
    updatedProducts[index] = { ...product, status: newStatus };
    ctx.setProducts(updatedProducts);
    logAction(req.user, newStatus === 'deactivated' ? 'DEACTIVATE_PRODUCT' : 'RESTORE_PRODUCT', { productId: req.params.id, name: product.name });
    res.status(200).json({ success: true, status: newStatus });
  });

  return router;
};
