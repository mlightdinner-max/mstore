import * as fs from 'fs';
import * as crypto from 'crypto';

/**
 * DataStore<T>  ── SUPERSEDED BY SQLiteStore
 *
 * This class is kept for reference and as a fallback. The application now
 * uses SQLiteStore (sqliteStore.ts) for all persistence.
 *
 * If you need to roll back to JSON file storage (e.g. for local development
 * without better-sqlite3 installed), swap SQLiteStore for DataStore in db.ts.
 * The public interface (.get(), .set(), .update()) is identical.
 *
 * Original capabilities for reference:
 *  - In-memory read cache  — disk is never touched after initial load
 *  - Serialised write queue — concurrent mutations are queued, never interleaved
 *  - Atomic writes         — write to .tmp then fs.rename, crash-safe
 *  - Immutable snapshots   — get() returns a deep clone
 */
export class DataStore<T> {
  private readonly filePath: string;
  private readonly initialData: T;
  private cache: T;
  private writeQueue: Promise<void> = Promise.resolve();

  constructor(filePath: string, initialData: T) {
    this.filePath = filePath;
    this.initialData = initialData;
    this.cache = this.load();
  }

  // ── private ────────────────────────────────────────────────────────────────

  private load(): T {
    if (!fs.existsSync(this.filePath)) {
      this.saveAtomic(this.initialData);
      return this.clone(this.initialData);
    }
    try {
      const content = fs.readFileSync(this.filePath, 'utf-8').trim();
      if (!content) {
        this.saveAtomic(this.initialData);
        return this.clone(this.initialData);
      }
      return JSON.parse(content) as T;
    } catch (err) {
      console.error(`DataStore: failed to load ${this.filePath} — using initial data:`, err);
      return this.clone(this.initialData);
    }
  }

  private clone(data: T): T {
    return JSON.parse(JSON.stringify(data));
  }

  private saveAtomic(data: T): void {
    const tmp = `${this.filePath}.tmp`;
    try {
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tmp, this.filePath);
    } catch (err) {
      console.error(`DataStore: atomic write failed for ${this.filePath}:`, err);
      try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch { /* ignore */ }
      throw err;
    }
  }

  // ── public ─────────────────────────────────────────────────────────────────

  /**
   * Returns a deep clone of the current cache so callers are completely
   * isolated from internal state. One clone per read — no double-cloning.
   */
  public get(): T {
    return this.clone(this.cache);
  }

  /**
   * Replaces the cache and enqueues a disk write.
   * Writes are serialised through a promise chain, so two concurrent calls
   * always produce a consistent final state on disk.
   */
  public set(data: T): void {
    this.cache = data;
    this.writeQueue = this.writeQueue.then(() => {
      try {
        this.saveAtomic(this.cache);
      } catch (err) {
        console.error(`DataStore: queued write failed for ${this.filePath}:`, err);
      }
    });
  }

  /** Fetch → transform → save in one call. */
  public update(updater: (current: T) => T): void {
    this.set(updater(this.cache));
  }
}

// ── ID helpers ───────────────────────────────────────────────────────────────

export const generateId = (): string =>
  `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

export const generateOrderId = (): string =>
  `ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
