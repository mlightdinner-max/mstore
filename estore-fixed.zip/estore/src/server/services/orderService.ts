import { Order, Product, Config, User } from '../../types.js';

export interface OrderFinancials {
  enrichedItems: any[];
  commissionAmount: number;
  affiliateId: string | null;
  soldPrice: number;
  netMargin: number;
  discountRatio: number;
  activeTotal: number;
}

export class OrderService {
  /**
   * Logic previously scattered in server.ts and orders.ts
   */
  static calculateFinancials(
    orderData: Partial<Order>, 
    products: Product[], 
    config: Config, 
    users: User[]
  ): OrderFinancials {
    let commissionAmount = 0;
    let affiliateId = orderData.affiliateId || null;

    // 1. Enrich items with costs at point of purchase and validate existence
    const enrichedItems = (orderData.items || []).map((item: any) => {
      const product = products.find(p => p.id === item.id);
      return {
        ...item,
        originalCostAtPurchase: product?.originalCost || 0,
        price: product?.price ?? item.price,
        priceAtPurchase: product?.price ?? item.price,
        sourceUrl: product?.sourceUrl || '',
        status: item.status || 'Pending',
        isValid: !!product && !product.isDeleted && product.status !== 'deactivated'
      };
    });

    // 2. Filter active items (not cancelled/returned)
    const activeItems = enrichedItems.filter(item => !['Cancelled', 'Returned'].includes(item.status));
    
    const fullSoldPrice = enrichedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const activeSoldPrice = activeItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // 3. Re-validate the coupon server-side and compute the discount entirely on
    //    the server — the client-supplied 'total' is NEVER used for pricing.
    let discountAmount = 0;
    const couponCode = (orderData as any).couponUsed;
    if (couponCode) {
      const coupons: any[] = (config as any).coupons || [];
      const coupon = coupons.find((c: any) =>
        c.code.toUpperCase() === couponCode.toUpperCase()
      );

      const isValid =
        coupon &&
        coupon.status?.toLowerCase() === 'active' &&
        !(coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) &&
        !(coupon.usageLimit > 0 && (coupon.usageCount || 0) >= coupon.usageLimit) &&
        (fullSoldPrice >= (coupon.minOrder || 0));

      if (isValid) {
        if (coupon.type === 'percentage') {
          discountAmount = (activeSoldPrice * Math.min(100, Math.max(0, coupon.value))) / 100;
        } else {
          discountAmount = Math.min(coupon.value, activeSoldPrice);
        }
      }
    }

    // discountRatio: proportion of the item price that remains after the coupon discount.
    // Used to prorate affiliate commission so it's calculated on the discounted price.
    // e.g. 20% coupon → discountRatio = 0.80 → commission is on 80% of the item price.
    const discountRatio = activeSoldPrice > 0
      ? Math.min(1, Math.max(0, (activeSoldPrice - discountAmount) / activeSoldPrice))
      : 1;

    const activeItemsTotalWithoutShipping = activeSoldPrice - discountAmount;
    const shipping = orderData.shipping || 0;
    const activeTotal = Math.max(0, activeItemsTotalWithoutShipping) + shipping;

    // 4. Affiliate Commission Calculation
    if (affiliateId) {
      const affiliate = users.find(u => u.role === 'Affiliate' && u.affiliateId === affiliateId);
      if (affiliate) {
        const settings = config.affiliateSettings || { defaultCommissionRate: 10, allowNonAssignedCommissions: true, nonAssignedCommissionRate: 5 };
        const rate = affiliate.commissionRate || settings.defaultCommissionRate;
        const nonAssignedRate = settings.nonAssignedCommissionRate || 5;
        const assignedProducts = affiliate.assignedProducts || [];

        activeItems.forEach((item: any) => {
          const isAssigned = assignedProducts.includes(item.id);
          const itemTotal = item.price * item.quantity * discountRatio;
          if (isAssigned) {
            commissionAmount += (itemTotal * rate) / 100;
          } else if (settings.allowNonAssignedCommissions) {
            commissionAmount += (itemTotal * nonAssignedRate) / 100;
          }
        });
      } else {
        affiliateId = null;
      }
    }

    const totalProductCost = activeItems.reduce((sum, item) => sum + (item.originalCostAtPurchase * item.quantity), 0);
    // netMargin = total revenue collected (items + shipping) minus product cost and commission
    // Shipping is part of the revenue the store receives from the customer
    const netMargin = activeTotal - totalProductCost - commissionAmount;

    return {
      enrichedItems,
      commissionAmount,
      affiliateId,
      soldPrice: activeSoldPrice,
      netMargin,
      discountRatio,
      activeTotal
    };
  }

  /**
   * Validates if an order contains "dummy" keywords
   */
  static detectDummy(orderData: any): boolean {
    const dummyKeywords = ['test', 'dummy', 'fake', 'sample'];
    const fieldsToSearch = [
      orderData.customerName,
      orderData.fullName,
      orderData.email,
      orderData.address,
      orderData.phone
    ];
    
    return fieldsToSearch.some(field => 
      field && typeof field === 'string' && dummyKeywords.some(k => field.toLowerCase().includes(k))
    );
  }

  /**
   * Manages transition logic for order status and returns
   */
  static processStatusChange(
    oldOrder: Order, 
    updateData: any, 
    config: Config,
    userRole: string
  ): { updatedOrder: Partial<Order>; error?: string } {
    const terminalStatuses = (config.orderStatuses || [])
      .filter(b => b.isTerminal)
      .map(b => b.label);

    const updatedOrder: any = { ...oldOrder, ...updateData };
    const isSuperAdmin = userRole === 'Super Admin';

    // 1. Permission Check for Terminal Products
    if (updateData.items) {
      for (const updatedItem of updateData.items) {
        const oldItem = oldOrder.items?.find(i => i.id === updatedItem.id);
        if (oldItem && terminalStatuses.includes(oldItem.status || '')) {
          if (updatedItem.status !== oldItem.status) {
            if (!isSuperAdmin) {
              return { updatedOrder: oldOrder, error: `Item ${oldItem.name} is in a terminal state (${oldItem.status}) and its status cannot be modified.` };
            }
            if (!updateData.adminNote) {
              return { updatedOrder: oldOrder, error: `A mandatory admin note is required to change terminal status for ${oldItem.name}.` };
            }
          }
        }
      }
    }

    // 2. Permission Check for CLOSED Order
    const canModifyClosed = userRole === 'Super Admin' || userRole === 'Admin';
    if (oldOrder.status === 'CLOSED' && !canModifyClosed) {
      return { updatedOrder: oldOrder, error: "This order is CLOSED and cannot be modified." };
    }
    if (oldOrder.status === 'CLOSED' && canModifyClosed && !updateData.adminNote) {
      return { updatedOrder: oldOrder, error: "A mandatory admin note is required to modify a CLOSED order." };
    }

    // 3. Handle Timestamps for Items
    if (updatedOrder.items) {
      updatedOrder.items = updatedOrder.items.map((item: any) => {
        const oldItem = oldOrder.items?.find(i => i.id === item.id);
        const effectiveDate = updateData.effectiveDate || new Date().toISOString();

        // If status changed and history entry doesn't exist for this change, we could add it here
        // but the frontend is already doing it. Let's just ensure we don't overwrite
        // specific timestamps if they are already set in the item (e.g. from frontend)
        
        if (item.status === 'Delivered' && oldItem?.status !== 'Delivered') {
          item.deliveredAt = item.deliveredAt || effectiveDate;
        } else if (item.status === 'Cancelled' && oldItem?.status !== 'Cancelled') {
          item.cancelledAt = item.cancelledAt || effectiveDate;
        } else if (item.status === 'Returned' && oldItem?.status !== 'Returned') {
          item.returnedAt = item.returnedAt || effectiveDate;
        }
        
        // Ensure statusHistory is preserved
        if (!item.statusHistory && oldItem?.statusHistory) {
          item.statusHistory = oldItem.statusHistory;
        }

        return item;
      });
    }

    // 4. Calculate Order-Level State
    const items = updatedOrder.items || [];
    const isAll = (status: string) => items.every((i: any) => i.status === status);
    const hasAny = (status: string) => items.some((i: any) => i.status === status);
    
    const allTerminal = items.every((item: any) => terminalStatuses.includes(item.status || ''));
    
    if (items.length === 0) {
      updatedOrder.status = 'OPEN';
    } else if (allTerminal) {
      // All items are terminal (Delivered, Cancelled, Returned)
      const deliveredItems = items.filter((item: any) => item.status === 'Delivered');
      
      if (deliveredItems.length > 0) {
        updatedOrder.status = 'WAITING TO CLOSE';
        // Latest delivery date for the window calculation
        const latestDelivery = Math.max(...deliveredItems.map((i: any) => new Date(i.deliveredAt || 0).getTime()));
        updatedOrder.latestDeliveredAt = new Date(latestDelivery).toISOString();
        
        // Check if config window days have passed
        const windowDays = Number(config.returnWindowDays) || 5;
        const windowInMs = windowDays * 24 * 60 * 60 * 1000;
        if (Date.now() - latestDelivery >= windowInMs) {
          updatedOrder.status = 'CLOSED';
        }
      } else {
        // All Cancelled or Returned
        updatedOrder.status = 'CLOSED';
      }
    } else {
      // Not all terminal, identify the "most advanced" common state
      if (hasAny('Shipped')) {
        const wasNotShipped = oldOrder.status !== 'Shipped';
        updatedOrder.status = 'Shipped';
        if (wasNotShipped && !updatedOrder.eta) {
          // ETA: +5 days from now
          const etaDate = new Date();
          etaDate.setDate(etaDate.getDate() + 5);
          updatedOrder.eta = etaDate.toISOString();
        }
      } else if (hasAny('Processing')) {
        updatedOrder.status = 'Processing';
      } else if (isAll('Cancelled')) {
        updatedOrder.status = 'CLOSED';
      } else {
        updatedOrder.status = 'OPEN';
      }
    }

    return { updatedOrder };
  }
}
