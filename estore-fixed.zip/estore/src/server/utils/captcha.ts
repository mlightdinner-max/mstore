import crypto from 'crypto';

const CAPTCHA_EXPIRY_MS = 5 * 60 * 1000; // 5 minutes

// One-time-use token cache: once a token is consumed it cannot be replayed.
// Entries are pruned automatically when their expiry passes so the set stays small.
const usedTokens = new Map<string, number>(); // token-sig → expiry timestamp

function pruneExpiredTokens() {
  const now = Date.now();
  for (const [key, exp] of usedTokens) {
    if (now > exp) usedTokens.delete(key);
  }
}

export function signCaptchaToken(code: string, secret: string): string {
  const payload = Buffer.from(
    JSON.stringify({ code: code.toUpperCase(), exp: Date.now() + CAPTCHA_EXPIRY_MS })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function verifyCaptchaToken(token: string, answer: string, secret: string): boolean {
  try {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return false;
    const expectedSig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) return false;
    const { code, exp } = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (Date.now() > exp) return false;
    if (answer.toUpperCase() !== code) return false;

    // Reject replayed tokens
    pruneExpiredTokens();
    if (usedTokens.has(sig)) return false;
    usedTokens.set(sig, exp);

    return true;
  } catch {
    return false;
  }
}
