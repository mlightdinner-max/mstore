/**
 * sqliteStore.ts
 *
 * Drop-in replacement for DataStore<T> backed by SQLite (better-sqlite3).
 *
 * Public interface is identical to DataStore:
 *   store.get()              → returns deep clone of current value
 *   store.set(data)          → persists new value synchronously
 *   store.update(fn)         → fetch → transform → set in one call
 *
 * Why better-sqlite3 (synchronous) instead of an async driver:
 *   - All existing route handlers call .get() and .set() synchronously.
 *     Switching to async would require rewriting every route.
 *   - better-sqlite3 is actually faster than async drivers for short
 *     read/write operations because it avoids event-loop round-trips.
 *   - SQLite with WAL mode handles concurrent reads perfectly and
 *     serialises writes automatically — no promise queue needed.
 *
 * Schema:
 *   One table: kv_store (key TEXT PRIMARY KEY, value TEXT NOT NULL)
 *   Each DataStore instance is one row keyed by `storeName`.
 *   The value column stores the JSON-serialised array/object.
 *
 *   This is intentionally simple. A single SQLite file holds all stores.
 *   Future migration to per-table schema is possible without changing
 *   the public interface.
 *
 * Concurrency:
 *   WAL (Write-Ahead Logging) mode is enabled so reads never block writes
 *   and writes never block reads. Multiple readers are safe. Single writer.
 *
 * Safety:
 *   - PRAGMA journal_mode=WAL     → crash-safe, concurrent reads
 *   - PRAGMA synchronous=NORMAL   → fsync on WAL checkpoints (safe + fast)
 *   - PRAGMA foreign_keys=ON      → referential integrity
 *   - PRAGMA busy_timeout=5000    → wait 5s instead of throwing SQLITE_BUSY
 */

import Database from 'better-sqlite3';
import * as path from 'path';
import * as fs from 'fs';

// Singleton database connection — shared across all SQLiteStore instances
let _db: Database.Database | null = null;

export function getDatabase(dbPath: string): Database.Database {
  if (_db) return _db;

  // Ensure the directory exists
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  _db = new Database(dbPath);

  // Performance and safety pragmas — set once on first connection
  _db.pragma('journal_mode = WAL');
  _db.pragma('synchronous = NORMAL');
  _db.pragma('foreign_keys = ON');
  _db.pragma('busy_timeout = 5000');
  _db.pragma('cache_size = -8000'); // 8MB page cache

  // Create the key-value table if it doesn't exist
  _db.exec(`
    CREATE TABLE IF NOT EXISTS kv_store (
      key   TEXT    PRIMARY KEY,
      value TEXT    NOT NULL DEFAULT '[]',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  console.log(`[SQLite] Connected: ${dbPath}`);
  return _db;
}

// ── SQLiteStore ───────────────────────────────────────────────────────────────

export class SQLiteStore<T> {
  private readonly key: string;
  private readonly db: Database.Database;
  private readonly initialData: T;
  private cache: T;

  // Prepared statements — compiled once, reused on every call (fast)
  private readonly stmtGet:    Database.Statement;
  private readonly stmtSet:    Database.Statement;

  constructor(dbPath: string, key: string, initialData: T) {
    this.key         = key;
    this.initialData = initialData;
    this.db          = getDatabase(dbPath);

    this.stmtGet = this.db.prepare(
      'SELECT value FROM kv_store WHERE key = ?'
    );
    this.stmtSet = this.db.prepare(`
      INSERT INTO kv_store (key, value, updated_at)
      VALUES (?, ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET
        value      = excluded.value,
        updated_at = excluded.updated_at
    `);

    // Seed with initial data if this key has never been written
    const existing = this.stmtGet.get(this.key) as { value: string } | undefined;
    if (!existing) {
      this.stmtSet.run(this.key, JSON.stringify(this.initialData));
      this.cache = this.clone(this.initialData);
    } else {
      try {
        this.cache = JSON.parse(existing.value) as T;
      } catch {
        console.error(`[SQLite] Failed to parse value for key "${this.key}" — using initial data`);
        this.cache = this.clone(this.initialData);
        this.stmtSet.run(this.key, JSON.stringify(this.initialData));
      }
    }
  }

  private clone(data: T): T {
    return JSON.parse(JSON.stringify(data));
  }

  /**
   * Returns a deep clone of the cached value.
   * Reads are served from the in-memory cache — zero SQLite I/O per read.
   */
  public get(): T {
    return this.clone(this.cache);
  }

  /**
   * Persists new value synchronously to SQLite and updates the in-memory cache.
   * better-sqlite3 writes are synchronous — no async/await needed.
   */
  public set(data: T): void {
    this.cache = data;
    try {
      this.stmtSet.run(this.key, JSON.stringify(data));
    } catch (err) {
      console.error(`[SQLite] Write failed for key "${this.key}":`, err);
      throw err;
    }
  }

  /**
   * Fetch → transform → save in one call.
   * Identical to DataStore.update().
   */
  public update(updater: (current: T) => T): void {
    this.set(updater(this.cache));
  }
}
