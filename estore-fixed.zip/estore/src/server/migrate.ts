/**
 * migrate.ts
 *
 * One-time migration from JSON file storage to SQLite.
 *
 * Run this ONCE on an existing deployment that already has data in JSON files:
 *   npm run db:migrate
 *
 * What it does:
 *   1. Reads every JSON data file from the data directory
 *   2. Opens (or creates) the SQLite database
 *   3. Inserts each store's data as a row in kv_store
 *   4. Verifies the migrated data matches the original
 *   5. Prints a summary
 *
 * Safe to run multiple times — uses INSERT OR REPLACE so re-running
 * will overwrite with the latest JSON file content rather than duplicating.
 *
 * After running:
 *   - The JSON files are kept as a backup (not deleted automatically)
 *   - The app now reads/writes SQLite on every restart
 *   - You can delete the .json files once you have confirmed the app works
 */

import * as path from 'path';
import * as fs from 'fs';
import Database from 'better-sqlite3';

// Resolve the data directory the same way db.ts does
const DATA_DIR = process.env.PERSISTENT_DATA_PATH
  ? path.resolve(process.env.PERSISTENT_DATA_PATH)
  : path.join(process.cwd(), 'data');

const DB_PATH = path.join(DATA_DIR, 'store.db');

// Map of SQLite key → JSON filename (must match db.ts exactly)
const STORES: Record<string, string> = {
  products:         'products.json',
  users:            'users.json',
  orders:           'orders.json',
  config:           'config.json',
  alerts:           'alerts.json',
  notificationLogs: 'notifications_log.json',
  auditLogs:        'audit_logs.json',
  systemLogs:       'system_logs.json',
  affiliatePayouts: 'affiliate_payouts.json',
  customers:        'customers.json',
  affiliateGroups:  'affiliate_groups.json',
  supportTickets:   'support_tickets.json',
  subscribers:      'subscribers.json',
};

// Default values for stores that might not have a JSON file yet
const DEFAULTS: Record<string, any> = {
  products:         [],
  users:            [],
  orders:           [],
  config:           {},
  alerts:           [],
  notificationLogs: [],
  auditLogs:        [],
  systemLogs:       [],
  affiliatePayouts: [],
  customers:        [],
  affiliateGroups:  [],
  supportTickets:   [],
  subscribers:      [],
};

async function migrate() {
  console.log('\n┌─────────────────────────────────────────────┐');
  console.log('│     eStore: JSON → SQLite Migration         │');
  console.log('└─────────────────────────────────────────────┘\n');

  console.log(`Data directory : ${DATA_DIR}`);
  console.log(`SQLite database: ${DB_PATH}\n`);

  // Ensure data directory exists
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    console.log(`Created data directory: ${DATA_DIR}`);
  }

  // Open/create the SQLite database
  const db = new Database(DB_PATH);

  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');

  // Create the kv_store table
  db.exec(`
    CREATE TABLE IF NOT EXISTS kv_store (
      key        TEXT PRIMARY KEY,
      value      TEXT NOT NULL DEFAULT '[]',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const stmt = db.prepare(`
    INSERT INTO kv_store (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET
      value      = excluded.value,
      updated_at = excluded.updated_at
  `);

  const results: { key: string; source: string; records: number; status: string }[] = [];

  // Wrap all inserts in a transaction for speed and atomicity
  const migrateAll = db.transaction(() => {
    for (const [key, filename] of Object.entries(STORES)) {
      const jsonPath = path.join(DATA_DIR, filename);
      let data: any;
      let source: string;

      if (fs.existsSync(jsonPath)) {
        try {
          const raw = fs.readFileSync(jsonPath, 'utf-8').trim();
          data   = raw ? JSON.parse(raw) : DEFAULTS[key];
          source = jsonPath;
        } catch (err: any) {
          console.warn(`  ⚠️  Failed to parse ${filename}: ${err.message} — using default`);
          data   = DEFAULTS[key];
          source = 'default (parse error)';
        }
      } else {
        data   = DEFAULTS[key];
        source = 'default (file not found)';
      }

      stmt.run(key, JSON.stringify(data));

      const count = Array.isArray(data) ? data.length
        : (typeof data === 'object' && data !== null) ? Object.keys(data).length
        : 1;

      results.push({ key, source, records: count, status: '✅' });
    }
  });

  migrateAll();
  db.close();

  // Print results table
  console.log('Migration results:\n');
  console.log('  Key                  Records  Status  Source');
  console.log('  ─────────────────────────────────────────────────────────────');
  for (const r of results) {
    const key     = r.key.padEnd(20);
    const records = String(r.records).padStart(7);
    const src     = path.basename(r.source);
    console.log(`  ${key} ${records}  ${r.status}      ${src}`);
  }

  // Verify — re-open and read back each key
  console.log('\nVerifying…');
  const db2    = new Database(DB_PATH);
  const verify = db2.prepare('SELECT value FROM kv_store WHERE key = ?');
  let   allOk  = true;

  for (const key of Object.keys(STORES)) {
    const row = verify.get(key) as { value: string } | undefined;
    if (!row) {
      console.error(`  ❌ Missing key after migration: ${key}`);
      allOk = false;
    } else {
      try {
        JSON.parse(row.value);
      } catch {
        console.error(`  ❌ Invalid JSON for key: ${key}`);
        allOk = false;
      }
    }
  }

  db2.close();

  if (allOk) {
    console.log('  ✅ All stores verified successfully.\n');
  } else {
    console.error('  ❌ Verification failed. Do not delete JSON files yet.\n');
    process.exit(1);
  }

  // Print next steps
  console.log('┌─────────────────────────────────────────────┐');
  console.log('│  Migration complete.                         │');
  console.log('│                                              │');
  console.log('│  Next steps:                                 │');
  console.log('│  1. Start the app and verify it works        │');
  console.log('│  2. Place a test order to confirm writes     │');
  console.log('│  3. Once confirmed, archive the .json files  │');
  console.log('│     (keep them as backup, do not delete yet) │');
  console.log('└─────────────────────────────────────────────┘\n');
}

migrate().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
