import * as path from 'path';
import * as fs from 'fs';
import { SQLiteStore } from './sqliteStore.js';
import { Product, User, Order, Config, AIAlert, NotificationLog, AffiliatePayout, Customer, AffiliateGroup } from '../types.js';
import bcrypt from 'bcryptjs';

/**
 * DATA DIRECTORY RESOLUTION
 *
 * By default, data is stored in <project-root>/data.
 * On hosting platforms with ephemeral filesystems (Render free tier, Railway, Fly.io)
 * you MUST mount a persistent volume and point DATA_DIR at it:
 *
 *   PERSISTENT_DATA_PATH=/var/www/mystore/data
 *
 * Without a persistent path all data is lost on every restart.
 *
 * DATABASE FILE
 *   All stores share a single SQLite file: <DATA_DIR>/store.db
 *   Each store is one row in the kv_store table, keyed by store name.
 *
 * MIGRATION FROM JSON FILES
 *   If you are upgrading from the old JSON file storage, run:
 *     npm run db:migrate
 *   This reads existing .json files and inserts them into SQLite.
 *   The JSON files are kept as backup and not deleted automatically.
 */
const DATA_DIR = process.env.PERSISTENT_DATA_PATH
  ? path.resolve(process.env.PERSISTENT_DATA_PATH)
  : path.join(process.cwd(), 'data');

// Ensure the data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Write-access guard — fail fast if the directory isn't writable
const _testFile = path.join(DATA_DIR, '.write-test');
try {
  fs.writeFileSync(_testFile, '1');
  fs.unlinkSync(_testFile);
} catch {
  console.error(`FATAL: Data directory is not writable: ${DATA_DIR}`);
  console.error('Set PERSISTENT_DATA_PATH to a writable directory and restart.');
  process.exit(1);
}

const DB_PATH = path.join(DATA_DIR, 'store.db');

// ── Initial data seeds ────────────────────────────────────────────────────────

export const initialProducts: Product[] = [];

export const initialUsers: User[] = [
  {
    id: 'super-admin',
    name: 'Super Admin',
    email: process.env.SUPER_ADMIN_EMAIL || 'super@example.com',
    // In production the server refuses to start without SUPER_ADMIN_PASSWORD (see server.ts).
    // The 'admin123' fallback is intentionally only reachable in development.
    password: bcrypt.hashSync(process.env.SUPER_ADMIN_PASSWORD || 'admin123', 10),
    role: 'Super Admin',
    joined: new Date().toISOString().split('T')[0]
  }
];

export const initialConfig: Config = {
  storeName: '',
  storeDescription: '',
  isLive: false,
  themeColor: '#0f172a',
  accentColor: '#10b981',
  aboutTitle: '',
  aboutContent: '',
  aboutMission: '',
  aboutVision: '',
  aboutHeroImage: '',
  logoUrl: '',
  faviconUrl: '',
  contactEmail: '',
  contactPhone: '',
  supportEmail: '',
  supportHeading: '',
  supportSubheading: '',
  supportHoursWorkingDays: '',
  supportHoursWorkingTime: '',
  supportHoursWeekendDays: '',
  supportHoursWeekendTime: '',
  socialLinks: {
    instagram: '',
    twitter: '',
    facebook: ''
  },
  // In production the server refuses to start without SYSTEM_RESET_PASSWORD (see server.ts).
  // The 'reset123' fallback is intentionally only reachable in development.
  resetPassword: bcrypt.hashSync(process.env.SYSTEM_RESET_PASSWORD || 'reset123', 10),
  categories: [],
  orderStatuses: [
    { id: 'pending',       label: 'Pending',          color: '#f59e0b', isTerminal: false, triggersEmail: true,  triggersWhatsApp: true,  triggersPayout: false },
    { id: 'processing',    label: 'Processing',        color: '#3b82f6', isTerminal: false, triggersEmail: true,  triggersWhatsApp: false, triggersPayout: false },
    { id: 'shipped',       label: 'Shipped',           color: '#8b5cf6', isTerminal: false, triggersEmail: true,  triggersWhatsApp: true,  triggersPayout: false },
    { id: 'delivered',     label: 'Delivered',         color: '#10b981', isTerminal: true,  triggersEmail: true,  triggersWhatsApp: true,  triggersPayout: true  },
    { id: 'cancelled',     label: 'Cancelled',         color: '#ef4444', isTerminal: true,  triggersEmail: true,  triggersWhatsApp: false, triggersPayout: false, requiresNote: true },
    { id: 'returned',      label: 'Returned',          color: '#6366f1', isTerminal: true,  triggersEmail: true,  triggersWhatsApp: false, triggersPayout: false, requiresNote: true },
    { id: 'open',          label: 'OPEN',              color: '#3b82f6', isTerminal: false, triggersEmail: false, triggersWhatsApp: false, triggersPayout: false },
    { id: 'waiting_close', label: 'WAITING TO CLOSE',  color: '#f59e0b', isTerminal: true,  triggersEmail: false, triggersWhatsApp: false, triggersPayout: false },
    { id: 'closed',        label: 'CLOSED',            color: '#000000', isTerminal: true,  triggersEmail: false, triggersWhatsApp: false, triggersPayout: true,  requiresNote: true }
  ],
  tags: [],
  banners: [],
  heroTag: '',
  qualityTitle: '',
  qualityDescription: '',
  qualityImage: '',
  notifications: [],
  footerLinks: { shop: [], company: [] },
  aiSettings: {
    enabled: false,
    useProductDescriptions: false,
    useCheckoutValidation: false,
    useRecommendations: false,
    useBlogGeneration: false
  },
  affiliateSettings: {
    defaultCommissionRate: 10,
    allowNonAssignedCommissions: true,
    nonAssignedCommissionRate: 5
  },
  notificationSettings: {
    email: {
      enabled: false,
      templates: {
        'Pending':   'Hello {customerName}, your order {orderId} has been received and is pending.',
        'Completed': 'Hello {customerName}, your order {orderId} is now completed!',
        'Cancelled': 'Hello {customerName}, your order {orderId} has been cancelled.',
        'Shipped':   'Hello {customerName}, your order {orderId} has been shipped!'
      }
    },
    whatsapp: {
      enabled: false,
      templates: {
        'Pending':   'Hello {customerName}, your order {orderId} has been received and is pending.',
        'Completed': 'Hello {customerName}, your order {orderId} is now completed!',
        'Cancelled': 'Hello {customerName}, your order {orderId} has been cancelled.',
        'Shipped':   'Hello {customerName}, your order {orderId} has been shipped!'
      }
    },
    webhook: {
      enabled: false,
      url: '',
      secret: '',
      templates: {
        'Pending':   '{"event":"order.pending","orderId":"{orderId}","customer":"{customerName}"}',
        'Completed': '{"event":"order.completed","orderId":"{orderId}","customer":"{customerName}"}',
        'Cancelled': '{"event":"order.cancelled","orderId":"{orderId}","customer":"{customerName}"}',
        'Shipped':   '{"event":"order.shipped","orderId":"{orderId}","customer":"{customerName}"}'
      }
    }
  }
};

// ── Store instances ───────────────────────────────────────────────────────────
// Each store is a single row in store.db, keyed by the store name.
// The SQLiteStore interface is identical to the old DataStore:
//   .get()        → deep clone of current value (served from in-memory cache)
//   .set(data)    → write to cache + persist to SQLite synchronously
//   .update(fn)   → fetch → transform → set in one call

export const db = {
  products:         new SQLiteStore<Product[]>      (DB_PATH, 'products',         initialProducts),
  users:            new SQLiteStore<User[]>          (DB_PATH, 'users',            initialUsers),
  orders:           new SQLiteStore<Order[]>         (DB_PATH, 'orders',           []),
  config:           new SQLiteStore<Config>          (DB_PATH, 'config',           initialConfig),
  alerts:           new SQLiteStore<AIAlert[]>       (DB_PATH, 'alerts',           []),
  notificationLogs: new SQLiteStore<NotificationLog[]>(DB_PATH, 'notificationLogs', []),
  auditLogs:        new SQLiteStore<any[]>           (DB_PATH, 'auditLogs',        []),
  systemLogs:       new SQLiteStore<any[]>           (DB_PATH, 'systemLogs',       []),
  affiliatePayouts: new SQLiteStore<AffiliatePayout[]>(DB_PATH, 'affiliatePayouts', []),
  customers:        new SQLiteStore<Customer[]>      (DB_PATH, 'customers',        []),
  affiliateGroups:  new SQLiteStore<AffiliateGroup[]>(DB_PATH, 'affiliateGroups',  []),
  supportTickets:   new SQLiteStore<any[]>           (DB_PATH, 'supportTickets',   []),
  subscribers:      new SQLiteStore<any[]>           (DB_PATH, 'subscribers',      []),
};

// ── Context factory ───────────────────────────────────────────────────────────
// getContext() is called by every route handler and returns the current state
// of all stores. The interface is unchanged from the old JSON implementation.

export const getContext = () => ({
  products:         db.products.get(),
  setProducts:      (val: any) => db.products.set(val),
  users:            db.users.get(),
  setUsers:         (val: any) => db.users.set(val),
  orders:           db.orders.get(),
  setOrders:        (val: any) => db.orders.set(val),
  config:           db.config.get(),
  setConfig:        (val: any) => db.config.set(val),
  customers:        db.customers.get(),
  setCustomers:     (val: any) => db.customers.set(val),
  affiliateGroups:  db.affiliateGroups.get(),
  setAffiliateGroups: (val: any) => db.affiliateGroups.set(val),
  affiliatePayouts: db.affiliatePayouts.get(),
  setAffiliatePayouts: (val: any) => db.affiliatePayouts.set(val),
  alerts:           db.alerts.get(),
  setAlerts:        (val: any) => db.alerts.set(val),
  notificationLogs: db.notificationLogs.get(),
  setNotificationLogs: (val: any) => db.notificationLogs.set(val),
  auditLogs:        db.auditLogs.get(),
  setAuditLogs:     (val: any) => db.auditLogs.set(val),
  systemLogs:       db.systemLogs.get(),
  setSystemLogs:    (val: any) => db.systemLogs.set(val),
  supportTickets:   db.supportTickets.get(),
  setSupportTickets: (val: any) => db.supportTickets.set(val),
  subscribers:      db.subscribers.get(),
  setSubscribers:   (val: any) => db.subscribers.set(val),
});
