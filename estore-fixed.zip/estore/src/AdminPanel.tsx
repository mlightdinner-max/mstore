import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Routes, Route, useNavigate, useParams, Navigate } from 'react-router-dom';
import { LayoutDashboard, CheckCircle2, ShieldAlert, Save, RefreshCw, AlertTriangle, Package, Brain, Activity } from 'lucide-react';
import { motion } from 'motion/react';
import { Product, Order, AIAlert, Visitor, User, Config, NotificationLog, AffiliatePayout, Customer } from './types';

// AIStatus shape used in props
interface AIStatus {
  isAvailable: boolean;
  isHealthy: boolean;
  status?: string;
  lastError?: string | null;
  isUnsavedKey?: boolean;
  settings?: {
    enabled: boolean;
    useCheckoutValidation: boolean;
    useRecommendations: boolean;
    [key: string]: any;
  };
}

// Minimal audit log entry shape (full definition lives server-side)
interface AuditLogEntry {
  id: string;
  action: string;
  userId?: string;
  userName?: string;
  timestamp: string;
  details?: Record<string, any>;
}
import Modal from './components/common/Modal';
import NotificationBar from './components/common/NotificationBar';
import AdminSidebar from './components/admin/AdminSidebar';
import { ADMIN_MENU_GROUPS } from './components/admin/AdminMenuSchema';
import { DEFAULT_PERMISSIONS, CONFIGURABLE_MODULES, CAPTCHA_CHARS } from './constants';

// Lazy-loaded admin panels
const AdminOrders              = React.lazy(() => import('./components/admin/AdminOrders'));
const AdminProducts            = React.lazy(() => import('./components/admin/AdminProducts'));
const AdminCustomers           = React.lazy(() => import('./components/admin/AdminCustomers'));
const AdminUsers               = React.lazy(() => import('./components/admin/AdminUsers'));
const AdminAffiliates          = React.lazy(() => import('./components/admin/AdminAffiliates'));
const AdminVisibility          = React.lazy(() => import('./components/admin/AdminVisibility'));
const AdminSystemConfig        = React.lazy(() => import('./components/admin/AdminSystemConfig'));
const AdminProfiles            = React.lazy(() => import('./components/admin/AdminProfiles'));
const AdminHomepage            = React.lazy(() => import('./components/admin/AdminHomepage'));
const AdminAboutPage           = React.lazy(() => import('./components/admin/AdminAboutPage'));
const NewsletterManagement     = React.lazy(() => import('./components/admin/NewsletterManagement'));
const AdminProfitMargin        = React.lazy(() => import('./components/admin/AdminProfitMargin'));
const LiveTraffic              = React.lazy(() => import('./components/admin/LiveTraffic'));
const MediaLibrary             = React.lazy(() => import('./components/admin/MediaLibrary'));
const OperationsPanel          = React.lazy(() => import('./components/admin/OperationsPanel'));
const AdminOverview            = React.lazy(() => import('./components/admin/AdminOverview'));
const AdminHome                = React.lazy(() => import('./components/admin/AdminHome'));
const BlogManagement           = React.lazy(() => import('./components/admin/BlogManagement'));
const PagesManagement          = React.lazy(() => import('./components/admin/PagesManagement'));
const CouponManagement         = React.lazy(() => import('./components/admin/CouponManagement'));
const SupportTicketManagement  = React.lazy(() => import('./components/admin/SupportTicketManagement'));
const CommandCenter            = React.lazy(() => import('./components/admin/CommandCenter'));
const AffiliateProgramManagement = React.lazy(() => import('./components/admin/AffiliateProgramManagement'));
const AdminGeneral             = React.lazy(() => import('./components/admin/AdminGeneral'));
const AffiliateDashboard       = React.lazy(() => import('./components/admin/AffiliateDashboard'));
const AdminTaxonomy            = React.lazy(() => import('./components/admin/AdminTaxonomy').then(m => ({ default: m.AdminTaxonomy })));
const AdminBranding            = React.lazy(() => import('./components/admin/AdminBranding').then(m => ({ default: m.AdminBranding })));
const AdminAuditLog            = React.lazy(() => import('./components/admin/AdminAuditLog').then(m => ({ default: m.AdminAuditLog })));
const AdminIntegrations        = React.lazy(() => import('./components/admin/AdminIntegrations').then(m => ({ default: m.AdminIntegrations })));
const AdminNotifications       = React.lazy(() => import('./components/admin/AdminNotifications').then(m => ({ default: m.AdminNotifications })));
const AdminNavigation          = React.lazy(() => import('./components/admin/AdminNavigation').then(m => ({ default: m.AdminNavigation })));
const AdminBackupRestore       = React.lazy(() => import('./components/admin/AdminBackupRestore').then(m => ({ default: m.AdminBackupRestore })));
const AdminAffiliatePayouts    = React.lazy(() => import('./components/admin/AdminAffiliatePayouts').then(m => ({ default: m.AdminAffiliatePayouts })));
const AdminShippingReturns     = React.lazy(() => import('./components/admin/AdminShippingReturns').then(m => ({ default: m.AdminShippingReturns })));
const AdminSupportPage         = React.lazy(() => import('./components/admin/AdminSupportPage').then(m => ({ default: m.AdminSupportPage })));
const AdminRevenue             = React.lazy(() => import('./components/admin/AdminRevenue').then(m => ({ default: m.AdminRevenue })));

// Lazy-loaded store pages
const HomePage          = React.lazy(() => import('./components/store/HomePage'));
const ProductsPage      = React.lazy(() => import('./components/store/ProductsPage'));
const ProductDetailPage = React.lazy(() => import('./components/store/ProductDetailPage'));
const CheckoutPage      = React.lazy(() => import('./components/store/CheckoutPage'));
const BlogPage          = React.lazy(() => import('./components/store/BlogPage'));
const SupportPage       = React.lazy(() => import('./components/store/SupportPage'));
const AboutPage         = React.lazy(() => import('./components/store/AboutPage'));
const StoreFooter       = React.lazy(() => import('./components/store/StoreFooter'));
const TrackingPage      = React.lazy(() => import('./pages/store/TrackingPage').then(m => ({ default: m.TrackingPage })));
const PrivacyPolicyPage    = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.PrivacyPolicyPage })));
const TermsOfServicePage   = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.TermsOfServicePage })));
const ReturnsPolicyPage    = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.ReturnsPolicyPage })));









const AdminPanel = ({ 
  products, 
  users, 
  orders,
  config,
  aiAlerts,
  onClearAlerts,
  onDeleteAlert,
  onAddProduct, 
  onDeleteProduct, 
  onUpdateProduct,
  onAddUser, 
  onDeleteUser,
  onUpdateUser,
  onUpdateOrderStatus,
  onUpdateItemStatus,
  onUpdateConfig,
  onResetApp,
  onShowNotification,
  user,
  onLogout,
  notificationLogs,
  setNotificationLogs,
  token,
  auditLogs,
  affiliatePayouts,
  customers,
  onUpdateCustomerStatus,
  fetchData,
  statusFilter,
  setStatusFilter,
  aiStatus,
  onRefreshAiStatus
}: { 
  products: Product[]; 
  users: User[]; 
  orders: Order[];
  config: Config;
  aiAlerts: AIAlert[];
  onClearAlerts: () => void;
  onDeleteAlert: (id: string) => void;
  onAddProduct: (p: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateProduct: (id: string, p: Partial<Product>) => void;
  onAddUser: (u: Partial<User>) => void;
  onDeleteUser: (id: string) => void;
  onUpdateUser: (id: string, u: Partial<User>) => void;
  onUpdateOrderStatus: (id: string, status: string, customDate?: string, reason?: string, initiator?: string) => void;
  onUpdateItemStatus: (orderId: string, itemId: string, status: 'Active' | 'Cancelled', reason?: string) => void;
  onUpdateCustomerStatus: (id: string, status: 'Active' | 'Blocked') => void;
  onUpdateConfig: (c: Config) => Promise<boolean>;
  onResetApp: (password: string) => Promise<boolean>;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  user: User;
  onLogout: () => void;
  notificationLogs: NotificationLog[];
  setNotificationLogs: (logs: NotificationLog[]) => void;
  token: string | null;
  auditLogs: AuditLogEntry[];
  affiliatePayouts: AffiliatePayout[];
  customers: Customer[];
  fetchData: (t?: string | null) => Promise<void>;
  statusFilter: string | null;
  setStatusFilter: (s: string | null) => void;
  aiStatus: AIStatus | null;
  onRefreshAiStatus: (apiKey?: string) => Promise<void>;
}) => {
  const [selectedCustomerIdForDirectory, setSelectedCustomerIdForDirectory] = useState<string | null>(null);
  const [selectedOrderIdForManagement, setSelectedOrderIdForManagement] = useState<string | null>(null);
  const [liveVisitors, setLiveVisitors] = useState<Visitor[]>([]);
  const [localConfig, setLocalConfig] = useState(config);

  const [isLiveModalOpen, setIsLiveModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const adminMainRef = React.useRef<HTMLElement>(null);
  const [showUnsavedConfirm, setShowUnsavedConfirm] = useState(false);
  const [pendingTabChange, setPendingTabChange] = useState<string | null>(null);
  const [pendingToggleLive, setPendingToggleLive] = useState(false);
  const [showCaptchaModal, setShowCaptchaModal] = useState(false);
  const [captchaValue, setCaptchaValue] = useState('');
  const [captchaToken, setCaptchaToken] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaVerifying, setCaptchaVerifying] = useState(false);
  const isAdmin = user?.role === 'Admin' || user?.role === 'Super Admin' || user?.role === 'Customer Support';
  const isSuperAdmin = user?.role === 'Super Admin';
  const isAffiliate = user?.role === 'Affiliate';
  const navigate = useNavigate();
  const { "*": subPath } = useParams();
  const activeTab = subPath || '';

  const basePath = location.pathname.startsWith('/home') ? '/home' : window.location.pathname.startsWith('/affiliate') ? '/affiliate' : '/home';

  const hasUnsavedChanges = JSON.stringify(localConfig) !== JSON.stringify(config);

  const generateCaptcha = async () => {
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += CAPTCHA_CHARS.charAt(Math.floor(Math.random() * CAPTCHA_CHARS.length));
    }
    setCaptchaValue(result);
    setCaptchaInput('');
    // Get a server-signed token for this code so verification happens server-side
    try {
      const res = await fetch('/api/v1/captcha/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: result }),
      });
      const data = await res.json();
      setCaptchaToken(data.token || '');
    } catch {
      setCaptchaToken('');
    }
  };

  const handleTabChange = useCallback((tabId: string) => {
    if (hasUnsavedChanges) {
      setPendingTabChange(tabId);
      setShowUnsavedConfirm(true);
      return;
    }

    if (tabId === 'system-configuration') {
      generateCaptcha();
      setShowCaptchaModal(true);
      return;
    }

    navigate(tabId ? `${basePath}/${tabId}` : basePath);
    setIsSidebarOpen(false);
  }, [hasUnsavedChanges, basePath, navigate]);

  useEffect(() => {
    if (adminMainRef.current) {
      adminMainRef.current.scrollTo(0, 0);
    }
  }, [activeTab]);

  const groups = useMemo(() => {
    return ADMIN_MENU_GROUPS.map(group => ({
      ...group,
      label: (isAffiliate && group.affiliateLabel) ? group.affiliateLabel : group.label,
      items: group.items.map(item => ({
        ...item,
        label: (isAffiliate && (item as any).affiliateLabel) ? (item as any).affiliateLabel : item.label
      }))
    }));
  }, [isAffiliate]);

  useEffect(() => {
    const handleTabChangeEvent = (e: any) => {
      if (e.detail) handleTabChange(e.detail);
    };
    window.addEventListener('admin-tab-change', handleTabChangeEvent);
    return () => window.removeEventListener('admin-tab-change', handleTabChangeEvent);
  }, [handleTabChange]);

  useEffect(() => {
    if (!isAdmin) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const storedToken = localStorage.getItem('auth_token');
    const wsUrl = `${protocol}//${window.location.host}${storedToken ? `?token=${encodeURIComponent(storedToken)}` : ''}`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'visitors_update') {
          setLiveVisitors(message.data);
        }
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    };

    socket.onerror = (err) => {
      console.error('WebSocket error:', err);
    };

    return () => socket.close();
  }, [isAdmin]);

  const prevConfigRef = React.useRef(config);

  useEffect(() => {
    // If the global config changed (e.g. from a background fetch)
    // and the user hasn't made any local changes yet, update the local config.
    // We compare localConfig with the PREVIOUS global config to see if it's "clean".
    const isClean = JSON.stringify(localConfig) === JSON.stringify(prevConfigRef.current);
    
    if (isClean) {
      setLocalConfig(config);
    }
    
    prevConfigRef.current = config;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config]);

  useEffect(() => {
    if (!user) {
      if (window.location.pathname.startsWith('/affiliate')) {
        navigate('/affiliate');
      } else {
        navigate('/logintosft');
      }
    }
    
    // Strict role-based tab access
    if (user) {
      const role = user.role || 'Customer';
      if (role === 'Customer') return; // let routes handle it

      const isSuper = role === 'Super Admin';
      const perms = config.profilePermissions || DEFAULT_PERMISSIONS;
      const userAllowedModules = isSuper ? ['*'] : (perms[role] || []);
      const baseTab = activeTab.split('/')[0];

      if (!isSuper && !userAllowedModules.includes(baseTab)) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        handleTabChange(userAllowedModules[0] || 'dashboard');
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, activeTab, config]);

  const handleSaveConfig = async (): Promise<boolean> => {
    setIsValidating(true);
    try {
      return await onUpdateConfig(localConfig);
    } finally {
      setIsValidating(false);
    }
  };

  const confirmCaptcha = async () => {
    if (!captchaInput || captchaVerifying) return;
    setCaptchaVerifying(true);
    try {
      const res = await fetch('/api/v1/captcha/admin-verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ captchaToken, captchaAnswer: captchaInput }),
      });
      if (res.ok) {
        navigate(`${basePath}/system-configuration`);
        setShowCaptchaModal(false);
        setIsSidebarOpen(false);
      } else {
        const data = await res.json();
        onShowNotification(data.error || 'Invalid CAPTCHA. Please try again.', 'error');
        generateCaptcha();
      }
    } catch {
      onShowNotification('Verification failed. Please try again.', 'error');
      generateCaptcha();
    } finally {
      setCaptchaVerifying(false);
    }
  };

  const confirmSaveAndNavigate = async () => {
    const success = await handleSaveConfig();
    if (!success) return;

    if (pendingTabChange) {
      if (pendingTabChange === 'system-configuration') {
        generateCaptcha();
        setShowCaptchaModal(true);
      } else {
        navigate(`${basePath}/${pendingTabChange}`);
      }
      setPendingTabChange(null);
    }
    if (pendingToggleLive) {
      setIsLiveModalOpen(true);
      setPendingToggleLive(false);
    }
    setShowUnsavedConfirm(false);
  };

  const confirmDiscardAndNavigate = () => {
    setLocalConfig(config);
    if (pendingTabChange) {
      if (pendingTabChange === 'system-configuration') {
        generateCaptcha();
        setShowCaptchaModal(true);
      } else {
        navigate(`${basePath}/${pendingTabChange}`);
      }
      setPendingTabChange(null);
    }
    if (pendingToggleLive) {
      setIsLiveModalOpen(true);
      setPendingToggleLive(false);
    }
    setShowUnsavedConfirm(false);
  };

  const handleToggleLive = () => {
    if (hasUnsavedChanges) {
      setPendingToggleLive(true);
      setShowUnsavedConfirm(true);
    } else {
      setIsLiveModalOpen(true);
    }
  };

  const confirmToggleLive = async () => {
    const newConfig = { ...localConfig, isLive: !localConfig.isLive };
    const success = await onUpdateConfig(newConfig);
    if (success) {
      setLocalConfig(newConfig);
      onShowNotification(`Website is now ${newConfig.isLive ? 'Live' : 'Offline'}`, 'success');
    } else {
      onShowNotification('Failed to update website status', 'error');
    }
    setIsLiveModalOpen(false);
  };

  useEffect(() => {
    // Refresh AI status when local key changes (to account for unsaved connectivity tests)
    if (localConfig.geminiApiKey !== config.geminiApiKey) {
      onRefreshAiStatus(localConfig.geminiApiKey);
    } else {
      onRefreshAiStatus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localConfig.geminiApiKey]);

  const aiStatusLabel = useMemo(() => {
    if (!localConfig.aiSettings?.enabled) return 'OFF';
    if (!aiStatus) return 'CHECKING';
    
    // If the local key is different from the saved key, and we have status for it
    if (aiStatus.isUnsavedKey) {
      if (aiStatus.status === 'healthy') return 'KEY PENDING SAVE';
      if (aiStatus.status === 'no-key') return 'NO API KEY';
      if (aiStatus.status === 'auth') return 'INVALID API KEY';
    }

    if (aiStatus.status === 'no-key') return 'NO API KEY';
    if (aiStatus.status === 'auth') return 'INVALID API KEY';
    if (aiStatus.status === 'quota') return 'API QUOTA EXCEEDED';
    if (aiStatus.isAvailable) return 'LIVE';
    if (aiStatus.lastError) return 'DEGRADED';
    return 'ONLINE';
  }, [localConfig.aiSettings?.enabled, aiStatus]);

  const systemHealth = useMemo(() => {
    if (!aiAlerts || aiAlerts.length === 0) return 100;
    const criticalAlerts = aiAlerts.filter(a => a.severity === 'critical').length;
    const highAlerts = aiAlerts.filter(a => a.severity === 'high').length;
    const health = 100 - (criticalAlerts * 15) - (highAlerts * 5);
    return Math.max(0, health);
  }, [aiAlerts]);

  return (
    <div className="flex h-screen bg-slate-50 relative overflow-hidden">
      <AdminSidebar 
        activeTab={activeTab} 
        setActiveTab={handleTabChange} 
        user={user} 
        onLogout={onLogout} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        config={config}
      />
      <div className="flex-1 flex flex-col min-w-0 lg:ml-60 relative">
        {/* Mobile Header */}
        <header className="lg:hidden h-14 bg-white border-b border-slate-200 px-4 flex items-center justify-between sticky top-0 z-[100] isolate">
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2.5 -ml-2 text-slate-500 hover:text-slate-900 transition-colors touch-manipulation"
            >
              <LayoutDashboard size={20} />
            </button>
            <div className="flex flex-col">
              <span className="text-xs font-medium uppercase tracking-wider text-slate-400 leading-none mb-1">
                {groups.find(g => g.items.some(i => i.id === activeTab))?.label || 'Admin'}
              </span>
              <h2 className="text-xs font-bold text-slate-900 leading-none">
                {groups.flatMap(g => g.items).find(i => i.id === activeTab)?.label || 'Overview'}
              </h2>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5 px-2 py-1 bg-slate-50 rounded-lg border border-slate-100">
              <div className={`w-1.5 h-1.5 rounded-full ${aiStatus?.isAvailable ? "bg-emerald-500 animate-pulse" : "bg-slate-300"}`} />
              <div className={`w-1.5 h-1.5 rounded-full ${systemHealth < 80 ? "bg-red-500" : systemHealth < 95 ? "bg-amber-500" : "bg-emerald-500"}`} />
            </div>
            <div className={`w-2 h-2 rounded-full ${config.isLive ? 'bg-primary animate-pulse' : 'bg-red-500'}`} title={config.isLive ? 'Store Live' : 'Store Offline'} />
          </div>
        </header>

        {/* Desktop Header / Breadcrumbs */}
        <header className="hidden lg:flex h-16 bg-white/95 backdrop-blur-md border-b border-slate-100 px-8 items-center justify-between sticky top-0 z-[100] shadow-sm isolate">
          <div className="flex items-center space-x-4">
            <div className="flex flex-col">
              <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">
                <span>{groups.find(g => g.items.some(i => i.id === activeTab))?.label}</span>
                <span>/</span>
              </div>
              <h1 className="text-xl font-black text-slate-900 tracking-tight">
                {groups.flatMap(g => g.items).find(i => i.id === activeTab)?.label}
              </h1>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <div className="hidden xl:flex items-center space-x-4">
              <div 
                className="flex items-center space-x-2 px-3 py-1.5 bg-slate-50 rounded-xl border border-slate-100 cursor-pointer hover:bg-slate-100 transition-all font-sans"
                onClick={() => handleTabChange('ai-settings')}
              >
                <Brain size={12} className={aiStatus?.isAvailable ? "text-emerald-500 animate-pulse" : "text-slate-400"} />
                <span className="text-xs font-medium uppercase tracking-wider text-slate-500 whitespace-nowrap">AI Managed: {aiStatusLabel}</span>
                <div className={`w-1 h-1 rounded-full ${aiStatus?.isAvailable ? "bg-emerald-500 shadow-[0_0_8px_#10b981]" : "bg-slate-300"}`} />
              </div>
              <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-50 rounded-xl border border-slate-100 font-sans">
                <Activity size={12} className={systemHealth < 90 ? "text-amber-500" : "text-primary/80"} />
                <span className="text-xs font-medium uppercase tracking-wider text-slate-500 whitespace-nowrap">Health:</span>
                <span className={`text-xs font-black ${systemHealth < 80 ? "text-red-500" : systemHealth < 95 ? "text-amber-500" : "text-primary"}`}>{systemHealth}%</span>
              </div>
            </div>
            
            {hasUnsavedChanges && (
              <div className="flex items-center space-x-2 px-3 py-1 bg-amber-50 rounded-full border border-amber-100">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-xs font-medium uppercase tracking-wider text-amber-700">Unsaved Session</span>
              </div>
            )}
            <div className="h-8 w-px bg-slate-100" />
            <div className="flex items-center space-x-3 pl-2">
              <div className="text-right">
                <p className="text-xs font-bold text-slate-900 leading-none mb-0.5">{user?.name}</p>
                <p className="text-xs font-medium text-slate-400 uppercase tracking-wider leading-none">{user?.role}</p>
              </div>
              <div className="w-8 h-8 bg-slate-900 text-white rounded-xl flex items-center justify-center font-bold text-xs ring-4 ring-slate-50">
                {user?.name?.charAt(0).toUpperCase()}
              </div>
            </div>
          </div>
        </header>

        <main ref={adminMainRef} className="flex-1 overflow-y-auto overflow-x-hidden px-3 sm:px-5 lg:px-8 py-4 md:py-6 w-full max-w-7xl mx-auto custom-scrollbar relative isolate">
          {/* Status Indicator Bar (Mobile only, if offline) */}
          {!config.isLive && (
            <div className="lg:hidden mb-6 p-3 bg-red-50 border border-red-100 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-2 text-red-700 font-bold text-xs uppercase tracking-widest">
                <ShieldAlert size={14} />
                <span>Storefront is Offline</span>
              </div>
              <button 
                onClick={handleToggleLive}
                className="px-3 py-1.5 bg-red-600 text-white text-xs font-medium uppercase tracking-wider rounded-lg shadow-sm"
              >
                Go Live
              </button>
            </div>
          )}

          {/* Quick Stats Grid (Dashboard only) */}
          {activeTab === 'dashboard' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 mb-8 md:mb-12">
              {/* These could be mini key-metrics */}
            </div>
          )}

          {/* Tab Content */}
          <div className="w-full">
            {/* Settings Sticky Actions */}
            {CONFIGURABLE_MODULES.includes(activeTab) && hasUnsavedChanges && (
              <motion.div 
                initial={{ y: -100 }}
                animate={{ y: 0 }}
                className="sticky top-0 z-[100] -mx-4 px-4 py-3 md:-mx-8 md:px-8 border-b border-amber-100 bg-amber-50/90 backdrop-blur-md flex items-center justify-between shadow-2xl shadow-amber-950/5 mb-8"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-amber-500 text-white rounded-lg shadow-lg shadow-amber-500/20">
                    <AlertTriangle size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-medium uppercase tracking-wider text-amber-900 leading-none mb-1">Unsaved Changes</h4>
                    <p className="text-xs text-amber-700/60 font-bold uppercase tracking-tight">You have pending modifications to the site configuration</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setLocalConfig(config)}
                    className="btn-secondary"
                  >
                    Discard
                  </button>
                  <button 
                    onClick={handleSaveConfig}
                    disabled={isValidating}
                    className="btn-primary flex items-center space-x-2 disabled:opacity-50"
                  >
                    {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                    <span>Save Configuration</span>
                  </button>
                </div>
              </motion.div>
            )}

            <React.Suspense fallback={<div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-2 border-slate-200 border-t-slate-900 rounded-full animate-spin" /></div>}>
            <Routes>
              <Route path="/" element={<AdminHome user={user} config={localConfig} products={products} orders={orders} customers={customers} />} />
              <Route path="dashboard" element={
                isAdmin 
                  ? <AdminOverview products={products} orders={orders} user={user} setActiveTab={handleTabChange} aiStatus={aiStatus} config={localConfig} />
                  : isAffiliate
                    ? <AffiliateDashboard user={user} products={products} orders={orders} onShowNotification={onShowNotification} payouts={affiliatePayouts} token={token} onRefresh={fetchData} />
                    : <Navigate to="products" replace />
              } />
              <Route path="live" element={isAdmin ? <LiveTraffic visitors={liveVisitors} /> : <Navigate to="/" replace />} />
              <Route path="profit" element={isSuperAdmin ? <AdminProfitMargin orders={orders} products={products} config={config} /> : <Navigate to="/" replace />} />
              <Route path="customers/:id" element={isAdmin ? (
                <AdminCustomers 
                  customers={customers} 
                  orders={orders} 
                  onUpdateStatus={onUpdateOrderStatus} 
                  onUpdateItemStatus={onUpdateItemStatus} 
                  onUpdateCustomerStatus={onUpdateCustomerStatus}
                  config={config} 
                  externalSelectedCustomerId={selectedCustomerIdForDirectory}
                  onClearExternalSelection={() => setSelectedCustomerIdForDirectory(null)}
                  onNavigateToOrder={(orderId) => {
                    navigate(`${basePath}/orders/${orderId}`);
                  }}
                />
              ) : <Navigate to="/" replace />} />
              <Route path="customers" element={isAdmin ? (
                <AdminCustomers 
                  customers={customers} 
                  orders={orders}
                  onUpdateStatus={onUpdateOrderStatus} 
                  onUpdateItemStatus={onUpdateItemStatus} 
                  onUpdateCustomerStatus={onUpdateCustomerStatus}
                  config={config} 
                  externalSelectedCustomerId={selectedCustomerIdForDirectory}
                  onClearExternalSelection={() => setSelectedCustomerIdForDirectory(null)}
                  onNavigateToOrder={(orderId) => {
                    navigate(`${basePath}/orders/${orderId}`);
                  }}
                />
              ) : <Navigate to="/" replace />} />
              <Route path="system-monitor" element={isAdmin ? (
                <OperationsPanel 
                  products={products} 
                  orders={orders} 
                  alerts={aiAlerts} 
                  config={config} 
                  onShowNotification={onShowNotification}
                  token={token}
                />
              ) : <Navigate to="/" replace />} />
              <Route path="orders" element={
                isAdmin ? (
                <AdminOrders 
                  orders={orders} 
                  onUpdateStatus={onUpdateOrderStatus} 
                  onUpdateItemStatus={onUpdateItemStatus}
                  config={config} 
                  alerts={aiAlerts} 
                  setActiveTab={handleTabChange} 
                  user={user}
                  token={token}
                  externalStatusFilter={statusFilter}
                  onClearExternalFilter={() => setStatusFilter(null)}
                  onShowNotification={onShowNotification}
                  externalSelectedOrderId={selectedOrderIdForManagement}
                  onClearExternalSelection={() => setSelectedOrderIdForManagement(null)}
                  onNavigateToCustomer={(customerId) => {
                    navigate(`${basePath}/customers/${customerId}`);
                  }}
                />
                ) : <Navigate to="/" replace />
              } />
              <Route path="orders/:id" element={
                isAdmin ? (
                <AdminOrders 
                  orders={orders} 
                  onUpdateStatus={onUpdateOrderStatus} 
                  onUpdateItemStatus={onUpdateItemStatus}
                  config={config} 
                  alerts={aiAlerts} 
                  setActiveTab={handleTabChange} 
                  user={user}
                  token={token}
                  externalStatusFilter={statusFilter}
                  onClearExternalFilter={() => setStatusFilter(null)}
                  onShowNotification={onShowNotification}
                  externalSelectedOrderId={selectedOrderIdForManagement}
                  onClearExternalSelection={() => setSelectedOrderIdForManagement(null)}
                  onNavigateToCustomer={(customerId) => {
                    navigate(`${basePath}/customers/${customerId}`);
                  }}
                />
                ) : <Navigate to="/" replace />
              } />
              <Route path="delivery-returns" element={isAdmin ? (
                <AdminShippingReturns 
                  orders={orders}
                  onUpdateStatus={onUpdateOrderStatus}
                  onUpdateItemStatus={onUpdateItemStatus}
                  config={config}
                  onNavigateToOrder={(orderId) => {
                    setSelectedOrderIdForManagement(orderId);
                    handleTabChange('orders');
                  }}
                />
              ) : <Navigate to="/" replace />} />
              <Route path="products/*" element={<AdminProducts products={products} onAddProduct={onAddProduct} onDeleteProduct={onDeleteProduct} onUpdateProduct={onUpdateProduct} config={config} user={user} onShowNotification={onShowNotification} token={token} aiStatus={aiStatus} />} />
              <Route path="media" element={<MediaLibrary onShowNotification={onShowNotification} token={token} />} />
              <Route path="users" element={isAdmin ? <AdminUsers users={users} onAddUser={onAddUser} onDeleteUser={onDeleteUser} onUpdateUser={onUpdateUser} user={user} products={products} onShowNotification={onShowNotification} /> : <Navigate to="/" replace />} />
              <Route path="users/:id" element={isAdmin ? <AdminUsers users={users} onAddUser={onAddUser} onDeleteUser={onDeleteUser} onUpdateUser={onUpdateUser} user={user} products={products} onShowNotification={onShowNotification} /> : <Navigate to="/" replace />} />
              <Route path="blog-posts" element={isAdmin ? (
                  <BlogManagement 
                    config={localConfig} 
                    onUpdateConfig={setLocalConfig} 
                    user={user} 
                    token={token}
                    onShowNotification={onShowNotification}
                    aiStatus={aiStatus}
                  />
                ) : <Navigate to="/" replace />} />
              <Route path="legal-pages" element={isSuperAdmin ? <PagesManagement config={localConfig} onUpdateConfig={setLocalConfig} /> : <Navigate to="/" replace />} />
              <Route path="coupons" element={isAdmin ? <CouponManagement config={localConfig} onUpdateConfig={setLocalConfig} products={products} /> : <Navigate to="/" replace />} />
              <Route path="newsletter" element={isAdmin ? <NewsletterManagement config={localConfig} onUpdateConfig={setLocalConfig} token={token} onShowNotification={onShowNotification} /> : <Navigate to="/" replace />} />
              <Route path="support" element={isAdmin ? <SupportTicketManagement config={localConfig} onUpdateConfig={setLocalConfig} token={token} onShowNotification={onShowNotification} fetchData={fetchData} /> : <Navigate to="/" replace />} />
              <Route path="support/:id" element={isAdmin ? <SupportTicketManagement config={localConfig} onUpdateConfig={setLocalConfig} token={token} onShowNotification={onShowNotification} fetchData={fetchData} /> : <Navigate to="/" replace />} />
              <Route path="help-center" element={isAdmin ? <AdminSupportPage config={localConfig} onUpdateConfig={onUpdateConfig} onShowNotification={onShowNotification} /> : <Navigate to="/" replace />} />
              <Route path="revenue" element={isAdmin ? <AdminRevenue orders={orders} /> : <Navigate to="/" replace />} />
              <Route path="ai-settings" element={isAdmin ? (
                  <CommandCenter 
                    config={localConfig} 
                    onUpdateConfig={setLocalConfig} 
                    onSave={async () => { await handleSaveConfig(); }}
                    alerts={aiAlerts} 
                    onClearAlerts={onClearAlerts} 
                    onDeleteAlert={onDeleteAlert} 
                    aiStatus={aiStatus}
                    onRefreshAiStatus={onRefreshAiStatus}
                  />
                ) : <Navigate to="/" replace />} />
              <Route path="affiliate-programme" element={isAdmin ? (
                  <AffiliateProgramManagement 
                    config={localConfig} 
                    onUpdateConfig={setLocalConfig} 
                    products={products} 
                    users={users}
                    orders={orders}
                    onNavigateToPayouts={() => handleTabChange('affiliate-payouts')}
                  />
                ) : <Navigate to="/" replace />} />
              <Route path="general-settings" element={<AdminGeneral config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} isValidating={isValidating} />} />
              <Route path="integrations" element={isSuperAdmin ? <AdminIntegrations config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} isValidating={isValidating} /> : <Navigate to="/" replace />} />
              <Route path="seo-visibility" element={<AdminVisibility config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} onToggleLive={handleToggleLive} isValidating={isValidating} />} />
              <Route path="system-configuration" element={isSuperAdmin ? <AdminSystemConfig config={localConfig} onUpdateConfig={setLocalConfig} onResetApp={onResetApp} isSuperAdmin={isSuperAdmin} setActiveTab={handleTabChange} aiStatus={aiStatus} /> : <Navigate to="/home" replace />} />
              <Route path="permissions" element={isSuperAdmin ? <AdminProfiles config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} isValidating={isValidating} /> : <Navigate to="/" replace />} />
              <Route path="home-page" element={<AdminHomepage config={localConfig} onUpdateConfig={setLocalConfig} products={products} token={token} onShowNotification={onShowNotification} />} />
              <Route path="about-us" element={isSuperAdmin ? <AdminAboutPage config={localConfig} onUpdateConfig={setLocalConfig} token={token} onShowNotification={onShowNotification} /> : <Navigate to="/" replace />} />
              <Route path="categories-tags" element={<AdminTaxonomy config={localConfig} onUpdateConfig={setLocalConfig} orders={orders} products={products} onUpdateProducts={(updatedProducts) => { updatedProducts.forEach(p => onUpdateProduct(p.id, p)); }} onNavigateToOrders={(status) => { setStatusFilter(status); handleTabChange('orders'); }} token={token} onShowNotification={onShowNotification} />} />
              <Route path="notifications" element={<AdminNotifications config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} logs={notificationLogs} onNavigateToTaxonomy={() => handleTabChange('categories-tags')} onNavigateToIntegrations={() => handleTabChange('integrations')} onClearNotificationLogs={() => setNotificationLogs([])} isValidating={isValidating} />} />
              <Route path="activity-logs" element={isSuperAdmin ? <AdminAuditLog logs={auditLogs} setActiveTab={handleTabChange} setStatusFilter={setStatusFilter} onNavigateToOrder={(orderId) => navigate(`${basePath}/orders/${orderId}`)} /> : <Navigate to="/" replace />} />
              <Route path="affiliates" element={
                <AdminAffiliates 
                  affiliates={users.filter(u => u.role === 'Affiliate').map(u => ({
                    id: u.id,
                    name: u.name,
                    email: u.email,
                    code: u.affiliateId || '',
                    commissionRate: u.commissionRate || 0,
                    status: u.isBlocked ? 'Suspended' : 'Active',
                    joinedAt: u.joined || u.createdAt || new Date().toISOString()
                  }))}
                  orders={orders} 
                  onUpdateAffiliate={(id, a) => onUpdateUser(id, { ...users.find(u => u.id === id), ...a, affiliateId: a.code, isBlocked: a.status === 'Suspended' })}
                  onDeleteAffiliate={onDeleteUser}
                  onShowNotification={onShowNotification}
                />
              } />
              <Route path="affiliates/:id" element={
                <AdminAffiliates 
                  affiliates={users.filter(u => u.role === 'Affiliate').map(u => ({
                    id: u.id,
                    name: u.name,
                    email: u.email,
                    code: u.affiliateId || '',
                    commissionRate: u.commissionRate || 0,
                    status: u.isBlocked ? 'Suspended' : 'Active',
                    joinedAt: u.joined || u.createdAt || new Date().toISOString()
                  }))}
                  orders={orders} 
                  onUpdateAffiliate={(id, a) => onUpdateUser(id, { ...users.find(u => u.id === id), ...a, affiliateId: a.code, isBlocked: a.status === 'Suspended' })}
                  onDeleteAffiliate={onDeleteUser}
                  onShowNotification={onShowNotification}
                />
              } />
              <Route path="affiliate-payouts" element={isAdmin ? <AdminAffiliatePayouts users={users} payouts={affiliatePayouts} onProcessPayout={async (p) => { const res = await fetch('/api/v1/affiliates/payouts', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(p) }); if (res.ok) fetchData(); }} /> : <Navigate to="/home" replace />} />
              <Route path="store-branding" element={<AdminBranding config={localConfig} onUpdateConfig={setLocalConfig} token={token} onShowNotification={onShowNotification} />} />
              <Route path="navigation" element={<AdminNavigation config={localConfig} onUpdateConfig={setLocalConfig} onSave={handleSaveConfig} hasUnsavedChanges={hasUnsavedChanges} products={products} isValidating={isValidating} />} />
              <Route path="backups" element={isSuperAdmin ? <AdminBackupRestore /> : <Navigate to="/" replace />} />
            </Routes>
            </React.Suspense>
          </div>
      </main>

      <Modal
        isOpen={isLiveModalOpen}
        onClose={() => setIsLiveModalOpen(false)}
        title="Confirm Status Change"
      >
        <div className="space-y-6">
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-start space-x-3">
            <AlertTriangle className="text-amber-600 shrink-0 mt-0.5" size={18} />
            <p className="text-sm text-amber-800 leading-relaxed">
              Are you sure you want to turn the website <strong>{localConfig.isLive ? 'OFFLINE' : 'LIVE'}</strong>? 
              {localConfig.isLive ? ' Customers will see a maintenance page.' : ' Customers will be able to browse and shop.'}
            </p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => setIsLiveModalOpen(false)}
              className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={confirmToggleLive}
              className={`flex-1 py-3 text-white rounded-xl font-bold text-sm transition-all shadow-lg ${localConfig.isLive ? 'bg-red-600 hover:bg-red-700 shadow-red-600/20' : 'bg-primary hover:bg-primary-dark shadow-primary/20'}`}
            >
              Confirm
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={showCaptchaModal}
        onClose={() => setShowCaptchaModal(false)}
        title="Security Verification"
      >
        <div className="space-y-6">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-4">
            <p className="text-xs text-slate-600 font-bold uppercase tracking-widest">Please enter the security code to access system settings.</p>
            <div className="flex items-center justify-between bg-white p-6 rounded-2xl border border-black/5 shadow-inner">
              <div className="text-2xl font-bold tracking-[0.5em] text-slate-800 italic select-none line-through decoration-primary/30">
                {captchaValue}
              </div>
              <button 
                onClick={generateCaptcha}
                className="p-2.5 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-all"
              >
                <RefreshCw size={20} />
              </button>
            </div>
            <input 
              type="text"
              placeholder="Enter CAPTCHA code"
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === 'Enter' && confirmCaptcha()}
              className="w-full p-4 bg-white border border-black/5 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 font-black tracking-widest text-center text-lg"
              autoFocus
            />
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => setShowCaptchaModal(false)}
              className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={confirmCaptcha}
              disabled={!captchaInput || captchaVerifying}
              className="flex-1 py-3 bg-slate-900 text-white rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-sm disabled:opacity-50"
            >
              Verify & Access
            </button>
          </div>
        </div>
      </Modal>

      {/* Unsaved Changes Confirmation Modal */}
      <Modal 
        isOpen={showUnsavedConfirm} 
        onClose={() => setShowUnsavedConfirm(false)} 
        title="Unsaved Changes"
      >
        <div className="space-y-6">
          <div className="p-6 bg-amber-50 rounded-3xl border border-amber-100 flex items-start gap-4">
            <div className="p-3 bg-amber-100 text-amber-600 rounded-2xl">
              <ShieldAlert size={24} />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-amber-900">Wait, you have unsaved changes!</h4>
              <p className="text-xs text-amber-700 leading-relaxed font-medium">
                If you leave this section now, your recent modifications will be lost. Would you like to save them first?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={confirmSaveAndNavigate}
              className="w-full py-4 bg-slate-900 text-white rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-sm flex items-center justify-center gap-2"
            >
              <Save size={18} />
              <span>Save & Continue</span>
            </button>
            <button 
              onClick={confirmDiscardAndNavigate}
              className="w-full py-4 bg-slate-100 text-slate-600 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Discard Changes
            </button>
            <button 
              onClick={() => setShowUnsavedConfirm(false)}
              className="w-full py-4 bg-white text-slate-400 rounded-lg font-bold text-xs uppercase tracking-widest hover:text-slate-600 transition-all"
            >
              Stay on this page
            </button>
          </div>
        </div>
      </Modal>

      {/* Admin Footer */}
      <footer className="fixed bottom-0 right-0 left-0 lg:left-60 bg-white/80 backdrop-blur-md border-t border-slate-200 z-40 py-3 px-8 text-center md:text-left">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            {config.logoUrl ? (
              <img src={config.logoUrl} alt="Logo" className="h-5 w-auto object-contain" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-6 h-6 bg-slate-900 rounded-lg flex items-center justify-center">
                <Package size={12} className="text-white" />
              </div>
            )}
            <div className="flex flex-col">
              <p className="text-slate-900 text-sm font-semibold">
                {config.storeName || 'Store Management'}
              </p>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.2em]">
                Control Panel Active
              </p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => handleTabChange('system-configuration')} 
              className="group flex items-center space-x-2 text-slate-400 hover:text-slate-900 transition-colors"
            >
              <ShieldAlert size={12} className="group-hover:text-primary transition-colors" />
              <span className="text-xs font-medium uppercase tracking-wider">Core Engine</span>
            </button>
            <div className="h-4 w-[1px] bg-slate-200" />
            <div className="flex items-center space-x-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-sm shadow-emerald-500/20" />
              <p className="text-slate-400 text-xs font-medium uppercase tracking-wider leading-none">
                © {new Date().getFullYear()} <span className="text-slate-900">{config.storeName || 'Store'}</span> Systems
              </p>
            </div>
          </div>
        </div>
      </footer>
      </div>
    </div>
  );
};


export { AdminPanel };
