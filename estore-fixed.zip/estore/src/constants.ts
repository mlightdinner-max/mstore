export const API_PREFIX = '/api/v1';

// Module IDs MUST match the item `id` values in AdminMenuSchema.ts exactly.
// The sidebar's canView() check does: userPermissions.includes(item.id)
// so any mismatch silently hides or shows modules incorrectly.
export const AVAILABLE_MODULES = [
  // Analytics & Insights
  { id: 'dashboard',        name: 'Overview',               group: 'Analytics & Insights' },
  { id: 'live',             name: 'Live Traffic',           group: 'Analytics & Insights' },
  { id: 'revenue',          name: 'Revenue & Sales',        group: 'Analytics & Insights' },
  { id: 'customers',        name: 'Customers',              group: 'Analytics & Insights' },

  // Inventory & Media
  { id: 'products',         name: 'Products',               group: 'Inventory & Media' },
  { id: 'media',            name: 'Media Library',          group: 'Inventory & Media' },
  { id: 'categories-tags',  name: 'Categories & Tags',      group: 'Inventory & Media' },

  // Operations
  { id: 'orders',           name: 'Orders',                 group: 'Operations' },
  { id: 'delivery-returns', name: 'Delivery & Returns',     group: 'Operations' },
  { id: 'coupons',          name: 'Coupons & Offers',       group: 'Operations' },

  // Growth & Marketing
  { id: 'affiliates',       name: 'Affiliate Partners',     group: 'Growth & Marketing' },
  { id: 'affiliate-programme', name: 'Affiliate Programme', group: 'Growth & Marketing' },
  { id: 'affiliate-payouts',name: 'Affiliate Payouts',      group: 'Growth & Marketing' },
  { id: 'newsletter',       name: 'Newsletter',             group: 'Growth & Marketing' },
  { id: 'blog-posts',       name: 'Blog Posts',             group: 'Growth & Marketing' },

  // Customer Support
  { id: 'notifications',    name: 'Notification Settings',  group: 'Customer Support' },
  { id: 'support',          name: 'Support Tickets',        group: 'Customer Support' },
  { id: 'help-center',      name: 'Help Centre Content',    group: 'Customer Support' },

  // Storefront Settings
  { id: 'store-branding',   name: 'Store Branding',         group: 'Storefront Settings' },
  { id: 'navigation',       name: 'Navigation & Layout',    group: 'Storefront Settings' },
  { id: 'home-page',        name: 'Home Page Settings',     group: 'Storefront Settings' },
  { id: 'seo-visibility',   name: 'SEO & Visibility',       group: 'Storefront Settings' },

  // System & Security (non-superAdminOnly items only — superAdminOnly items are always hidden for non-super-admins)
  { id: 'general-settings', name: 'General Settings',       group: 'System & Security' },
  { id: 'users',            name: 'Admin Users',            group: 'System & Security' },
  { id: 'system-monitor',   name: 'System Monitor',         group: 'System & Security' },
  { id: 'ai-settings',      name: 'AI Settings',            group: 'System & Security' },
];

export const CAPTCHA_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// Tabs that show the "unsaved changes" warning banner when the user
// tries to navigate away without saving. Must match menu item IDs.
export const CONFIGURABLE_MODULES = [
  'general-settings',
  'navigation',
  'store-branding',
  'seo-visibility',
  'permissions',
  'notifications',
  'ai-settings'
];

// Default module access per role.
// Super Admin always gets everything — their ['*'] is handled separately in AdminSidebar.
export const DEFAULT_PERMISSIONS: Record<string, string[]> = {
  'Super Admin': ['*'],
  'Admin': AVAILABLE_MODULES.map(m => m.id),
  'Affiliate': ['dashboard', 'products', 'orders', 'affiliate-payouts'],
  'Customer Support': ['dashboard', 'orders', 'delivery-returns', 'support', 'help-center', 'notifications'],
};

export const LOCALIZATION = {
  PINCODE: 'PIN code',
  ZIP: 'PIN code',
  SHIPPING: 'Delivery Charges',
  DELIVERY: 'Delivery',
  COD: 'Cash on Delivery (COD)',
  ORDER_ID: 'Order ID',
  ORDER_PLACED: 'Order Placed Successfully',
  TRACK_ORDER: 'Track Order',
  STATE: 'State',
  PHONE: 'Mobile number',
  SUBTOTAL: 'Subtotal',
  TOTAL: 'Grand Total',
  CHECKOUT: 'Checkout',
  PAYMENT_METHOD: 'Payment Mode',
  ADDRESS: 'Delivery Address',
  CITY: 'City',
  COUPON: 'Coupon Code',
  APPLY: 'Apply',
  DISCOUNT: 'Discount',
  CURRENCY: '₹',
  FALLBACK_IMAGE: 'https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=2029&auto=format&fit=crop'
};
