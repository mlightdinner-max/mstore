import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, AlertCircle, CheckCircle2, RotateCcw, Activity, 
  MapPin, X, AlertTriangle, RefreshCw, ArrowLeft, ShoppingBag 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Order } from '../../types';
import { LOCALIZATION } from '../../constants';
import Captcha, { type CaptchaResult } from '../../components/common/Captcha';

interface TrackingPageProps {
  config: any;
  onUpdateItemStatus?: (orderId: string, itemId: string, status: string, reason?: string, date?: string, eta?: string) => void;
  onUpdateOrderStatus?: (id: string, status: string, statusDate?: string, statusChangeReason?: string, updatedBy?: string, eta?: string) => void;
}

  export const TrackingPage = ({ config: _config, onUpdateItemStatus: _onUpdateItemStatus }: TrackingPageProps) => {
    const [orderId, setOrderId] = useState('');
    const [contactInfo, setContactInfo] = useState('');
    const [zipCode, setZipCode] = useState('');
    const [captcha, setCaptcha] = useState<CaptchaResult>({ verified: false, token: '', answer: '' });
    
    const [error, setError] = useState('');
    const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);
    const [isSearching, setIsSearching] = useState(false);
    
  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId.trim() || !contactInfo.trim() || !zipCode.trim()) {
      setError('Order ID, Contact Info, and PIN Code are mandatory.');
      return;
    }
    if (!captcha.verified) {
      setError('Please complete the security verification.');
      return;
    }
    setIsSearching(true);
    setError('');
    try {
      const res = await fetch('/api/v1/orders/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: orderId.trim(), contact: contactInfo.trim(), zip: zipCode.trim(), captchaToken: captcha.token, captchaAnswer: captcha.answer })
      });
      if (res.ok) {
        setTrackedOrder(await res.json());
      } else {
        setError('No order found matching these details. Please check your Order ID, mobile number or email, and PIN code.');
        setTrackedOrder(null);
      }
    } catch {
      setError('Unable to reach server. Please try again.');
    } finally {
      setIsSearching(false);
    }
  };

  const refreshTrackedOrder = async () => {
    try {
      const res = await fetch('/api/v1/orders/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: orderId.trim(), contact: contactInfo.trim(), zip: zipCode.trim() })
      });
      if (res.ok) setTrackedOrder(await res.json());
    } catch (err) {
      console.error('Failed to refresh tracked order:', err);
    }
  };

  const handleCancelItem = async (itemId: string) => {
    if (!trackedOrder) return;
    try {
      const res = await fetch('/api/v1/orders/public-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: trackedOrder.id, itemId, action: 'cancel', reason: cancelReason, contact: contactInfo })
      });
      const data = await res.json();
      if (res.ok) {
        setShowCancelConfirm(null);
        setCancelReason('');
        await refreshTrackedOrder();
      } else {
        setError(data.error || 'Failed to request cancellation.');
      }
    } catch {
      setError('Unable to reach server.');
    }
  };

  const handleReturnItem = async (itemId: string, reason: string) => {
    if (!trackedOrder) return;
    try {
      const res = await fetch('/api/v1/orders/public-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: trackedOrder.id, itemId, action: 'return', reason, contact: contactInfo })
      });
      const data = await res.json();
      if (res.ok) {
        setShowReturnConfirm(null);
        await refreshTrackedOrder();
      } else {
        setError(data.error || 'Failed to request return.');
      }
    } catch {
      setError('Unable to reach server.');
    }
  };

  const isWithinReturnWindow = (deliveredAt?: string) => {
    if (!deliveredAt) return false;
    const deliveredDate = new Date(deliveredAt);
    const now = new Date();
    const diffTime = now.getTime() - deliveredDate.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    return diffDays >= 0 && diffDays <= 30;
  };

  const [showReturnConfirm, setShowReturnConfirm] = useState<string | null>(null);
  const [returnReason, setReturnReason] = useState('');
  const [showCancelConfirm, setShowCancelConfirm] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');


  const getStatusStep = (status: string) => {
    const steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];
    const index = steps.indexOf(status);
    if (index === -1) {
      if (status === 'Completed') return 3;
      return -1;
    }
    return index;
  };

  return (
    <div className="min-h-screen bg-slate-50 py-5 md:py-12 pb-10 md:pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-200/50 border border-slate-300/50 text-xs font-bold uppercase tracking-[0.2em] text-slate-500 mb-4">
            <Activity size={12} className="text-primary" />
            Live Order Delivery Tracking
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight mb-3">
            {LOCALIZATION.TRACK_ORDER.split(' ')[0]} Your <span className="text-primary">{LOCALIZATION.TRACK_ORDER.split(' ')[1] || 'Order'}</span>
          </h1>
          <p className="text-slate-500 max-w-xl mx-auto text-sm sm:text-lg">
            Monitor your package's journey from our store to your doorstep in real-time.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-12"
          >
            <div className="bg-white rounded-2xl sm:rounded-[2rem] shadow-xl sm:shadow-2xl shadow-slate-200 border border-slate-200 overflow-hidden">
              <div className="p-5 md:p-8">
                <form onSubmit={handleTrack} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Order ID</label>
                      <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-900 transition-colors" size={18} />
                        <input
                          type="text"
                          value={orderId}
                          onChange={(e) => setOrderId(e.target.value)}
                          placeholder="e.g. ORD-123456"
                          className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all text-base sm:text-sm font-medium"
                          required
                        />
                      </div>
                      <p className="text-xs text-slate-500 ml-1">
                        Don't know your order ID? Check your email or <Link to="/support" className="text-primary hover:underline font-medium">contact support</Link>.
                      </p>
                    </div>
                    <div className="space-y-3">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Mobile Number or Email</label>
                      <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-900 transition-colors" size={18} />
                        <input
                          type="text"
                          value={contactInfo}
                          onChange={(e) => setContactInfo(e.target.value)}
                          placeholder="Mobile number or email address"
                          className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all text-base sm:text-sm font-medium"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">PIN Code</label>
                      <div className="relative group">
                        <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-900 transition-colors" size={18} />
                        <input
                          type="text"
                          value={zipCode}
                          onChange={(e) => setZipCode(e.target.value)}
                          placeholder="Enter 6-digit PIN code"
                          className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all text-base sm:text-sm font-medium"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Security Verification</label>
                      <Captcha onVerify={setCaptcha} />
                    </div>
                  </div>

                  <AnimatePresence>
                    {error && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="p-4 bg-red-50 text-red-600 rounded-2xl border border-red-100 flex items-start gap-3 shadow-sm"
                      >
                        <AlertCircle className="shrink-0 mt-0.5" size={18} />
                        <p className="text-xs font-bold uppercase tracking-wider">{error}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    type="submit"
                    disabled={isSearching}
                    className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold text-sm uppercase tracking-wider active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed hover:bg-black touch-manipulation"
                  >
                    {isSearching ? (
                      <RefreshCw className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <Search size={20} />
                        Track My Order
                      </>
                    )}
                  </button>
                </form>
              </div>

              <AnimatePresence>
                {trackedOrder && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="border-t border-slate-100 bg-slate-50/50 p-6 md:p-8 space-y-8"
                  >
                    {/* Header Info */}
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                        <div className="space-y-1">
                          <button 
                            onClick={() => {
                              setTrackedOrder(null);
                              setOrderId('');
                              setContactInfo('');
                              setZipCode('');
                              setCaptcha({ verified: false, token: '', answer: '' });
                              setError('');
                            }}
                            className="flex items-center space-x-2 text-xs font-black text-slate-400 hover:text-slate-900 uppercase tracking-widest transition-colors mb-4 group"
                          >
                            <ArrowLeft size={12} className="group-hover:-translate-x-1 transition-transform" />
                            <span>Track Another Order</span>
                          </button>
                          <div className="flex items-center gap-3">
                          <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">{trackedOrder.id}</h2>
                        </div>
                        <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-2">
                          Ordered on {new Date(trackedOrder.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}
                        </p>
                        {trackedOrder.eta && (
                           <p className="text-primary text-xs font-bold uppercase tracking-widest mt-1">
                             Estimated Delivery: {new Date(trackedOrder.eta).toLocaleDateString(undefined, { dateStyle: 'long' })}
                           </p>
                        )}
                      </div>
                    </div>

                    {/* Customer Info */}
                    <div className="bg-white p-6 rounded-2xl border border-slate-200">
                      <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4">Customer Info</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-600 font-medium">
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Name</p>
                          <p className="mt-1 text-slate-900">{trackedOrder.customerName || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Email</p>
                          <p className="mt-1 text-slate-900">{trackedOrder.email || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Phone</p>
                          <p className="mt-1 text-slate-900">{trackedOrder.phone || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Address</p>
                          <p className="mt-1 text-slate-900 truncate" title={`${trackedOrder.address}, ${trackedOrder.city}, ${trackedOrder.state} ${trackedOrder.zip}`}>{trackedOrder.address}, {trackedOrder.city}, {trackedOrder.state} {trackedOrder.zip}</p>
                        </div>
                      </div>
                    </div>

                    {/* Content Grid */}
                    <div className="flex flex-col space-y-8 mt-8">
                      {/* Line Items */}
                      <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm space-y-6">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                          <div className="flex items-center gap-3">
                            <ShoppingBag size={18} className="text-slate-400" />
                            <h3 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em]">Items Ordered</h3>
                          </div>
                          <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{trackedOrder.items.length} Units</span>
                        </div>
                        
                        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                          {trackedOrder.items.map((item, idx) => (
                            <div key={idx} className="group flex flex-col gap-4 p-5 rounded-2xl border border-slate-100 bg-white hover:border-slate-200 hover:shadow-md transition-all">
                              {item.statusHistory && item.statusHistory.length > 0 && !['Cancelled', 'Returned', 'Return Requested', 'Cancellation Requested'].includes(item.status || '') && (
                                <div className="relative w-full pb-4 border-b border-slate-50">
                                  <div className="absolute top-[10px] left-4 right-4 h-[2px] bg-slate-100 rounded-full" />
                                  <div 
                                    className="absolute top-[10px] left-4 h-[2px] bg-primary rounded-full transition-all duration-1000"
                                    style={{ width: `calc(${(getStatusStep(item.status || 'Pending') / 3) * 100}% - 2rem)` }}
                                  />
                                  <div className="relative flex justify-between">
                                    {['Pending', 'Processing', 'Shipped', 'Delivered'].map((step, i) => {
                                      const isPast = getStatusStep(item.status || 'Pending') >= i;
                                      const historyEntry = item.statusHistory?.slice().reverse().find(h => h.status === step || (step === 'Delivered' && h.status === 'Completed'));
                                      let dateValue = historyEntry?.date;
                                      if (!dateValue) {
                                        if (step === 'Pending') dateValue = trackedOrder.createdAt;
                                        else if (step === 'Delivered' && item.status === 'Delivered') dateValue = item.deliveredAt || trackedOrder.deliveredAt || trackedOrder.updatedAt;
                                      }
                                      
                                      return (
                                        <div key={step} className="flex flex-col items-center w-16">
                                          <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all duration-500 z-10 ${
                                            isPast ? 'bg-primary text-white shadow-sm' : 'bg-white border-2 border-slate-100 text-slate-300'
                                          }`}>
                                            {isPast ? <CheckCircle2 size={12} /> : <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />}
                                          </div>
                                          <p className={`text-xs font-medium uppercase tracking-wider mt-1.5 text-center ${isPast ? 'text-slate-900' : 'text-slate-400'}`}>
                                            {step}
                                          </p>
                                          {isPast && dateValue && (
                                            <p className="text-xs font-bold text-slate-500 mt-0.5 text-center">
                                              {new Date(dateValue).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                            </p>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}
                              
                              <div className="flex flex-col md:flex-row md:items-center gap-4">
                                <div className="flex items-center gap-4 flex-1">
                                  <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-100 shrink-0 shadow-sm">
                                    <img 
                                      src={item.image || LOCALIZATION.FALLBACK_IMAGE} 
                                      alt={item.name} 
                                      className="w-full h-full object-cover transition-transform group-hover:scale-110" 
                                    />
                                      {item.status === 'Cancelled' ? (
                                        <div className="absolute inset-0 bg-red-500/10 backdrop-blur-[1px] flex items-center justify-center">
                                          <X size={16} className="text-red-600" />
                                        </div>
                                      ) : item.status === 'Cancellation Requested' ? (
                                        <div className="absolute inset-0 bg-amber-500/10 backdrop-blur-[1px] flex items-center justify-center">
                                          <AlertTriangle size={16} className="text-amber-600 animate-pulse" />
                                        </div>
                                      ) : item.status === 'Return Requested' ? (
                                        <div className="absolute inset-0 bg-amber-500/10 backdrop-blur-[1px] flex items-center justify-center">
                                          <RotateCcw size={16} className="text-amber-600 animate-pulse" />
                                        </div>
                                      ) : null}
                                  </div>
                                  
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-black text-slate-900 uppercase tracking-tight truncate">{item.name}</p>
                                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2">
                                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Qty: <span className="text-slate-900 font-black">{item.quantity}</span></p>
                                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Price: <span className="text-slate-900 font-black">{LOCALIZATION.CURRENCY}{item.price.toLocaleString()}</span></p>
                                      {item.status && (
                                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium uppercase tracking-wider ${
                                          item.status === 'Delivered' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                                          item.status === 'Cancelled' ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                                          item.status === 'Cancellation Requested' ? 'bg-amber-50 text-amber-600 border border-amber-100 italic' :
                                          item.status === 'Return Requested' ? 'bg-amber-50 text-amber-600 border border-amber-100 italic' :
                                          item.status === 'Shipped' ? 'bg-blue-50 text-blue-600 border border-blue-100' :
                                          'bg-slate-50 text-slate-500 border border-slate-100'
                                        }`}>
                                          {item.status}
                                        </span>
                                      )}
                                    </div>
                                    
                                    <div className="flex gap-2 mt-2">
                                      {item.status === 'Cancelled' && (
                                        <span className="inline-block px-2 py-0.5 bg-red-100 text-red-700 text-xs font-black uppercase tracking-[0.1em] rounded-md">Voided</span>
                                      )}
                                      {item.status === 'Cancellation Requested' && (
                                        <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-700 text-xs font-black uppercase tracking-[0.1em] rounded-md animate-pulse">Cancellation Awaiting Approval</span>
                                      )}
                                      {item.status === 'Return Requested' && (
                                        <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-700 text-xs font-black uppercase tracking-[0.1em] rounded-md animate-pulse">Return Awaiting Approval</span>
                                      )}
                                      {item.status === 'Returned' && (
                                        <span className="inline-block px-2 py-0.5 bg-purple-100 text-purple-700 text-xs font-black uppercase tracking-[0.1em] rounded-md">Returned</span>
                                      )}
                                      {item.status === 'Return Rejected' && (
                                        <span className="inline-block px-2 py-0.5 bg-slate-100 text-slate-500 text-xs font-black uppercase tracking-[0.1em] rounded-md line-through">Return Rejected</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="flex gap-2 self-end md:self-center">
                                  {item.status !== 'Cancelled' && item.status !== 'Returned' && item.status !== 'Return Requested' && item.status !== 'Cancellation Requested' && (
                                    <>
                                      {['Pending', 'Processing', 'Shipped'].includes(trackedOrder.status) && (
                                        <button 
                                          onClick={() => setShowCancelConfirm(item.id)}
                                          className="px-4 py-2 bg-red-50 text-red-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-red-500 hover:text-white transition-all border border-red-100 shadow-sm flex items-center gap-2"
                                          title="Cancel Item"
                                        >
                                          <X size={14} />
                                          <span>Cancel</span>
                                        </button>
                                      )}
                                      {trackedOrder.status === 'Delivered' && isWithinReturnWindow(item.deliveredAt || trackedOrder.deliveredAt) && (
                                        <button 
                                          onClick={() => setShowReturnConfirm(item.id)}
                                          className="px-4 py-2 bg-amber-50 text-amber-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-amber-500 hover:text-white transition-all border border-amber-100 shadow-sm flex items-center gap-2"
                                          title="Request Return"
                                        >
                                          <RotateCcw size={14} />
                                          <span>Return</span>
                                        </button>
                                      )}
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {showCancelConfirm && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="p-6 bg-red-50 rounded-2xl border border-red-100 space-y-4 shadow-inner"
                          >
                            <div className="flex items-center gap-2">
                              <AlertTriangle size={14} className="text-red-500" />
                              <p className="text-xs font-medium text-red-700 uppercase tracking-wider">Security Override: Cancellation</p>
                            </div>
                            <textarea 
                              placeholder="Provide justification for cancellation..."
                              className="w-full p-4 bg-white border border-red-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-4 focus:ring-red-500/10 transition-all placeholder:text-red-300"
                              value={cancelReason}
                              onChange={(e) => setCancelReason(e.target.value)}
                              rows={2}
                            />
                            <div className="flex gap-3">
                              <button 
                                onClick={() => handleCancelItem(showCancelConfirm)}
                                className="flex-1 py-3 bg-red-600 text-white text-xs font-medium uppercase tracking-wider rounded-xl hover:bg-red-700 transition-all shadow-lg shadow-red-600/20"
                              >
                                Confirm Void
                              </button>
                              <button 
                                onClick={() => {
                                  setShowCancelConfirm(null);
                                  setCancelReason('');
                                }}
                                className="flex-1 py-3 bg-white text-slate-400 text-xs font-medium uppercase tracking-wider rounded-xl border border-slate-200 hover:bg-slate-50 transition-all shadow-sm"
                              >
                                Abort
                              </button>
                            </div>
                          </motion.div>
                        )}

                        {showReturnConfirm && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="p-6 bg-amber-50 rounded-2xl border border-amber-100 space-y-4 shadow-inner"
                          >
                            <div className="flex items-center gap-2">
                              <RotateCcw size={14} className="text-amber-500" />
                              <p className="text-xs font-medium text-amber-700 uppercase tracking-wider">Initialization: Item Return Request</p>
                            </div>
                            <textarea 
                              placeholder="Reason for returning this product..."
                              className="w-full p-4 bg-white border border-amber-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-4 focus:ring-amber-500/10 transition-all placeholder:text-amber-300"
                              value={returnReason}
                              onChange={(e) => setReturnReason(e.target.value)}
                              rows={2}
                            />
                            <div className="flex gap-3">
                              <button 
                                onClick={() => handleReturnItem(showReturnConfirm, returnReason)}
                                className="flex-1 py-3 bg-amber-600 text-white text-xs font-medium uppercase tracking-wider rounded-xl hover:bg-amber-700 transition-all shadow-lg shadow-amber-600/20"
                              >
                                Submit Request
                              </button>
                              <button 
                                onClick={() => {
                                  setShowReturnConfirm(null);
                                  setReturnReason('');
                                }}
                                className="flex-1 py-3 bg-white text-slate-400 text-xs font-medium uppercase tracking-wider rounded-xl border border-slate-200 hover:bg-slate-50 transition-all shadow-sm"
                              >
                                Abort
                              </button>
                            </div>
                          </motion.div>
                        )}

                        <div className="pt-6 border-t border-slate-100 flex justify-between items-center">
                          <span className="text-xs font-medium text-slate-400 uppercase tracking-wider text-[#64748b]">{LOCALIZATION.TOTAL}</span>
                          <span className="text-2xl font-black text-slate-900 tracking-tighter">{LOCALIZATION.CURRENCY}{trackedOrder.total.toLocaleString()}</span>
                        </div>
                      </div>
                      
                      {trackedOrder.reopenReason && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-primary/5 border border-primary/20 p-6 rounded-[2rem] flex items-start gap-4 lg:col-span-2"
                        >
                          <div className="shrink-0 p-2 rounded-xl bg-primary/10">
                            <Activity size={20} className="text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs font-medium uppercase tracking-wider text-primary">Service Update</p>
                            <p className="text-sm font-black text-slate-900 leading-tight">This order was reopened for further processing.</p>
                            <p className="text-xs text-slate-500 font-medium mt-1 italic">"{trackedOrder.reopenReason}"</p>
                          </div>
                        </motion.div>
                      )}


                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};


export default TrackingPage;
