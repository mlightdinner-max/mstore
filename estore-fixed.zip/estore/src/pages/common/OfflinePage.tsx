import React from 'react';
import { motion } from 'motion/react';
import { Activity } from 'lucide-react';

interface OfflinePageProps {
  config: any;
}

const OfflinePage = ({ config }: OfflinePageProps) => (
  <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-6 text-center">
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md space-y-5"
    >
      <div className="w-12 h-12 bg-slate-50 text-slate-600 rounded-lg flex items-center justify-center mx-auto border border-slate-100 shadow-sm">
        <Activity size={20} className="animate-pulse" />
      </div>
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">{config.storeName || 'Store'} is Offline</h1>
        <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">We are currently performing maintenance. Please check back later.</p>
      </div>
      <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm">
        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Contact Support</p>
        <p className="text-xs text-slate-900 font-bold mt-1">{config.contactEmail || ''}</p>
      </div>
    </motion.div>
  </div>
);

export default OfflinePage;
