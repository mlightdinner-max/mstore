import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * ScrollToTop component that resets scroll position on route changes.
 */
const ScrollToTop = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    // Reset scroll position to top
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant', // Use 'instant' to avoid flickers during navigation
    });
  }, [pathname]);

  return null;
};

export default ScrollToTop;
