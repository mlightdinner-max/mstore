import React, { useState, useEffect, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';
import { CAPTCHA_CHARS } from '../../constants';

export interface CaptchaResult {
  verified: boolean;
  token: string;
  answer: string;
}

interface CaptchaProps {
  onVerify: (result: CaptchaResult) => void;
}

const Captcha = ({ onVerify }: CaptchaProps) => {
  const [code, setCode] = useState('');
  const [token, setToken] = useState('');
  const [input, setInput] = useState('');
  const [error, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const generateCode = useCallback(() => {
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += CAPTCHA_CHARS.charAt(Math.floor(Math.random() * CAPTCHA_CHARS.length));
    }
    return result;
  }, []);

  const fetchChallenge = useCallback(async () => {
    setIsLoading(true);
    setInput('');
    setError(false);
    onVerify({ verified: false, token: '', answer: '' });

    const newCode = generateCode();
    setCode(newCode);

    try {
      const res = await fetch('/api/v1/captcha/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: newCode }),
      });
      const data = await res.json();
      setToken(data.token || '');
    } catch {
      setToken('');
    } finally {
      setIsLoading(false);
    }
  }, [generateCode, onVerify]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchChallenge();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCheck = (val: string) => {
    const upper = val.toUpperCase();
    setInput(upper);
    const isMatch = upper === code;
    if (isMatch) {
      setError(false);
      onVerify({ verified: true, token, answer: upper });
    } else {
      onVerify({ verified: false, token, answer: upper });
      if (upper.length >= code.length) setError(true);
    }
  };

  return (
    <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
      <div className="flex items-center gap-3">
        <div className="bg-slate-900 text-white px-4 py-2 rounded-lg font-bold tracking-[0.2em] italic text-base select-none border border-slate-800 shadow-inner min-w-[120px] text-center">
          {isLoading ? '······' : code}
        </div>
        <button
          type="button"
          onClick={fetchChallenge}
          disabled={isLoading}
          aria-label="Refresh captcha"
          className="p-2 text-slate-400 hover:text-slate-900 transition-colors disabled:opacity-50 shrink-0"
        >
          <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
        </button>
        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-auto shrink-0">Verify</span>
      </div>
      <input
        type="text"
        placeholder="Enter the code above"
        value={input}
        onChange={(e) => handleCheck(e.target.value)}
        className={`w-full p-3 bg-white border rounded-xl text-sm font-bold focus:outline-none transition-all ${
          error ? 'border-red-500 ring-4 ring-red-500/10' : 'border-black/5 focus:ring-4 focus:ring-primary/10'
        }`}
      />
    </div>
  );
};

export default Captcha;
