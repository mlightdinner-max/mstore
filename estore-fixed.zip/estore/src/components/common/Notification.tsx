import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface NotificationProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

const Notification = ({ message, type, onClose }: NotificationProps) => {
  const colors = {
    success: 'bg-primary/80 text-white shadow-primary-dark/20',
    error: 'bg-rose-500 text-white shadow-rose-950/20',
    info: 'bg-slate-900 text-white shadow-slate-950/20'
  };

  const icons = {
    success: <CheckCircle2 size={18} />,
    error: <AlertCircle size={18} />,
    info: <Info size={18} />
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 50, scale: 0.9 }}
      className={`fixed bottom-8 right-8 z-[300] flex items-center gap-4 px-6 py-4 rounded-2xl shadow-2xl border border-white/10 backdrop-blur-md ${colors[type]}`}
    >
      <div className="p-2 bg-white/20 rounded-xl">
        {icons[type]}
      </div>
      <p className="text-xs font-medium uppercase tracking-wider">{message}</p>
      <button 
        onClick={onClose}
        className="p-1.5 hover:bg-white/10 rounded-lg transition-colors ml-2"
      >
        <X size={16} />
      </button>
    </motion.div>
  );
};

export default Notification;
