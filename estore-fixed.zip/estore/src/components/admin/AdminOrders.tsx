import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronDown, 
  Package, RefreshCw, 
  X, User, ShoppingBag, MapPin, Phone, Mail, 
  Calendar, ShieldAlert, Globe, ArrowLeft, History, ShoppingCart, Bot, CheckCircle2, AlertTriangle, Clock, XCircle
} from 'lucide-react';
import { Order, AIAlert } from '../../types';
import { LOCALIZATION } from '../../constants';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

// ── Agent Status Badge ─────────────────────────────────────────────────────

type AgentStatus = string | undefined;

const AGENT_STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending_confirmation:  { label: 'Awaiting Confirmation', color: 'bg-amber-50 text-amber-700 border border-amber-200',    icon: <Clock size={10} /> },
  placing:               { label: 'Placing on Meesho…',   color: 'bg-blue-50 text-blue-700 border border-blue-200',        icon: <RefreshCw size={10} className="animate-spin" /> },
  placed:                { label: 'Placed on Meesho',     color: 'bg-emerald-50 text-emerald-700 border border-emerald-200', icon: <CheckCircle2 size={10} /> },
  manually_placed:       { label: 'Manually Placed',      color: 'bg-emerald-50 text-emerald-700 border border-emerald-200', icon: <CheckCircle2 size={10} /> },
  failed:                { label: 'Placement Failed',     color: 'bg-rose-50 text-rose-700 border border-rose-200',         icon: <AlertTriangle size={10} /> },
  cancelling:            { label: 'Cancelling…',          color: 'bg-orange-50 text-orange-700 border border-orange-200',  icon: <RefreshCw size={10} className="animate-spin" /> },
  cancelled_on_meesho:   { label: 'Cancelled on Meesho', color: 'bg-slate-100 text-slate-600 border border-slate-200',     icon: <XCircle size={10} /> },
  cancel_failed:         { label: 'Cancel Failed',        color: 'bg-rose-50 text-rose-700 border border-rose-200',         icon: <AlertTriangle size={10} /> },
  returning:             { label: 'Initiating Return…',  color: 'bg-purple-50 text-purple-700 border border-purple-200',   icon: <RefreshCw size={10} className="animate-spin" /> },
  return_initiated:      { label: 'Return Initiated',     color: 'bg-purple-50 text-purple-700 border border-purple-200',  icon: <CheckCircle2 size={10} /> },
  return_failed:         { label: 'Return Failed',        color: 'bg-rose-50 text-rose-700 border border-rose-200',         icon: <AlertTriangle size={10} /> },
};

function AgentStatusBadge({ status, compact = false }: { status: AgentStatus; compact?: boolean }) {
  if (!status) return null;
  const cfg = AGENT_STATUS_CONFIG[status];
  if (!cfg) return null;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${cfg.color}`}>
      {cfg.icon}
      {!compact && cfg.label}
      {compact && cfg.label.split(' ')[0]}
    </span>
  );
}

// ── Manual Meesho ID Entry ─────────────────────────────────────────────────

function ManualMeeshoIdEntry({ orderId, currentMeeshoId, onSave }: {
  orderId: string;
  currentMeeshoId?: string;
  onSave: (meeshoId: string) => Promise<void>;
}) {
  const [editing, setEditing]   = useState(false);
  const [value,   setValue]     = useState(currentMeeshoId ?? '');
  const [saving,  setSaving]    = useState(false);

  if (!editing) {
    return (
      <button
        onClick={() => setEditing(true)}
        className="text-xs font-bold text-blue-600 hover:underline mt-1"
      >
        {currentMeeshoId ? 'Edit Meesho Order ID' : '+ Enter Meesho Order ID manually'}
      </button>
    );
  }

  return (
    <div className="flex items-center gap-2 mt-2">
      <input
        autoFocus
        value={value}
        onChange={e => setValue(e.target.value)}
        placeholder="Meesho order ID"
        className="flex-1 px-3 py-2 text-xs font-mono border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5"
      />
      <button
        disabled={!value.trim() || saving}
        onClick={async () => {
          setSaving(true);
          await onSave(value.trim());
          setEditing(false);
          setSaving(false);
        }}
        className="px-3 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl disabled:opacity-50"
      >
        {saving ? '…' : 'Save'}
      </button>
      <button onClick={() => setEditing(false)} className="px-3 py-2 text-xs font-bold text-slate-500 hover:text-slate-700">
        Cancel
      </button>
    </div>
  );
}

interface AdminOrdersProps {
  orders: Order[];
  onUpdateStatus: (id: string, status: string, customDate?: string, reason?: string, initiator?: string, eta?: string) => void;
  onUpdateItemStatus: (orderId: string, itemId: string, status: string, reason?: string, date?: string, eta?: string) => void;
  config: any;
  alerts: AIAlert[];
  setActiveTab?: (t: string) => void;
  user: any;
  token?: string | null;
  externalStatusFilter?: string | null;
  onClearExternalFilter?: () => void;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  externalSelectedOrderId?: string | null;
  onClearExternalSelection?: () => void;
  onNavigateToCustomer?: (customerId: string) => void;
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

const AdminOrders = ({ 
  orders, 
  onUpdateStatus: _onUpdateStatus, 
  onUpdateItemStatus,
  config: _config,
  alerts: _alerts, 
  user,
  token,
  externalStatusFilter, 
  onShowNotification,
  externalSelectedOrderId,
  onClearExternalSelection,
  onNavigateToCustomer
}: AdminOrdersProps) => {
  const { id: routeOrderId } = useParams();
  const navigate = useNavigate();
  const [statusFilter, setStatusFilter] = useState<string>(externalStatusFilter || 'All');
  const [prevExternalStatusFilter, setPrevExternalStatusFilter] = useState(externalStatusFilter);

  const [searchQuery, setSearchQuery] = useState('');
  const [aiFlaggedOnly, setAiFlaggedOnly] = useState(false);
  const [aiNotFlaggedOnly, setAiNotFlaggedOnly] = useState(false);
  const [isAiValidatedOnly, setIsAiValidatedOnly] = useState(false);
  const [repeatCustomersOnly, setRepeatCustomersOnly] = useState(false);
  const [sourceFilter, setSourceFilter] = useState('All');
  const [cityFilter, setCityFilter] = useState('All');
  const [pincodeFilter, setPincodeFilter] = useState('');
  const [orderValueRange] = useState({ min: 0, max: 1000000 });

  const [dateFilter, setDateFilter] = useState('all');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [sortBy, setSortBy] = useState('date-desc');

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 25;
  
  const handleUpdateStatus = () => {
    if (!statusUpdate) return;
    
    const statusConfig = (_config.orderStatuses || []).find((s: any) => s.label === statusUpdate.status);
    const isCurrentlyClosed = selectedOrder?.status === 'CLOSED';
    
    if (statusUpdate.status === 'Shipped' && !statusUpdate.eta) {
      onShowNotification("An ETA date is required when updating to Shipped status.", "error");
      return;
    }

    if ((statusConfig?.requiresNote || isCurrentlyClosed) && !statusUpdate.reason) {
      onShowNotification(isCurrentlyClosed ? "A reason/note is required for reopening a closed order." : "A reason/note is required for this status change.", "error");
      return;
    }
    
    _onUpdateStatus(
      statusUpdate.orderId, 
      statusUpdate.status, 
      statusUpdate.date, 
      statusUpdate.reason, 
      user?.name,
      statusUpdate.eta
    );
    setStatusUpdate(null);
  };

  const handleUpdateItemStatus = () => {
    if (!itemStatusUpdate) return;
    
    if (itemStatusUpdate.status === 'Shipped' && !itemStatusUpdate.eta) {
      onShowNotification("An ETA date is required when updating an item to Shipped status.", "error");
      return;
    }

    onUpdateItemStatus(
      itemStatusUpdate.orderId,
      itemStatusUpdate.itemId,
      itemStatusUpdate.status as any,
      itemStatusUpdate.reason,
      itemStatusUpdate.date,
      itemStatusUpdate.eta
    );
    setItemStatusUpdate(null);
  };


  const [statusUpdate, setStatusUpdate] = useState<{
    orderId: string, 
    status: string, 
    date?: string, 
    eta?: string,
    reason?: string
  } | null>(null);

  const [itemStatusUpdate, setItemStatusUpdate] = useState<{
    orderId: string,
    itemId: string,
    status: string,
    date?: string,
    eta?: string,
    reason?: string
  } | null>(null);

  // eslint-disable-next-line react-hooks/preserve-manual-memoization
  const selectedOrder = useMemo(() => {
    if (externalSelectedOrderId) {
      return orders.find(o => o.id === externalSelectedOrderId) || null;
    }
    if (routeOrderId) {
      return orders.find(o => o.id === routeOrderId) || null;
    }
    return null;
  }, [routeOrderId, externalSelectedOrderId, orders]);

  // Handle clearing external selection if needed
  React.useEffect(() => {
    if (externalSelectedOrderId && selectedOrder && onClearExternalSelection) {
      onClearExternalSelection();
    }
  }, [externalSelectedOrderId, selectedOrder, onClearExternalSelection]);

  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const isAdmin = user?.role === 'Admin' || user?.role === 'Super Admin';

  if (externalStatusFilter !== prevExternalStatusFilter) {
    setPrevExternalStatusFilter(externalStatusFilter);
    setStatusFilter(externalStatusFilter || 'All');
    setCurrentPage(1);
  }

  const dateRanges = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const last7 = new Date(today);
    last7.setDate(last7.getDate() - 7);
    const last30 = new Date(today);
    last30.setDate(last30.getDate() - 30);
    const last90 = new Date(today);
    last90.setDate(last90.getDate() - 90);
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    return { today, yesterday, last7, last30, last90, thisMonth };
  }, []);

  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      const matchesSearch = 
        order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.items.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStatus = statusFilter === 'All' || order.status === statusFilter;
      const matchesSource = sourceFilter === 'All' || order.source === sourceFilter;
      const matchesCity = cityFilter === 'All' || order.city === cityFilter;
      const matchesPincode = !pincodeFilter || (order.zip || '').includes(pincodeFilter);
      const matchesOrderValue = (order.total ?? 0) >= orderValueRange.min && (order.total ?? 0) <= orderValueRange.max;

      const orderDate = new Date(order.createdAt);
      let matchesDate = true;
      if (dateFilter === 'today') matchesDate = orderDate >= dateRanges.today;
      else if (dateFilter === 'yesterday') matchesDate = orderDate >= dateRanges.yesterday && orderDate < dateRanges.today;
      else if (dateFilter === '7days') matchesDate = orderDate >= dateRanges.last7;
      else if (dateFilter === '30days') matchesDate = orderDate >= dateRanges.last30;
      else if (dateFilter === '90days') matchesDate = orderDate >= dateRanges.last90;
      else if (dateFilter === 'thisMonth') matchesDate = orderDate >= dateRanges.thisMonth;
      else if (dateFilter === 'custom' && customStartDate && customEndDate) {
        matchesDate = orderDate >= new Date(customStartDate) && orderDate <= new Date(customEndDate);
      }

      const matchesAiFlagged = !aiFlaggedOnly || (order as any).isAiFlagged;
      const matchesAiNotFlagged = !aiNotFlaggedOnly || !(order as any).isAiFlagged;
      const matchesAiValidated = !isAiValidatedOnly || (order as any).isAiValidated;
      const matchesRepeatCustomer = !repeatCustomersOnly || order.customerType === 'Repeat';

      return matchesSearch && matchesStatus && matchesSource && matchesCity && 
             matchesPincode && matchesOrderValue && matchesDate && 
             matchesAiFlagged && matchesAiNotFlagged && matchesAiValidated && 
             matchesRepeatCustomer;
    }).sort((a, b) => {
      if (sortBy === 'date-desc') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'date-asc') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'amount-desc') return (b.total ?? 0) - (a.total ?? 0);
      if (sortBy === 'amount-asc') return (a.total ?? 0) - (b.total ?? 0);
      return 0;
    });
  }, [orders, searchQuery, statusFilter, sourceFilter, cityFilter, pincodeFilter, orderValueRange, dateFilter, customStartDate, customEndDate, dateRanges, aiFlaggedOnly, aiNotFlaggedOnly, isAiValidatedOnly, repeatCustomersOnly, sortBy]);

  const pagedOrders = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredOrders.slice(start, start + itemsPerPage);
  }, [filteredOrders, currentPage]);

  const basePath = window.location.pathname.startsWith('/home') ? '/home' : window.location.pathname.includes('/affiliate') ? '/affiliate' : '/home';

  if (routeOrderId && selectedOrder) {
    return (
      <AdminPageWrapper
        title={`Order Details`}
        description={`Viewing detailed information for order #${selectedOrder.id}`}
        icon={ShoppingBag}
        actions={
          <button 
            onClick={() => navigate(`${basePath}/orders`)}
            className="flex items-center space-x-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg active:scale-95 group"
          >
            <ArrowLeft size={16} />
            <span>Back to Orders</span>
          </button>
        }
      >
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200">
           <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-10">
                {selectedOrder.reopenReason && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-amber-50 border-2 border-amber-200 p-6 rounded-2xl flex items-start gap-4 shadow-sm"
                  >
                    <ShieldAlert className="text-amber-600 shrink-0 mt-1" size={24} />
                    <div className="space-y-1">
                      <p className="text-xs font-medium uppercase tracking-wider text-amber-700">Order Reopened Warning</p>
                      <p className="text-sm font-black text-slate-900 leading-tight">This order was previously closed and has been reopened by a Super Admin.</p>
                      <div className="mt-2 text-xs font-bold text-slate-600 bg-white/60 p-3 rounded-xl border border-amber-100">
                        Reason: {selectedOrder.reopenReason}
                      </div>
                    </div>
                  </motion.div>
                )}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                  <div className="lg:col-span-2 space-y-8">
                    <div className="space-y-4">
                      <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                        <Package size={16} className="text-blue-500" />
                        Order Items
                      </h3>
                      <div className="space-y-4">
                        {selectedOrder.items.map((item, idx) => (
                          <div key={item.id + idx} className="flex flex-col gap-4 p-5 bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                            <div className="flex items-center gap-5">
                              <div className="w-20 h-20 bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden flex-shrink-0 relative group-hover:scale-105 transition-transform duration-500">
                                {item.image ? (
                                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-slate-300">
                                    <Package size={28} />
                                  </div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-black text-slate-950 uppercase tracking-tight truncate">{item.name}</p>
                                <div className="flex items-center gap-3 mt-1">
                                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Qty: {item.quantity}</p>
                                  <div className="w-1 h-1 rounded-full bg-slate-200" />
                                  <p className="text-xs text-primary font-medium uppercase tracking-wider">{LOCALIZATION.CURRENCY}{(item.price ?? 0).toLocaleString()}</p>
                                  {item.originalCostAtPurchase > 0 && isAdmin && (
                                    <>
                                      <div className="w-1 h-1 rounded-full bg-slate-200" />
                                      <p className="text-xs text-emerald-600 font-medium uppercase tracking-wider">Cost: {LOCALIZATION.CURRENCY}{item.originalCostAtPurchase.toLocaleString()}</p>
                                    </>
                                  )}
                                </div>
                                {item.sourceUrl && isAdmin && (
                                  <a 
                                    href={item.sourceUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-xs text-blue-500 font-bold uppercase tracking-widest hover:underline flex items-center gap-1 mt-1.5"
                                  >
                                    <Globe size={10} />
                                    Source Reference
                                  </a>
                                )}
                              </div>
                              </div>
                              <div className="text-right flex flex-col items-end gap-2">
                                <p className="text-sm font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{(item.price * item.quantity).toLocaleString()}</p>
                                <div className={`px-2.5 py-1 rounded-lg text-xs font-medium uppercase tracking-wider border ${
                                  item.status === 'Delivered' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                                  item.status === 'Cancelled' ? 'bg-rose-50 text-rose-600 border-rose-100' :
                                  item.status === 'Returned' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                                  item.status === 'Return Requested' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                                  item.status === 'Return Rejected' ? 'bg-slate-50 text-slate-500 border-slate-200' :
                                  'bg-blue-50 text-blue-600 border-blue-100'
                                }`}>
                                  {item.status || 'Pending'}
                                </div>

                                {isAdmin && selectedOrder.status !== 'CLOSED' && (
                                  <div className="flex flex-col items-end gap-2 mt-1">
                                    {item.status === 'Return Requested' ? (
                                      <div className="flex gap-2">
                                        <button 
                                          onClick={() => setItemStatusUpdate({
                                            orderId: selectedOrder.id,
                                            itemId: item.id,
                                            status: 'Returned',
                                            reason: 'Admin approved return request',
                                            date: new Date().toISOString()
                                          })}
                                          className="px-2 py-1 bg-emerald-600 text-white rounded text-xs font-medium uppercase tracking-wider hover:bg-emerald-700 transition-all shadow-sm"
                                        >
                                          Approve
                                        </button>
                                        <button 
                                          onClick={() => setItemStatusUpdate({
                                            orderId: selectedOrder.id,
                                            itemId: item.id,
                                            status: 'Return Rejected',
                                            reason: 'Admin rejected return request',
                                            date: new Date().toISOString()
                                          })}
                                          className="px-2 py-1 bg-rose-600 text-white rounded text-xs font-medium uppercase tracking-wider hover:bg-rose-700 transition-all shadow-sm"
                                        >
                                          Reject
                                        </button>
                                      </div>
                                    ) : (
                                      (selectedOrder.status !== 'Completed' || user?.role === 'Super Admin') && (
                                        <div className="relative group/status">
                                          <button className="text-xs font-medium uppercase tracking-wider text-slate-400 hover:text-slate-950 transition-colors flex items-center gap-1.5 py-1 px-2 border border-slate-100 rounded-lg hover:bg-slate-50">
                                            Update Status
                                            <ChevronDown size={10} />
                                          </button>
                                          <div className="absolute right-0 top-full mt-1 hidden group-hover/status:block z-[40] bg-white border border-slate-200 rounded-xl shadow-xl p-1.5 min-w-[140px]">
                                            {['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled', 'Returned'].map(s => (
                                              <button
                                                key={s}
                                                onClick={() => setItemStatusUpdate({
                                                  orderId: selectedOrder.id,
                                                  itemId: item.id,
                                                  status: s,
                                                  reason: `Manual status adjustment to ${s}`,
                                                  date: new Date().toISOString(),
                                                  ...(s === 'Shipped' ? { eta: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString() } : {})
                                                })}
                                                className={`w-full text-left px-3 py-2 text-xs font-medium uppercase tracking-wider rounded-lg transition-colors mb-0.5 last:mb-0 ${
                                                  item.status === s ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                                                }`}
                                              >
                                                {s}
                                              </button>
                                            ))}
                                          </div>
                                        </div>
                                      )
                                    )}
                                  </div>
                                )}
                              </div>

                            {item.statusHistory && item.statusHistory.length > 0 && (
                              <div className="mt-2 pt-4 border-t border-slate-100">
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const el = document.getElementById(`history-${item.id}-${idx}`);
                                    if (el) {
                                      el.classList.toggle('hidden');
                                      e.currentTarget.classList.toggle('text-slate-900');
                                    }
                                  }}
                                  className="text-xs font-medium uppercase tracking-wider text-slate-400 hover:text-slate-900 transition-colors flex items-center justify-between w-full outline-none py-1 group/btn"
                                >
                                  <span className="flex items-center gap-2">
                                    <History size={12} className="group-hover/btn:rotate-[-45deg] transition-transform" />
                                    View Detailed Item History
                                  </span>
                                  <span className="bg-slate-100 px-2 py-0.5 rounded-full text-xs">{item.statusHistory.length} logs</span>
                                </button>
                                <div id={`history-${item.id}-${idx}`} className="hidden mt-4 space-y-4 pl-4 border-l-2 border-slate-100 py-1">
                                  {item.statusHistory.slice().reverse().map((h, hIdx) => (
                                    <div key={hIdx} className="relative">
                                      <div className="absolute -left-[1.35rem] top-1.5 w-2 h-2 rounded-full border-2 border-slate-50 bg-slate-950" />
                                      <div className="space-y-1.5">
                                        <div className="flex items-center justify-between gap-4">
                                          <span className="text-xs font-black text-slate-950 uppercase tracking-tight">{h.status}</span>
                                          <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                                            {new Date(h.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                                          </span>
                                        </div>
                                        {h.reason && (
                                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/50">
                                            <p className="text-xs text-slate-600 font-bold leading-relaxed italic">
                                              "{h.reason}"
                                            </p>
                                          </div>
                                        )}
                                        {h.updatedBy && (
                                          <div className="flex items-center gap-1.5 px-1">
                                            <User size={8} className="text-slate-400" />
                                            <span className="text-[7.5px] text-slate-400 uppercase tracking-widest font-black">Logged By: {h.updatedBy}</span>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-6 bg-slate-900 rounded-2xl text-white space-y-4 shadow-xl">
                      <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400">Order Summary</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs font-medium text-slate-300">
                          <span>Subtotal</span>
                          <span>{LOCALIZATION.CURRENCY}{selectedOrder.items.reduce((sum, i) => sum + (i.price * i.quantity), 0).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs font-medium text-slate-300">
                          <span>Delivery Fee</span>
                          <span>{LOCALIZATION.CURRENCY}{selectedOrder.shippingFee?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="pt-2 border-t border-slate-800 flex justify-between text-base font-medium uppercase tracking-wider">
                          <span>Final Total</span>
                          <span className="text-blue-400">{LOCALIZATION.CURRENCY}{(selectedOrder.total ?? 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-8">
                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6">
                      <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-3">Admin Actions</h3>
                      
                      <div className="space-y-3">
                        <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Overall Order Lifecycle</label>
                        <div className="p-4 bg-white border border-slate-200 rounded-2xl flex items-center justify-between group">
                          <div className="flex items-center gap-3">
                            <RefreshCw size={14} className={`text-blue-500 ${selectedOrder.status === 'Processing' ? 'animate-spin' : ''}`} />
                            <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{selectedOrder.status}</p>
                          </div>
                        </div>
                        
                        {selectedOrder.status === 'CLOSED' && user?.role === 'Super Admin' && (
                          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-3">
                            <div className="p-5 border-2 border-amber-200 bg-amber-50 rounded-2xl space-y-4">
                              <p className="text-xs font-black uppercase text-amber-700 tracking-widest">Reopen Order Control</p>
                              <div className="space-y-2">
                                <label className="text-xs font-medium uppercase tracking-wider text-amber-600/60 ml-1">Reopen Reason (Required)</label>
                                <textarea 
                                  placeholder="Why is this closed order being reopened?"
                                  value={statusUpdate?.reason || ''}
                                  onChange={(e) => setStatusUpdate({ 
                                    orderId: selectedOrder.id, 
                                    status: 'OPEN', 
                                    reason: e.target.value,
                                    date: new Date().toISOString()
                                  })}
                                  className={`w-full px-4 py-3 bg-white border border-amber-200 rounded-xl text-xs font-bold outline-none min-h-[80px] shadow-sm ${!statusUpdate?.reason ? 'border-amber-300' : 'border-amber-400'}`}
                                />
                              </div>
                              <button 
                                onClick={handleUpdateStatus}
                                disabled={!statusUpdate?.reason}
                                className="w-full py-3 bg-amber-600 text-white rounded-xl text-xs font-medium uppercase tracking-wider shadow-lg shadow-amber-600/20 hover:bg-amber-700 transition-all disabled:opacity-50"
                              >
                                Confirm Reopen
                              </button>
                            </div>
                          </motion.div>
                        )}
                        
                        <p className="text-xs text-slate-400 font-bold leading-relaxed px-1">
                          {selectedOrder.status === 'CLOSED' 
                            ? "This order is final. Reopening is restricted to Super Admins and requires justification."
                            : "Overall status is managed automatically based on individual item states."}
                        </p>
                        
                        <div className="pt-4 border-t border-slate-200 mt-4 space-y-3">
                           <h4 className="text-xs font-medium uppercase tracking-wider text-slate-400">Order Security Checks</h4>
                           <div className="flex flex-wrap gap-2 items-center">
                              {(selectedOrder as any).isAiFlagged && (
                                <div className="px-3 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-medium uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-rose-600/20">
                                  <ShieldAlert size={12} />
                                  <span>AI Security Flagged</span>
                                </div>
                              )}
                              {(selectedOrder as any).isAiValidated ? (
                                <div className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-medium uppercase tracking-wider border border-indigo-100 flex items-center gap-1.5">
                                  <ShieldAlert size={12} />
                                  <span>AI Check Passed</span>
                                </div>
                              ) : (selectedOrder as any).systemTags && (selectedOrder as any).systemTags.length > 0 ? (
                                <div className="px-3 py-1.5 bg-amber-50 text-amber-600 rounded-xl text-xs font-medium uppercase tracking-wider border border-amber-100 flex items-center gap-1.5">
                                  <ShieldAlert size={12} />
                                  <span>Passed Without AI (Fallback)</span>
                                </div>
                              ) : (
                                <div className="px-3 py-1.5 bg-slate-50 text-slate-600 rounded-xl text-xs font-medium uppercase tracking-wider border border-slate-200 flex items-center gap-1.5">
                                  <ShieldAlert size={12} />
                                  <span>No AI Check Executed</span>
                                </div>
                              )}
                           </div>
                        </div>
                      </div>
                    </div>

                    {/* ── Meesho Fulfilment Status ─────────────────────────── */}
                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                      <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-3 flex items-center gap-2">
                        <ShoppingCart size={14} />
                        Meesho Fulfilment
                      </h3>
                      <div className="flex flex-wrap items-center gap-3">
                        <AgentStatusBadge status={(selectedOrder as any).agentStatus} />
                        {(selectedOrder as any).meeshoOrderId && (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-500 font-medium">Meesho Order:</span>
                            {(selectedOrder as any).meeshoOrderUrl ? (
                              <a
                                href={(selectedOrder as any).meeshoOrderUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs font-mono font-bold text-blue-600 hover:underline"
                              >
                                {(selectedOrder as any).meeshoOrderId}
                              </a>
                            ) : (
                              <span className="text-xs font-mono font-bold text-slate-800">
                                {(selectedOrder as any).meeshoOrderId}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                      {(selectedOrder as any).agentError && (
                        <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs text-rose-700 font-medium">
                          <span className="font-black">Last error: </span>{(selectedOrder as any).agentError}
                        </div>
                      )}
                      {(selectedOrder as any).agentAttempts > 0 && (
                        <p className="text-xs text-slate-400 font-medium">
                          Attempts: {(selectedOrder as any).agentAttempts} · Last tried: {(selectedOrder as any).agentLastAttemptAt ? new Date((selectedOrder as any).agentLastAttemptAt).toLocaleString('en-IN') : '—'}
                        </p>
                      )}
                      {/* Manual Meesho order ID entry */}
                      {isAdmin && !['placed', 'manually_placed', 'cancelled_on_meesho', 'return_initiated'].includes((selectedOrder as any).agentStatus) && (
                        <ManualMeeshoIdEntry
                          orderId={selectedOrder.id}
                          currentMeeshoId={(selectedOrder as any).meeshoOrderId}
                          onSave={async (meeshoId) => {
                            await fetch(`/api/v1/orders/${selectedOrder.id}/agent`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
                              body: JSON.stringify({ agentStatus: 'manually_placed', meeshoOrderId: meeshoId }),
                            });
                            onShowNotification('Meesho order ID saved', 'success');
                          }}
                        />
                      )}
                    </div>

                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6">
                      <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-3">Customer Information</h3>
                      <div className="space-y-6">
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-white shrink-0">
                            <User size={18} />
                          </div>
                          <div>
                            <p className="text-xs font-black text-slate-950 uppercase">{selectedOrder.customerName}</p>
                            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{selectedOrder.customerType === 'Repeat' ? 'Repeat Customer' : 'New Customer'}</p>
                            <button 
                              onClick={() => onNavigateToCustomer?.(selectedOrder.customerId)}
                              className="text-xs font-medium text-blue-500 uppercase tracking-wider mt-1 hover:underline"
                            >
                              View Customer Profile
                            </button>
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <div className="flex items-center gap-3 text-slate-600">
                            <Mail size={14} className="text-slate-400" />
                            <span className="text-xs font-bold">{selectedOrder.email}</span>
                          </div>
                          <div className="flex items-center gap-3 text-slate-600">
                            <Phone size={14} className="text-slate-400" />
                            <span className="text-xs font-bold">{selectedOrder.phone}</span>
                          </div>
                          <div className="flex items-start gap-3 text-slate-600">
                            <MapPin size={14} className="text-slate-400 shrink-0 mt-0.5" />
                            <span className="text-xs font-bold leading-relaxed">
                              {selectedOrder.address}<br />
                              {selectedOrder.city}, {selectedOrder.state} - {selectedOrder.zip}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <AnimatePresence>
                  {itemStatusUpdate && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
                    >
                      <div className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl">
                        <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                          <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Update Item Status</h3>
                          <button onClick={() => setItemStatusUpdate(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                            <X size={20} />
                          </button>
                        </div>
                        <div className="p-8 space-y-6">
                          <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                            <div className="w-12 h-12 rounded-lg bg-white border border-slate-200 overflow-hidden shadow-sm">
                              <img 
                                src={selectedOrder.items.find(i => i.id === itemStatusUpdate.itemId)?.image || undefined} 
                                alt="" 
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-black uppercase text-slate-950 truncate">
                                {selectedOrder.items.find(i => i.id === itemStatusUpdate.itemId)?.name}
                              </p>
                              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mt-0.5">
                                Updating to <span className="text-blue-600 font-black">{itemStatusUpdate.status}</span>
                              </p>
                            </div>
                          </div>
                          
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Event Timestamp (Optional)</label>
                              <input 
                                type="date" 
                                value={itemStatusUpdate.date ? new Date(new Date(itemStatusUpdate.date).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 10) : ''}
                                onChange={(e) => setItemStatusUpdate({ ...itemStatusUpdate, date: e.target.value ? new Date(e.target.value).toISOString() : undefined })}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all font-mono"
                              />
                            </div>
                            {itemStatusUpdate.status === 'Shipped' && (
                              <div className="space-y-2">
                                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Estimated Delivery Date (ETA)</label>
                                <input 
                                  type="date"
                                  value={itemStatusUpdate.eta ? new Date(new Date(itemStatusUpdate.eta).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 10) : ''}
                                  onChange={(e) => setItemStatusUpdate({ ...itemStatusUpdate, eta: e.target.value ? new Date(e.target.value).toISOString() : undefined })}
                                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all font-mono"
                                  required
                                />
                              </div>
                            )}
                            <div className="space-y-2">
                              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Mandatory Timeline Note</label>
                              <textarea 
                                placeholder="Explain the reason for this manual item update (this will be tracked in history)..."
                                value={itemStatusUpdate.reason || ''}
                                onChange={(e) => setItemStatusUpdate({ ...itemStatusUpdate, reason: e.target.value })}
                                className={`w-full px-4 py-3 bg-slate-50 border rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all resize-none min-h-[100px] ${!itemStatusUpdate.reason ? 'border-rose-300' : 'border-slate-200'}`}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                          <button onClick={() => setItemStatusUpdate(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                          <button 
                            onClick={handleUpdateItemStatus}
                            disabled={!itemStatusUpdate.reason}
                            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            Commit Status Change
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
           </div>
        </div>
      </AdminPageWrapper>
    );
  }

  // REST OF THE FILE (List view) ...
  return (
    <AdminPageWrapper
      title="Orders"
      description="Process orders, update statuses, and manage tracking"
      icon={ShoppingBag}
      toolbar={
        <AdminToolbar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          showAdvanced={showAdvancedFilters}
          setShowAdvanced={setShowAdvancedFilters}
          filters={
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setStatusFilter('All')}
                className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all ${statusFilter === 'All' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-50 text-slate-500 hover:text-slate-900'}`}
              >
                All
              </button>
              {[
                { label: 'Open', value: 'OPEN' },
                { label: 'Processing', value: 'Processing' },
                { label: 'Shipped', value: 'Shipped' },
                { label: 'Waiting to Close', value: 'WAITING TO CLOSE' },
                { label: 'Closed', value: 'CLOSED' }
              ].map(s => (
                <button
                  key={s.value}
                  onClick={() => setStatusFilter(s.value)}
                  className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all ${statusFilter === s.value ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-50 text-slate-500 hover:text-slate-900'}`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          }
          advancedFilters={
            <div className="space-y-6 px-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Status Filter</label>
                  <select 
                    value={statusFilter} 
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all appearance-none uppercase tracking-widest"
                  >
                    <option value="All">All Statuses</option>
                    {[
                      { label: 'Open', value: 'OPEN' },
                      { label: 'Processing', value: 'Processing' },
                      { label: 'Shipped', value: 'Shipped' },
                      { label: 'Waiting to Close', value: 'WAITING TO CLOSE' },
                      { label: 'Closed', value: 'CLOSED' }
                    ].map(s => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Source Partner</label>
                  <select 
                    value={sourceFilter} 
                    onChange={(e) => setSourceFilter(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all appearance-none uppercase tracking-widest"
                  >
                    <option value="All">All Sources</option>
                    <option value="Direct">Direct Store</option>
                    <option value="Amazon">Amazon</option>
                    <option value="Affiliate">Affiliate</option>
                  </select>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Date Range</label>
                  <select 
                    value={dateFilter} 
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all appearance-none uppercase tracking-widest"
                  >
                    <option value="all">All Time</option>
                    <option value="today">Today</option>
                    <option value="yesterday">Yesterday</option>
                    <option value="last7">Last 7 Days</option>
                    <option value="last30">Last 30 Days</option>
                    <option value="thisMonth">This Month</option>
                    <option value="last90">Last 90 Days</option>
                    <option value="custom">Custom Range</option>
                  </select>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Sorting</label>
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all appearance-none uppercase tracking-widest"
                  >
                    <option value="date-desc">Newest First</option>
                    <option value="date-asc">Oldest First</option>
                    <option value="amount-desc">Value: High to Low</option>
                    <option value="amount-asc">Value: Low to High</option>
                  </select>
                </div>
              </div>

              {dateFilter === 'custom' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Start Date</label>
                    <input type="date" value={customStartDate} onChange={e => setCustomStartDate(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all uppercase tracking-widest" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">End Date</label>
                    <input type="date" value={customEndDate} onChange={e => setCustomEndDate(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all uppercase tracking-widest" />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">City</label>
                  <input type="text" placeholder="Enter city" value={cityFilter === 'All' ? '' : cityFilter} onChange={e => setCityFilter(e.target.value || 'All')} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all placeholder:text-slate-400" />
                </div>
                <div className="space-y-3">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">Pincode</label>
                  <input type="text" placeholder="Enter pincode" value={pincodeFilter} onChange={e => setPincodeFilter(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black outline-none focus:border-slate-950 transition-all placeholder:text-slate-400" />
                </div>
                <div className="space-y-3 md:col-span-2">
                  <label className="text-xs font-medium uppercase tracking-wider text-slate-400 ml-1">AI & Customer Filters</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <input type="checkbox" checked={aiFlaggedOnly} onChange={e => setAiFlaggedOnly(e.target.checked)} className="rounded text-primary focus:ring-primary border-slate-300" />
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-600">AI Flagged</span>
                    </label>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <input type="checkbox" checked={aiNotFlaggedOnly} onChange={e => setAiNotFlaggedOnly(e.target.checked)} className="rounded text-primary focus:ring-primary border-slate-300" />
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-600">AI Not Flagged</span>
                    </label>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <input type="checkbox" checked={isAiValidatedOnly} onChange={e => setIsAiValidatedOnly(e.target.checked)} className="rounded text-primary focus:ring-primary border-slate-300" />
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-600">AI Validated</span>
                    </label>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <input type="checkbox" checked={repeatCustomersOnly} onChange={e => setRepeatCustomersOnly(e.target.checked)} className="rounded text-primary focus:ring-primary border-slate-300" />
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-600">Repeat Customers</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex items-end pt-4 border-t border-slate-100">
                <button 
                  onClick={() => {
                    setStatusFilter('All');
                    setSourceFilter('All');
                    setSearchQuery('');
                    setSortBy('date-desc');
                    setDateFilter('all');
                    setCityFilter('All');
                    setPincodeFilter('');
                    setAiFlaggedOnly(false);
                    setAiNotFlaggedOnly(false);
                    setIsAiValidatedOnly(false);
                    setRepeatCustomersOnly(false);
                  }}
                  className="w-full md:w-auto px-8 py-3 bg-slate-100 text-slate-500 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-200 transition-colors"
                >
                  Reset All Filters
                </button>
              </div>
            </div>
          }
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableHead className="text-xs font-medium uppercase tracking-wider text-slate-400 py-6">Order Information</TableHead>
              <TableHead className="text-xs font-medium uppercase tracking-wider text-slate-400">Customer Details</TableHead>
              <TableHead className="text-xs font-medium uppercase tracking-wider text-slate-400">Action Status</TableHead>
              <TableHead className="text-xs font-medium uppercase tracking-wider text-slate-400">Status & Source</TableHead>
              <TableHead className="text-xs font-medium uppercase tracking-wider text-slate-400 text-right pr-8">Total Amount</TableHead>
            </TableHeader>
            <TableBody>
              {pagedOrders.map(order => (
                <TableRow 
                  key={order.id} 
                  className="hover:bg-slate-50/50 transition-colors cursor-pointer group"
                  onClick={() => navigate(`${basePath}/orders/${order.id}`)}
                >
                  <TableCell className="py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-white shrink-0 group-hover:scale-110 transition-transform">
                        <ShoppingBag size={18} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-black text-slate-950 uppercase tracking-tight">#{order.id.slice(0, 8)}</p>
                          {(order as any).isAiFlagged && (
                             <span className="px-1.5 py-0.5 bg-rose-600 text-white rounded text-xs font-medium uppercase tracking-wider flex items-center gap-1 shadow-sm">
                               <ShieldAlert size={8} />
                               AI Flagged
                             </span>
                          )}
                          {(order as any).isAiValidated ? (
                             <span className="px-1.5 py-0.5 bg-indigo-50 text-indigo-600 rounded text-xs font-medium uppercase tracking-wider">AI Validated</span>
                          ) : (order as any).systemTags && (order as any).systemTags.length > 0 ? (
                             <span className="px-1.5 py-0.5 bg-amber-50 text-amber-600 rounded text-xs font-medium uppercase tracking-wider">No AI</span>
                          ) : null}
                          {/* Agent / Meesho fulfilment status */}
                          {(order as any).agentStatus && (
                            <AgentStatusBadge status={(order as any).agentStatus} compact />
                          )}
                          {order.items.some(i => i.status === 'Return Requested') && (
                             <span className="px-1.5 py-0.5 bg-rose-50 text-rose-600 rounded text-xs font-medium uppercase tracking-wider animate-pulse border border-rose-200">Return Req</span>
                          )}
                          {order.items.some(i => i.status === 'Cancellation Requested') && (
                             <span className="px-1.5 py-0.5 bg-amber-50 text-amber-600 rounded text-xs font-medium uppercase tracking-wider animate-pulse border border-amber-200">Cancel Req</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 text-slate-400">
                          <Calendar size={10} />
                          <span className="text-xs font-medium uppercase tracking-wider">{new Date(order.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{order.customerName}</p>
                      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider truncate max-w-[150px]">{order.email}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1 items-start">
                      {order.items.some(i => i.status === 'Cancelled') && (
                        <span className="px-2 py-1 bg-red-50 text-red-600 rounded-md text-xs font-medium uppercase tracking-wider border border-red-100">Item Cancelled</span>
                      )}
                      {order.items.some(i => i.status === 'Return Requested') && (
                        <span className="px-2 py-1 bg-amber-50 text-amber-600 rounded-md text-xs font-medium uppercase tracking-wider border border-amber-100 animate-pulse">Return Requested</span>
                      )}
                      {order.items.some(i => i.status === 'Cancellation Requested') && (
                        <span className="px-2 py-1 bg-amber-50 text-amber-600 rounded-md text-xs font-medium uppercase tracking-wider border border-amber-100 animate-pulse">Cancellation Requested</span>
                      )}
                      {order.items.some(i => i.status === 'Returned') && (
                        <span className="px-2 py-1 bg-purple-50 text-purple-600 rounded-md text-xs font-medium uppercase tracking-wider border border-purple-100">Returned</span>
                      )}
                      {!order.items.some(i => ['Cancelled', 'Return Requested', 'Returned', 'Cancellation Requested'].includes(i.status || '')) && (
                        <span className="text-xs font-bold text-slate-400">-</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-4">
                      <div className={`px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider ${
                        order.status === 'Completed' || order.status === 'Delivered' ? 'bg-emerald-50 text-emerald-600' :
                        order.status === 'Cancelled' || order.status === 'CLOSED' ? 'bg-rose-50 text-rose-600' :
                        'bg-blue-50 text-blue-600'
                      }`}>
                        {order.status}
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-400">
                        <Globe size={10} />
                        <span className="text-xs font-medium uppercase tracking-wider">{order.source}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right pr-8">
                    <p className="text-sm font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{(order.total ?? 0).toLocaleString()}</p>
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{order.items.length} items</p>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {filteredOrders.length > itemsPerPage && (
          <div className="flex items-center justify-between px-8 py-6 bg-white rounded-3xl border border-slate-200">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
              Showing <span className="text-slate-950">{pagedOrders.length}</span> of <span className="text-slate-950">{filteredOrders.length}</span> results
            </p>
            <div className="flex items-center gap-2">
              <button 
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => prev - 1)}
                className="p-2 text-slate-400 hover:text-slate-900 disabled:opacity-50 transition-colors"
              >
                <ChevronDown className="rotate-90" size={16} />
              </button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.ceil(filteredOrders.length / itemsPerPage) }, (_, i) => i + 1).map(p => (
                  <button
                    key={p}
                    onClick={() => setCurrentPage(p)}
                    className={`w-8 h-8 rounded-lg text-xs font-black transition-all ${
                      currentPage === p ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
              <button 
                disabled={currentPage === Math.ceil(filteredOrders.length / itemsPerPage)}
                onClick={() => setCurrentPage(prev => prev + 1)}
                className="p-2 text-slate-400 hover:text-slate-900 disabled:opacity-50 transition-colors"
              >
                <ChevronDown className="-rotate-90" size={16} />
              </button>
            </div>
          </div>
        )}
      {filteredOrders.length === 0 && (
        <div className="py-20 text-center space-y-3">
          <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto text-slate-300">
            <ShoppingBag size={24} />
          </div>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No orders found matching your filters</p>
        </div>
      )}

      {/* Status Update Confirmation Modal */}
      <AnimatePresence>
        {statusUpdate && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Update Status</h3>
                <button onClick={() => setStatusUpdate(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-4">
                  <div className="p-2 bg-blue-500 text-white rounded-lg">
                    <RefreshCw size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Confirm Status Change</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      You are about to change the status of order <span className="text-blue-600 font-bold">#{statusUpdate.orderId.slice(0, 8)}</span> to <span className="text-blue-600 font-bold">{statusUpdate.status}</span>.
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Event Date</label>
                    <input 
                      type="date"
                      value={statusUpdate.date ? new Date(new Date(statusUpdate.date).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 10) : ''}
                      onChange={(e) => setStatusUpdate({ ...statusUpdate, date: e.target.value ? new Date(e.target.value).toISOString() : undefined })}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all font-mono"
                    />
                  </div>
                  {statusUpdate.status === 'Shipped' && (
                    <div className="space-y-2">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Estimated Delivery Date (ETA)</label>
                      <input 
                        type="date"
                        value={statusUpdate.eta ? new Date(new Date(statusUpdate.eta).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 10) : ''}
                        onChange={(e) => setStatusUpdate({ ...statusUpdate, eta: e.target.value ? new Date(e.target.value).toISOString() : undefined })}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all font-mono"
                        required
                      />
                    </div>
                  )}
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">
                      Reason for Change {(_config.orderStatuses || []).find((s: any) => s.label === statusUpdate.status)?.requiresNote ? '(Required)' : '(Optional)'}
                    </label>
                    <textarea 
                      value={statusUpdate.reason || ''}
                      onChange={(e) => setStatusUpdate({ ...statusUpdate, reason: e.target.value })}
                      className={`w-full px-4 py-3 bg-slate-50 border rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all resize-none ${(_config.orderStatuses || []).find((s: any) => s.label === statusUpdate.status)?.requiresNote && !statusUpdate.reason ? 'border-rose-300' : 'border-slate-200'}`}
                      placeholder={(_config.orderStatuses || []).find((s: any) => s.label === statusUpdate.status)?.requiresNote ? "A note is required for this status change..." : "Enter reason..."}
                      rows={3}
                    />
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setStatusUpdate(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={handleUpdateStatus}
                  className="btn-primary"
                >
                  Confirm Update
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default AdminOrders;
