import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LOCALIZATION } from '../../constants';
import { 
  Tag, Plus, Search, Edit2, Trash2, 
  X, Clock, Percent, DollarSign
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface CouponManagementProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  products: any[];
}

const CouponManagement = ({ config, onUpdateConfig, products }: CouponManagementProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<any>(null);
  const [productSearch, setProductSearch] = useState('');
  const [formData, setFormData] = useState({
    code: '',
    type: 'percentage' as 'percentage' | 'fixed',
    value: 0,
    minOrder: 0,
    expiryDate: '',
    usageLimit: 0,
    usageCount: 0,
    status: 'active' as 'active' | 'expired' | 'disabled',
    applicableProducts: [] as string[]
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const coupons = config.coupons || [];

  const handleSave = () => {
    if (!formData.code || formData.value <= 0) return;

    // Prevent duplicate coupon codes (case-insensitive)
    const normalised = formData.code.trim().toUpperCase();
    const duplicate = coupons.find(
      (c: any) => c.code.toUpperCase() === normalised && (!editingCoupon || c.id !== editingCoupon.id)
    );
    if (duplicate) {
      alert(`A coupon with code "${normalised}" already exists. Please use a unique code.`);
      return;
    }

    let newCoupons;
    if (editingCoupon) {
      newCoupons = coupons.map((c: any) => c.id === editingCoupon.id ? { ...formData, code: normalised, id: c.id } : c);
    } else {
      newCoupons = [{ ...formData, code: normalised, id: crypto.randomUUID() }, ...coupons];
    }

    onUpdateConfig({ ...config, coupons: newCoupons });
    resetForm();
  };

  const resetForm = () => {
    setIsAdding(false);
    setEditingCoupon(null);
    setFormData({
      code: '',
      type: 'percentage',
      value: 0,
      minOrder: 0,
      expiryDate: '',
      usageLimit: 0,
      usageCount: 0,
      status: 'active',
      applicableProducts: []
    });
  };

  const handleEdit = (coupon: any) => {
    setEditingCoupon(coupon);
    setFormData(coupon);
    setIsAdding(true);
  };

  const handleDelete = (id: string) => {
    const newCoupons = coupons.filter((c: any) => c.id !== id);
    onUpdateConfig({ ...config, coupons: newCoupons });
  };

  const filteredCoupons = coupons.filter((c: any) => 
    c.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminPageWrapper
      title="Coupons & Offers"
      description="Create and manage discount codes for your store."
      icon={Tag}
      options={[{"label":"New Coupon","description":"Create a new discount code."}]}
      actions={
        <button 
          onClick={() => setIsAdding(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus size={14} />
          <span>New Coupon</span>
        </button>
      }
      toolbar={
        <AdminToolbar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search coupons by code..."
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
        <Table>
          <TableHeader>
            <TableHead>Coupon Code</TableHead>
            <TableHead>Discount</TableHead>
            <TableHead>Usage</TableHead>
            <TableHead>Expiry</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableHeader>
          <TableBody>
            {filteredCoupons.length > 0 ? filteredCoupons.map((coupon: any, idx: number) => (
              <TableRow key={`${coupon.id}-${idx}`}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-slate-400">
                      <Tag size={14} />
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-950 uppercase tracking-tight font-mono">{coupon.code}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Min. Order: {LOCALIZATION.CURRENCY}{coupon.minOrder}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {coupon.type === 'percentage' ? <Percent size={12} className="text-slate-400" /> : <DollarSign size={12} className="text-slate-400" />}
                    <span className="text-xs font-medium uppercase tracking-wider text-slate-900">
                      {coupon.type === 'percentage' ? `${coupon.value}% OFF` : `${LOCALIZATION.CURRENCY}${coupon.value} OFF`}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-slate-400">
                      <span>{coupon.usageCount} / {coupon.usageLimit || '∞'}</span>
                    </div>
                    <div className="w-24 h-1 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${coupon.usageLimit && (coupon.usageCount / coupon.usageLimit) >= 0.9 ? 'bg-rose-500' : 'bg-slate-900'}`} 
                        style={{ width: coupon.usageLimit ? `${Math.min(100, (coupon.usageCount / coupon.usageLimit) * 100)}%` : '0%' }}
                      />
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2 text-slate-500">
                    <Clock size={12} />
                    <span className="text-xs font-medium uppercase tracking-wider">
                      {coupon.expiryDate ? new Date(coupon.expiryDate).toLocaleDateString() : 'No Expiry'}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${coupon.status === 'active' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                    <span className={`text-xs font-medium uppercase tracking-wider ${coupon.status === 'active' ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {coupon.status}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button 
                      onClick={() => handleEdit(coupon)}
                      className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
                      title="Edit Coupon"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button 
                      onClick={() => setShowDeleteConfirm(coupon.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                      title="Delete Coupon"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={6} className="py-12 text-center">
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No coupons found</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  {editingCoupon ? 'Edit Coupon' : 'Create New Coupon'}
                </h2>
                <button onClick={resetForm} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Coupon Code</label>
                    <input 
                      type="text"
                      value={formData.code}
                      onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase().replace(/\s+/g, '') })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all font-mono"
                      placeholder="SUMMER20"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Discount Type</label>
                    <div className="flex bg-slate-50 p-1 rounded-xl">
                      {['percentage', 'fixed'].map((type) => (
                        <button
                          key={type}
                          onClick={() => setFormData({ ...formData, type: type as any })}
                          className={`flex-1 px-4 py-2 rounded-lg text-xs font-medium uppercase tracking-wider transition-all ${
                            formData.type === type ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Value ({formData.type === 'percentage' ? '%' : LOCALIZATION.CURRENCY})</label>
                    <input 
                      type="number"
                      value={formData.value}
                      onChange={e => setFormData({ ...formData, value: parseFloat(e.target.value) })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Min Order Amount</label>
                    <input 
                      type="number"
                      value={formData.minOrder}
                      onChange={e => setFormData({ ...formData, minOrder: parseFloat(e.target.value) })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Usage Limit</label>
                    <input 
                      type="number"
                      value={formData.usageLimit}
                      onChange={e => setFormData({ ...formData, usageLimit: parseInt(e.target.value) })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                      placeholder="0 for unlimited"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Expiry Date</label>
                    <input 
                      type="date"
                      value={formData.expiryDate}
                      onChange={e => setFormData({ ...formData, expiryDate: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Applicable Products (Leave empty for all)</label>
                  <div className="relative mb-2">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                    <input 
                      type="text"
                      placeholder="Search products..."
                      value={productSearch}
                      onChange={(e) => setProductSearch(e.target.value)}
                      className="w-full pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                  <div className="max-h-32 overflow-y-auto border border-slate-200 rounded-xl bg-slate-50 p-2 space-y-1">
                    {products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase())).map(product => (
                      <label key={product.id} className="flex items-center space-x-2 p-2 hover:bg-white rounded-lg cursor-pointer transition-colors">
                        <input
                          type="checkbox"
                          checked={formData.applicableProducts.includes(product.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setFormData({ ...formData, applicableProducts: [...formData.applicableProducts, product.id] });
                            } else {
                              setFormData({ ...formData, applicableProducts: formData.applicableProducts.filter(id => id !== product.id) });
                            }
                          }}
                          className="rounded border-slate-300 text-slate-900 focus:ring-slate-900/20"
                        />
                        <span className="text-xs font-bold text-slate-700">{product.name}</span>
                      </label>
                    ))}
                    {products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase())).length === 0 && (
                      <p className="p-4 text-xs text-slate-400 font-bold uppercase tracking-widest text-center">No products found</p>
                    )}
                  </div>
                </div>
              </div>
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end space-x-3">
                <button 
                  onClick={resetForm}
                  className="px-6 py-2.5 text-xs font-medium uppercase tracking-wider text-slate-500 hover:text-slate-900 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  className="btn-primary"
                >
                  {editingCoupon ? 'Update Coupon' : 'Create Coupon'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Confirm Delete</h3>
                <button onClick={() => setShowDeleteConfirm(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-5 sm:p-8 space-y-5 sm:space-y-6">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex items-start gap-4">
                  <div className="p-2 bg-rose-500 text-white rounded-lg">
                    <Trash2 size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Irreversible Action</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      Are you sure you want to remove this coupon code? This will instantly deactivate the discount for all future orders.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setShowDeleteConfirm(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={() => {
                    handleDelete(showDeleteConfirm);
                    setShowDeleteConfirm(null);
                  }}
                  className="px-8 py-3 bg-rose-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-950/20"
                >
                  Remove Coupon
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default CouponManagement;
