import React from 'react';
import { Sparkles, Trash2, Plus } from 'lucide-react';
import { Config, Product } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';
import { ImageInput } from './ImageInput';

const AdminHomepage = ({ 
  config, 
  onUpdateConfig, 
  products, 
  token, 
  onShowNotification 
}: { 
  config: Config; 
  onUpdateConfig: (c: any) => void; 
  products: Product[];
  token: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}) => {
  return (
    <AdminPageWrapper
      title="Home Page Settings"
      description="Customise the content, banners, and promotional highlights on your storefront homepage."
      options={[{"label":"Manage Banners","description":"Upload and organise hero banners."},{"label":"Promotional Highlights","description":"Edit the key selling points displayed below the banner."}]}
    >
      <div className="space-y-8">
        {/* Banners Section */}
        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h3 className="text-sm font-black flex items-center space-x-3 text-slate-950 uppercase italic tracking-tighter">
                <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
                  <Sparkles size={20} className="text-slate-400" />
                </div>
                <span>Hero Banners</span>
              </h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Add up to 7 high-impact images for your homepage slider.</p>
            </div>
            {(!config.banners || config.banners.length < 7) && (
              <button 
                onClick={() => onUpdateConfig({ ...config, banners: [...(config.banners || []), { image: '', link: '/products' }] })}
                className="btn-primary flex items-center gap-2"
              >
                <Plus size={14} />
                Add Banner
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(config.banners || []).map((banner: any, idx: number) => (
              <div key={idx} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4 group relative shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="w-6 h-6 bg-slate-900 text-white text-xs font-black rounded-lg flex items-center justify-center shadow-lg">{idx + 1}</span>
                    <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Banner Configuration</span>
                  </div>
                  <button 
                    onClick={() => {
                      const newBanners = config.banners.filter((_: any, i: number) => i !== idx);
                      onUpdateConfig({ ...config, banners: newBanners });
                    }}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-rose-100"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="space-y-4">
                  <ImageInput 
                    label="Banner Image URL"
                    value={banner.image || ''}
                    onChange={(url) => {
                      const newBanners = [...config.banners];
                      newBanners[idx].image = url;
                      onUpdateConfig({ ...config, banners: newBanners });
                    }}
                    token={token}
                    onShowNotification={onShowNotification}
                  />

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Action Link</label>
                    <div className="grid grid-cols-1 gap-2.5">
                      <select
                        value={banner.link?.startsWith('/product/') ? banner.link.split('/product/')[1] : ''}
                        onChange={(e) => {
                          const newBanners = [...config.banners];
                          newBanners[idx].link = e.target.value ? `/product/${e.target.value}` : '/products';
                          onUpdateConfig({ ...config, banners: newBanners });
                        }}
                        className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider focus:outline-none"
                      >
                        <option value="">-- Link to Product (Optional) --</option>
                        {products.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                      <input 
                        placeholder="Or enter custom URL (e.g., /shop)" 
                        className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:outline-none" 
                        value={banner.link || ''}
                        onChange={(e) => {
                          const newBanners = [...config.banners];
                          newBanners[idx].link = e.target.value;
                          onUpdateConfig({ ...config, banners: newBanners });
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quality Section */}
        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="space-y-1">
            <h3 className="text-sm font-black flex items-center space-x-3 text-slate-950 uppercase italic tracking-tighter">
              <Sparkles size={20} className="text-amber-500" />
              <span>Quality Uncompromised Section</span>
            </h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest text-wrap max-w-2xl">Manage the featured content and imagery for the quality showcase on your homepage.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Section Title</label>
                <input 
                  value={config.qualityTitle || ''} 
                  onChange={(e) => onUpdateConfig({ ...config, qualityTitle: e.target.value })}
                  placeholder="Quality Uncompromised"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 font-black text-xl uppercase italic tracking-tighter text-slate-950" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Section Description</label>
                <textarea 
                  value={config.qualityDescription || ''} 
                  onChange={(e) => onUpdateConfig({ ...config, qualityDescription: e.target.value })}
                  placeholder="Tell your brand's quality story..."
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 min-h-[140px] text-xs font-medium leading-relaxed text-slate-600" 
                />
              </div>
            </div>

            <div className="space-y-6">
              <ImageInput 
                label="Feature Image URL"
                value={config.qualityImage || ''}
                onChange={(url) => onUpdateConfig({ ...config, qualityImage: url })}
                token={token}
                onShowNotification={onShowNotification}
              />
            </div>
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AdminHomepage;
