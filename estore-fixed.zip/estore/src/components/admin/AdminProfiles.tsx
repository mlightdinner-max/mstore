import React, { useState, useMemo } from 'react';
import { Shield, Settings2, ShieldCheck, CheckSquare, Square, Save } from 'lucide-react';
import { AdminSectionHeader } from './AdminSectionHeader';
import { Config } from '../../types';
import { AVAILABLE_MODULES, DEFAULT_PERMISSIONS } from '../../constants';

interface AdminProfilesProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
  isValidating?: boolean;
}

const AdminProfiles = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, isValidating }: AdminProfilesProps) => {
  const [selectedRole, setSelectedRole] = useState<'Admin' | 'Affiliate' | 'Customer Support'>('Admin');
  
  const currentPermissions = useMemo(() => {
    return config.profilePermissions || DEFAULT_PERMISSIONS;
  }, [config.profilePermissions]);

  const handleToggleModule = (moduleId: string) => {
    const rolePermissions = currentPermissions[selectedRole] || [];
    let updatedRolePermissions;
    
    if (rolePermissions.includes(moduleId)) {
      updatedRolePermissions = rolePermissions.filter(id => id !== moduleId);
    } else {
      updatedRolePermissions = [...rolePermissions, moduleId];
    }
    
    onUpdateConfig({
      ...config,
      profilePermissions: {
        ...currentPermissions,
        [selectedRole]: updatedRolePermissions
      }
    });
  };

  const groupedModules = useMemo(() => {
    const groups: Record<string, typeof AVAILABLE_MODULES> = {};
    AVAILABLE_MODULES.forEach(m => {
      if (!groups[m.group]) groups[m.group] = [];
      groups[m.group].push(m);
    });
    return groups;
  }, []);

  return (
    <div className="space-y-8 pb-10">
      <AdminSectionHeader 
        title="Permissions & Roles" 
        description="Manage which modules each user role is allowed to view or edit." 
      />

      <div className="flex flex-col lg:flex-row gap-8 items-start h-[calc(100vh-280px)]">
        {/* Sidebar Roles list */}
        <div className="w-full lg:w-72 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex-shrink-0">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-xs font-medium uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <ShieldCheck size={16} className="text-primary" />
              Role Profiles
            </h3>
          </div>
          <div className="p-3 space-y-2">
            <div className="p-4 rounded-2xl flex items-center justify-between border-2 border-transparent bg-slate-50 opacity-60">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                  <Shield size={14} />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">Super Admin</h4>
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Full Access</p>
                </div>
              </div>
              <LockIcon />
            </div>

            {(['Admin', 'Affiliate', 'Customer Support'] as const).map(role => (
              <button
                key={role}
                onClick={() => setSelectedRole(role)}
                className={`w-full p-4 rounded-2xl flex items-center justify-between border-2 transition-all ${
                  selectedRole === role 
                    ? 'border-slate-900 bg-slate-900 shadow-lg text-white' 
                    : 'border-transparent bg-white hover:bg-slate-50 hover:border-slate-200 text-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    selectedRole === role ? 'bg-white/10 text-white' : 'bg-slate-100 text-slate-500'
                  }`}>
                    <Settings2 size={14} />
                  </div>
                  <div className="text-left">
                    <h4 className={`text-sm font-semibold ${
                      selectedRole === role ? 'text-white' : 'text-slate-900'
                    }`}>{role}</h4>
                    <p className={`text-xs font-medium uppercase tracking-wider ${
                      selectedRole === role ? 'text-white/60' : 'text-slate-400'
                    }`}>Customisable</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Modules Configurator */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col h-full">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div>
              <h3 className="text-sm font-semibold tracking-tight text-slate-900">
                {selectedRole} Permissions
              </h3>
              <p className="text-xs font-medium uppercase tracking-wider text-slate-500 mt-1">
                Select which modules a {selectedRole} can access
              </p>
            </div>
            {hasUnsavedChanges && (
              <button
                onClick={onSave}
                disabled={isValidating}
                className="btn-primary flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isValidating ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save size={14} />
                )}
                <span>Save Changes</span>
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 sm:p-8 custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Object.entries(groupedModules).map(([groupName, modules]) => (
                <div key={groupName} className="space-y-4">
                  <h4 className="text-xs font-medium uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-2">
                    {groupName}
                  </h4>
                  <div className="space-y-2">
                    {modules.map(module => {
                      const isSelected = (currentPermissions[selectedRole] || []).includes(module.id);
                      return (
                        <button
                          key={module.id}
                          onClick={() => handleToggleModule(module.id)}
                          className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100 group"
                        >
                          <div className={`transition-colors ${
                            isSelected ? 'text-slate-900' : 'text-slate-300 group-hover:text-slate-400'
                          }`}>
                            {isSelected ? <CheckSquare size={18} /> : <Square size={18} />}
                          </div>
                          <span className={`text-xs font-bold tracking-tight text-left ${
                            isSelected ? 'text-slate-900' : 'text-slate-500'
                          }`}>
                            {module.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const LockIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
);

export default AdminProfiles;
