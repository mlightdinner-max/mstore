import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Filter, ChevronDown, Edit2, Trash2, 
  Eye, Package, Folder, X, Save, Trash, LayoutGrid, Check,
  Wand2, RefreshCw, Activity, ArrowUp, ArrowRight
} from 'lucide-react';
import { Product } from '../../types';
import { LOCALIZATION } from '../../constants';
import { aiService } from '../../services/aiService';
import { MediaLibrary } from './MediaLibrary';
import { 
  Table, 
  TableHeader, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell 
} from './AdminTable';
interface AdminProductsProps {
  products: Product[];
  onAddProduct: (p: any) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateProduct: (id: string, p: any) => void;
  config: any;
  user: any;
  onShowNotification: (msg: string, type: 'success' | 'error') => void;
  token: string | null;
  aiStatus: any;
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';
import { Modal } from '../ui/Modal';

const AdminProducts = ({ 
  products, 
  onAddProduct, 
  onDeleteProduct, 
  onUpdateProduct, 
  config, 
  user, 
  onShowNotification, 
  token,
  aiStatus
}: AdminProductsProps) => {
  const navigate = useNavigate();
  const basePath = window.location.pathname.startsWith('/home') ? '/home' : window.location.pathname.includes('/affiliate') ? '/affiliate' : '/home';
  const { '*': subPath } = useParams();
  const isAdding = subPath === 'new' || (subPath && subPath.startsWith('edit/'));
  const [currentStep, setCurrentStep] = useState(1);
  const [isFolderPickerOpen, setIsFolderPickerOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState(() => ({ 
    name: '', 
    sku: '',
    price: 0, 
    originalCost: 0, 
    mrp: 0,
    profitPrice: 0, 
    category: (typeof config.categories?.[0] === 'string' ? config.categories[0] : config.categories?.[0]?.name) || '', 
    image: '', 
    images: [] as string[],
    description: '', 
    stock: 9999, 
    lowStockThreshold: 5,
    isApproved: true, 
    orderLimit: 0, 
    sourceUrl: '', 
    tags: [] as string[],
    status: 'active' as 'active' | 'deactivated' | 'draft',
    folder: '',
    variants: [] as any[]
  }));
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [folderFilter, setFolderFilter] = useState('All');
  const [tagFilter, setTagFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'name' | 'price-asc' | 'price-desc' | 'newest'>('newest');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000000 });
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const itemsPerPage = 24;
  const isAdmin = user?.role === 'Admin' || user?.role === 'Super Admin';
  const isAffiliate = user?.role === 'Affiliate';

  const createProductFolder = async (name: string) => {
    if (!name || !token) return;
    const folderName = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    try {
      await fetch('/api/v1/media/folders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name: folderName, path: 'products' })
      });
    } catch (err) {
      console.error('Failed to create product folder:', err);
    }
  };

  const [isSyncingMedia, setIsSyncingMedia] = useState(false);

  const fetchProductImages = React.useCallback(async (folder: string) => {
    if (!folder || !token) return;
    setIsSyncingMedia(true);
    try {
      const res = await fetch(`/api/v1/media?path=${encodeURIComponent(folder)}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (Array.isArray(data)) {
        const urls = data.filter(item => !item.isDirectory).map(item => item.url).sort();
        if (urls.length > 0) {
          setFormData(prev => {
            const shouldUpdateMain = !prev.image || urls.includes(prev.image);
            return {
              ...prev,
              image: shouldUpdateMain ? urls[0] : prev.image,
              images: urls.filter(u => u !== (shouldUpdateMain ? urls[0] : prev.image))
            };
          });
        }
      }
    } catch (err) {
      console.error('Fetch media failed:', err);
    } finally {
      setIsSyncingMedia(false);
    }
  }, [token]);

  const handleEdit = React.useCallback((product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      sku: product.sku || '',
      price: product.price,
      originalCost: product.originalCost || 0,
      profitPrice: product.profitPrice || 0,
      mrp: product.mrp || 0,
      category: product.category,
      image: product.image,
      images: Array.isArray(product.images) ? product.images : (typeof product.images === 'string' ? [product.images] : []),
      description: product.description || '',
      stock: product.stock || 0,
      lowStockThreshold: product.lowStockThreshold || 5,
      isApproved: product.isApproved !== false,
      orderLimit: product.orderLimit || 0,
      sourceUrl: product.sourceUrl || '',
      tags: Array.isArray(product.tags) ? product.tags : (typeof product.tags === 'string' ? (product.tags as string).split(',').map(t => t.trim()) : []),
      status: product.status || 'active',
      folder: product.folder || '',
      variants: Array.isArray(product.variants) ? product.variants : []
    });
    setCurrentStep(1);
    navigate(`${basePath}/products/edit/${product.id}`);
  }, [navigate, basePath]);

  useEffect(() => {
    if (isAdding && formData.folder) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      fetchProductImages(formData.folder);
    }
  }, [isAdding, formData.folder, fetchProductImages]);

  const previousSubPath = React.useRef<string | undefined>(undefined);
  useEffect(() => {
    const handleRouteChange = async () => {
      if (subPath === 'new' && previousSubPath.current !== 'new') {
        setEditingProduct(null);
        setFormData({ 
          name: '', sku: '', price: 0, originalCost: 0, mrp: 0, profitPrice: 0, 
          category: (typeof config.categories?.[0] === 'string' ? config.categories[0] : config.categories?.[0]?.name) || '', 
          image: '', images: [], description: '', stock: 9999, 
          lowStockThreshold: 5,
          isApproved: true, orderLimit: 0, sourceUrl: '', 
          tags: [], status: 'active', folder: '', variants: []
        });
        setCurrentStep(1);
      } else if (subPath && subPath.startsWith('edit/') && previousSubPath.current !== subPath) {
        const id = subPath.split('/')[1];
        const product = products.find(p => p.id.toString() === id);
        if (product && (!editingProduct || editingProduct.id !== product.id)) {
          handleEdit(product);
        }
      }
      previousSubPath.current = subPath;
    };
    handleRouteChange();
  }, [subPath, products, editingProduct, config.categories, handleEdit]);

  const affiliateProducts = useMemo(() => {
    if (!isAffiliate) return products;
    const enabledIds = config.affiliateSettings?.enabledProducts || [];
    if (enabledIds.length > 0) {
      return products.filter(p => enabledIds.includes(p.id));
    }
    return products.filter(p => p.isApproved !== false);
  }, [products, isAffiliate, config.affiliateSettings?.enabledProducts]);

  const filteredProducts = useMemo(() => {
    const filtered = affiliateProducts.filter(p => {
      const name = p.name || '';
      const id = p.id?.toString() || '';
      const matchesSearch = name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (p.sku && p.sku.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = categoryFilter === 'All' || p.category === categoryFilter;
      const matchesFolder = folderFilter === 'All' || p.folder === folderFilter;
      const matchesStatus = statusFilter === 'All' || 
        (statusFilter === 'Active' && p.status !== 'deactivated' && p.isApproved !== false) ||
        (statusFilter === 'Pending' && p.isApproved === false) ||
        (statusFilter === 'Deactivated' && p.status === 'deactivated');
      const matchesPrice = p.price >= priceRange.min && p.price <= priceRange.max;
      const matchesTag = tagFilter === 'All' || (Array.isArray(p.tags) && p.tags.includes(tagFilter));
      
      return matchesSearch && matchesCategory && matchesFolder && matchesStatus && matchesPrice && matchesTag;
    });

    return [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'newest': {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        }
        case 'price-asc': return a.price - b.price;
        case 'price-desc': return b.price - a.price;
        default: return a.name.localeCompare(b.name);
      }
    });
  }, [affiliateProducts, searchQuery, categoryFilter, statusFilter, priceRange, sortBy, tagFilter, folderFilter]);

  const folders = useMemo(() => {
    const uniqueFolders = Array.from(new Set(products.map(p => p.folder).filter(f => f && f.trim() !== ''))).sort();
    return ['All', ...uniqueFolders];
  }, [products]);

  const uniqueTags = useMemo(() => {
    const allTags = products.flatMap(p => p.tags || []);
    return Array.from(new Set(allTags)).sort();
  }, [products]);

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const paginatedProducts = filteredProducts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setCurrentPage(1);
  }, [searchQuery, categoryFilter, statusFilter, priceRange, sortBy, tagFilter, folderFilter]);

  useEffect(() => {
    if (!formData.category && config.categories && config.categories.length > 0) {
      const firstCat = config.categories[0];
      const categoryName = typeof firstCat === 'string' ? firstCat : firstCat.name;
      if (categoryName) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setFormData(prev => ({ ...prev, category: categoryName }));
      }
    }
  }, [config.categories, formData.category]); 

  const handleSave = async (forceDraft = false) => {
    const requiredFields = [
      { key: 'name', label: 'Title (Name)' },
      { key: 'category', label: 'Category' },
      { key: 'description', label: 'Content (Description)' },
      { key: 'price', label: `Selling Price (${LOCALIZATION.CURRENCY})` },
      { key: 'mrp', label: `MRP (${LOCALIZATION.CURRENCY})` },
      { key: 'originalCost', label: `Original Cost (${LOCALIZATION.CURRENCY})` }
    ];

    const missingFields = requiredFields.filter(f => {
      const val = (formData as any)[f.key];
      return val === undefined || val === null || (typeof val === 'string' && val.trim() === '') || (typeof val === 'number' && isNaN(val));
    });

    if (missingFields.length > 0 || !formData.tags || formData.tags.length === 0) {
      const missingLabels = missingFields.map(f => f.label);
      if (!formData.tags || formData.tags.length === 0) missingLabels.push('Tags');
      onShowNotification(`Please fill in all required fields: ${missingLabels.join(', ')}.`, "error");
      return;
    }

    // Ensure folder exists before saving if it doesn't already
    let currentFolder = formData.folder;
    if (!currentFolder && formData.name) {
      currentFolder = formData.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
      try {
        await createProductFolder(formData.name);
      } catch (err) {
        console.error('Folder creation failed but continuing:', err);
      }
    }

    const dataToSave = { 
      ...formData,
      tags: Array.isArray(formData.tags) ? formData.tags.map(t => t.trim()).filter(Boolean) : [],
      stock: formData.stock || 9999, 
      isApproved: forceDraft ? false : (formData.status === 'active' ? true : formData.isApproved),
      status: forceDraft ? 'draft' : (formData.status || 'active'),
      folder: currentFolder,
      isOutOfStock: false,
      profitPrice: (formData.price || 0) - (formData.originalCost || 0)
    };

    try {
      if (editingProduct) {
        await onUpdateProduct(editingProduct.id, dataToSave);
        onShowNotification("Product updated successfully.", "success");
      } else {
        await onAddProduct(dataToSave);
        onShowNotification("Product added successfully.", "success");
      }
      resetForm();
    } catch (err: any) {
      console.error('Failed to save product:', err);
      onShowNotification(`Failed to save product: ${err.message || 'Unknown error'}`, "error");
    }
  };

  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const resetForm = () => {
    setEditingProduct(null);
    setFormData({ 
      name: '', sku: '', price: 0, originalCost: 0, mrp: 0, profitPrice: 0, 
      category: (typeof config.categories?.[0] === 'string' ? config.categories[0] : config.categories?.[0]?.name) || '', 
      image: '', images: [], description: '', stock: 10, 
      lowStockThreshold: 5,
      isApproved: true, orderLimit: 0, sourceUrl: '', 
      tags: [], status: 'active', folder: '', variants: []
    });
    setCurrentStep(1);
    navigate(`${basePath}/products`);
  };


  const generateAIDescription = async () => {
    if (!formData.name) {
      onShowNotification('Please enter a product name first', 'error');
      return;
    }
    
    if (!aiStatus?.settings?.enabled || !aiStatus?.settings?.useProductDescriptions) {
      onShowNotification('AI Product Descriptions are disabled in System Settings.', 'error');
      return;
    }
    
    if (!aiStatus?.isAvailable) {
      onShowNotification('AI is currently unavailable (Quota or Key issue).', 'error');
      return;
    }
    
    setIsGeneratingDescription(true);
    try {
      const text = await aiService.generateDescription(
        formData.name,
        formData.category,
        formData.description,
        aiStatus?.isUnsavedKey ? config.geminiApiKey : undefined
      );
      
      if (text) {
        setFormData(prev => ({ ...prev, description: text }));
        onShowNotification('Description updated by AI', 'success');
      } else {
        onShowNotification('AI service is currently unavailable. Using manual mode.', 'error');
      }
    } catch (error: any) {
      console.error('AI Error:', error);
      onShowNotification(error.message || 'AI generation error', 'error');
    } finally {
      setIsGeneratingDescription(false);
    }
  };

  return (
    <>
      {!isAdding && (
      <AdminPageWrapper
        title="Products"
        description="Manage your product catalog, pricing, stock levels, and visibility."
        icon={Package}
        options={[
          { label: 'Add/Edit Product', description: 'Create new products or update existing details, pricing, and images.' },
          { label: 'Manage Stock', description: 'Update inventory levels and track out-of-stock items.' }
        ]}
        actions={
          <div className="flex items-center gap-3">
            {isAdmin && (
              <button 
                onClick={() => navigate(`${basePath}/products/new`)}
                className="flex items-center space-x-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg active:scale-95 group"
              >
                <Plus size={16} className="group-hover:rotate-90 transition-transform" />
                <span>Add Product</span>
              </button>
            )}
          </div>
        }
        toolbar={
          <AdminToolbar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            searchPlaceholder="Search by name or product ID..."
            showAdvanced={showAdvancedFilters}
            setShowAdvanced={setShowAdvancedFilters}
            leftActions={
              <div className="flex items-center gap-4">
                <div className="flex items-center bg-slate-50 border border-slate-200 p-1 rounded-2xl shadow-sm">
                  <button 
                    onClick={() => setViewMode('grid')}
                    className={`px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${viewMode === 'grid' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    <LayoutGrid size={14} />
                    Grid
                  </button>
                    <button 
                      onClick={() => setViewMode('list')}
                      className={`px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${viewMode === 'list' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                      <Filter size={14} className="rotate-90" />
                      List View
                    </button>
                </div>

                <AnimatePresence>
                  {selectedProducts.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, x: -20 }}
                      animate={{ opacity: 1, scale: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.9, x: -20 }}
                      className="flex items-center gap-2 px-4 py-2 bg-rose-50 border border-rose-100 rounded-2xl shadow-sm"
                    >
                      <span className="text-xs font-medium text-rose-600 uppercase tracking-wider whitespace-nowrap">
                        {selectedProducts.length} Selected
                      </span>
                      <div className="h-4 w-[1px] bg-rose-200 mx-2" />
                      <button 
                        onClick={() => {
                          if (window.confirm(`Permanently delete ${selectedProducts.length} product(s)? This cannot be undone.`)) {
                            selectedProducts.forEach(id => onDeleteProduct(id));
                            setSelectedProducts([]);
                            onShowNotification(`Permanently deleted ${selectedProducts.length} product(s)`, 'success');
                          }
                        }}
                        className="p-1.5 hover:bg-rose-500 hover:text-white text-rose-500 rounded-lg transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                      <button 
                        onClick={() => setSelectedProducts([])}
                        className="p-1.5 hover:bg-slate-200 text-slate-400 rounded-lg transition-all"
                      >
                        <X size={14} />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            }
            filters={
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="All">All Categories</option>
                {config.categories?.map((cat: any, i: number) => {
                  const catName = typeof cat === 'string' ? cat : cat.name;
                  const catId = typeof cat === 'string' ? `cat-${i}` : (cat.id || `cat-${i}`);
                  return <option key={catId} value={catName}>{catName}</option>;
                })}
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="All">All Status</option>
                <option value="Active">Active</option>
                <option value="Pending">Pending</option>
                <option value="Deactivated">Deactivated</option>
              </select>
            </div>
          }
          advancedFilters={
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-3">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider outline-none"
                >
                  <option value="newest">NEWEST FIRST</option>
                  <option value="name">NAME (A-Z)</option>
                  <option value="price-asc">PRICE (LOW-HIGH)</option>
                  <option value="price-desc">PRICE (HIGH-LOW)</option>
                </select>
              </div>
              <div className="space-y-3">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Folders</label>
                <select
                  value={folderFilter}
                  onChange={(e) => setFolderFilter(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider outline-none"
                >
                  {folders.map(folder => (
                    <option key={folder} value={folder}>{folder.toUpperCase()}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-3">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Tags</label>
                <select
                  value={tagFilter}
                  onChange={(e) => setTagFilter(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider outline-none shadow-sm"
                >
                  <option value="All">All Tags</option>
                  {uniqueTags.map(tag => (
                    <option key={tag} value={tag}>{tag}</option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-1 lg:col-span-3 space-y-4 pt-4 border-t border-slate-100 flex flex-col md:flex-row gap-6">
                <div className="flex-1 space-y-3">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider flex justify-between">
                    <span>Price Range</span>
                    <span className="text-slate-900">{LOCALIZATION.CURRENCY}{priceRange.min} - {LOCALIZATION.CURRENCY}{priceRange.max === 1000000 ? '1L+' : priceRange.max}</span>
                  </label>
                  <div className="flex gap-4">
                    <input
                      type="range"
                      min="0"
                      max="1000000"
                      step="500"
                      value={priceRange.max}
                      onChange={(e) => setPriceRange({ ...priceRange, max: parseInt(e.target.value) })}
                      className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>
          }
        />
      }
      isEmpty={filteredProducts.length === 0}
      emptyState={
        <div className="space-y-4">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300">
            <Package size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">No products found</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your filters or search terms</p>
          </div>
          <button 
            onClick={() => {
              setSearchQuery('');
              setCategoryFilter('All');
              setStatusFilter('All');
              setFolderFilter('All');
              setTagFilter('All');
              setPriceRange({ min: 0, max: 1000000 });
            }}
            className="text-xs font-medium text-slate-900 uppercase tracking-wider hover:underline pt-2"
          >
            Clear All Filters
          </button>
        </div>
      }
    >
      <div className="space-y-6 pt-2">
        {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {paginatedProducts.map((product) => (
              <motion.div
                layout
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden group hover:shadow-2xl hover:shadow-slate-950/5 transition-all"
              >
                <div className="relative aspect-square overflow-hidden bg-slate-100">
                    {product.image ? (
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                    ) : null}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    <span className="px-3 py-1.5 bg-white/90 backdrop-blur-md text-slate-950 text-xs font-medium uppercase tracking-wider rounded-xl shadow-sm">
                      {product.category}
                    </span>
                    {product.folder && (
                      <span className="px-3 py-1.5 bg-slate-900/90 backdrop-blur-md text-white text-xs font-medium uppercase tracking-wider rounded-xl shadow-sm flex items-center space-x-1">
                        <Folder size={10} />
                        <span>{product.folder}</span>
                      </span>
                    )}
                  </div>
                  <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
                    <div className={`px-3 py-1.5 rounded-xl text-xs font-medium uppercase tracking-wider shadow-sm backdrop-blur-md ${
                      product.status === 'deactivated' ? 'bg-rose-500/90 text-white' :
                      product.isApproved === false ? 'bg-amber-500/90 text-white' :
                      'bg-emerald-500/90 text-white'
                    }`}>
                      {product.status === 'deactivated' ? 'Deactivated' :
                       product.isApproved === false ? 'Pending' :
                       'Active'}
                    </div>
                    <div 
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedProducts(prev => 
                          prev.includes(product.id) ? prev.filter(id => id !== product.id) : [...prev, product.id]
                        );
                      }}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-sm ${
                        selectedProducts.includes(product.id) ? 'bg-primary text-white' : 'bg-white/80 backdrop-blur-sm text-slate-300 hover:text-slate-500'
                      }`}
                    >
                      {selectedProducts.includes(product.id) ? <Check size={16} /> : <div className="w-4 h-4 border-2 border-current rounded-md" />}
                    </div>
                  </div>
                  
                  {/* Hover Actions */}
                  <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                    {isAdmin && (
                      <>
                        {product.status === 'deactivated' ? (
                          <button 
                            onClick={async () => {
                              try {
                                await onUpdateProduct(product.id, { ...product, status: 'active' });
                                onShowNotification("Product restored successfully.", "success");
                              } catch {
                                onShowNotification("Failed to restore product.", "error");
                              }
                            }}
                            className="p-3 bg-emerald-500 text-white rounded-2xl hover:scale-110 transition-all shadow-xl"
                            title="Restore Product"
                          >
                            <RefreshCw size={18} />
                          </button>
                        ) : (
                          <>
                            <button 
                              onClick={() => navigate(`${basePath}/products/edit/${product.id}`)}
                              className="p-3 bg-white text-slate-900 rounded-2xl hover:scale-110 transition-all shadow-xl"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button 
                              onClick={() => setShowDeleteConfirm(product.id)}
                              className="p-3 bg-rose-500 text-white rounded-2xl hover:scale-110 transition-all shadow-xl"
                            >
                              <Trash2 size={18} />
                            </button>
                          </>
                        )}
                      </>
                    )}
                    <button 
                      onClick={() => window.open(`/product/${product.id}`, '_blank')}
                      className="p-3 bg-blue-500 text-white rounded-2xl hover:scale-110 transition-all shadow-xl"
                    >
                      <Eye size={18} />
                    </button>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">ID: {product.id}</p>
                    <h3 className="text-sm font-black text-slate-950 uppercase tracking-tight line-clamp-1">{product.name}</h3>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Price</p>
                      <div className="flex items-center gap-2">
                        <p className="text-lg font-black text-slate-950 tracking-tighter">{LOCALIZATION.CURRENCY}{(Number(product.price) || 0).toLocaleString()}</p>
                      </div>
                    </div>
                  </div>

                  {Array.isArray(product.tags) && product.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {product.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="px-2 py-0.5 bg-slate-50 text-slate-500 text-xs font-medium uppercase tracking-wider rounded-full border border-slate-100">
                          {tag}
                        </span>
                      ))}
                      {product.tags.length > 3 && (
                        <span className="px-2 py-0.5 bg-slate-50 text-slate-400 text-xs font-medium uppercase tracking-wider rounded-full">
                          +{product.tags.length - 3}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
          <Table>
            <TableHeader>
              <TableHead className="w-10">
                <div 
                  onClick={() => {
                    if (selectedProducts.length === paginatedProducts.length) setSelectedProducts([]);
                    else setSelectedProducts(paginatedProducts.map(p => p.id));
                  }}
                  className="w-4 h-4 rounded border-2 border-slate-300 flex items-center justify-center cursor-pointer hover:border-slate-900 transition-colors"
                >
                  {selectedProducts.length === paginatedProducts.length && <div className="w-2 h-2 bg-slate-900 rounded-[1px]" />}
                </div>
              </TableHead>
              <TableHead>Product</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Pricing & Margin</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableHeader>
            <TableBody>
              {paginatedProducts.map((product) => (
                <TableRow key={product.id} className={selectedProducts.includes(product.id) ? 'bg-slate-50' : ''}>
                  <TableCell>
                    <div 
                      onClick={() => setSelectedProducts(prev => prev.includes(product.id) ? prev.filter(id => id !== product.id) : [...prev, product.id])}
                      className={`w-4 h-4 rounded border-2 transition-all cursor-pointer flex items-center justify-center ${
                        selectedProducts.includes(product.id) ? 'bg-slate-900 border-slate-900' : 'border-slate-300 hover:border-slate-400'
                      }`}
                    >
                      {selectedProducts.includes(product.id) && <Check size={10} className="text-white" />}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-slate-100 rounded-xl overflow-hidden border border-slate-200">
                        {product.image ? (
                          <img src={product.image} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : null}
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{product.name}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">ID: {product.id}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="px-2 py-1 bg-slate-100 text-slate-600 text-xs font-medium uppercase tracking-wider rounded-lg border border-slate-200">
                      {product.category}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <p className="font-black text-slate-950 tracking-tighter">{LOCALIZATION.CURRENCY}{(Number(product.price) || 0).toLocaleString()}</p>
                      {product.originalCost > 0 && (
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Cost: {LOCALIZATION.CURRENCY}{product.originalCost}</p>
                          <span className="text-xs font-black text-emerald-600">
                            {Math.round(((product.price - product.originalCost) / product.price) * 100)}% Margin
                          </span>
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                      <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium uppercase tracking-wider ${
                        product.status === 'deactivated' ? 'bg-rose-100 text-rose-700' :
                        product.status === 'draft' || product.isApproved === false ? 'bg-amber-100 text-amber-700' :
                        'bg-emerald-100 text-emerald-700'
                      }`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          product.status === 'deactivated' ? 'bg-rose-500' :
                          product.status === 'draft' || product.isApproved === false ? 'bg-amber-500' :
                          'bg-emerald-500'
                        }`} />
                        {product.status === 'deactivated' ? 'Deactivated' :
                         product.status === 'draft' ? 'Draft' :
                         product.isApproved === false ? 'Pending' :
                         'Active'}
                      </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {isAdmin && (
                        <>
                          {product.status === 'deactivated' ? (
                            <button 
                              onClick={async () => {
                                try {
                                  await onUpdateProduct(product.id, { ...product, status: 'active' });
                                  onShowNotification("Product restored successfully.", "success");
                                } catch {
                                  onShowNotification("Failed to restore product.", "error");
                                }
                              }}
                              className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all"
                              title="Restore Product"
                            >
                              <RefreshCw size={14} />
                            </button>
                          ) : (
                            <>
                              <button 
                                onClick={() => navigate(`${basePath}/products/edit/${product.id}`)}
                                className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
                                title="Edit Product"
                              >
                                <Edit2 size={14} />
                              </button>
                              <button 
                                onClick={() => setShowDeleteConfirm(product.id)}
                                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                title="Delete Product"
                              >
                                <Trash2 size={14} />
                              </button>
                            </>
                          )}
                        </>
                      )}
                      <button 
                        onClick={() => window.open(`/product/${product.id}`, '_blank')}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        title="View Product"
                      >
                        <Eye size={14} />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center space-x-2 pt-8">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(prev => prev - 1)}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-900 disabled:opacity-50 transition-all shadow-sm"
            title="Previous Page"
          >
            <ChevronDown className="rotate-90" size={18} />
          </button>
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-sm">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i + 1)}
                className={`w-10 h-10 rounded-lg text-xs font-black transition-all ${currentPage === i + 1 ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-900'}`}
              >
                {i + 1}
              </button>
            ))}
          </div>
          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(prev => prev + 1)}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-900 disabled:opacity-50 transition-all shadow-sm"
          >
            <ChevronDown className="-rotate-90" size={18} />
          </button>
        </div>
      )}
      </div>
    </AdminPageWrapper>
      )}

      {/* Add/Edit View */}
      {isAdding && (
        <div className="w-full h-full flex flex-col flex-1 bg-[#f2f4f7]">
              {/* Sticky CRM Header */}
              <div className="px-8 py-4 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20 shadow-sm">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-slate-900 text-white rounded shadow-sm">
                    <Package size={20} />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium uppercase tracking-wider leading-none mb-1">Products</div>
                    <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                      {editingProduct ? `Edit ${formData.name}` : 'Create Product'}
                    </h2>
                  </div>
                </div>

                {/* Progress Tracker */}
                <div className="hidden md:flex items-center space-x-8">
                  {[
                    { step: 1, label: 'Identify' },
                    { step: 2, label: 'Media' },
                    { step: 3, label: 'Advanced' }
                  ].map((s) => (
                    <div key={s.step} className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all ${
                        currentStep === s.step ? 'bg-slate-900 text-white shadow-lg scale-110' : 
                        currentStep > s.step ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400'
                      }`}>
                        {currentStep > s.step ? <Check size={14} /> : s.step}
                      </div>
                      <span className={`text-xs font-medium uppercase tracking-wider ${
                        currentStep === s.step ? 'text-slate-900' : 'text-slate-400'
                      }`}>{s.label}</span>
                      {s.step < 3 && <div className="w-12 h-[1px] bg-slate-200" />}
                    </div>
                  ))}
                </div>

                <div className="flex items-center space-x-3">
                  <button 
                    onClick={resetForm} 
                    className="px-5 py-2 text-slate-600 font-bold text-xs uppercase tracking-wider hover:bg-slate-100 rounded-md transition-all active:scale-95"
                  >
                    Cancel
                  </button>
                  {currentStep > 1 && (
                    <button 
                      onClick={() => setCurrentStep(prev => prev - 1)} 
                      className="px-5 py-2 bg-white border border-slate-300 text-slate-700 rounded-md font-bold text-xs uppercase tracking-wider hover:bg-slate-50 transition-all shadow-sm active:scale-95"
                    >
                      Back
                    </button>
                  )}
                  {currentStep < 3 ? (
                    <button 
                      onClick={async () => {
                        if (currentStep === 1) {
                          // Validation for step 1
                          const isNameMissing = !formData.name || formData.name.trim() === '';
                          const isCatMissing = !formData.category || formData.category.trim() === '';
                          const isPriceValid = typeof formData.price === 'number' && formData.price > 0;
                          const isCostValid = typeof formData.originalCost === 'number' && formData.originalCost >= 0;

                          if (isNameMissing || isCatMissing || !isPriceValid || !isCostValid) {
                            onShowNotification("Product name, category, cost price, and selling price (must be greater than 0) are mandatory.", "error");
                            return;
                          }

                          // Price Validation
                          if (formData.price < formData.originalCost) {
                            onShowNotification("Selling Price (My Price) must be higher or equal to Supplier Cost.", "error");
                            return;
                          }

                          if (formData.mrp && formData.price >= formData.mrp) {
                            onShowNotification("Selling Price (My Price) must be lower than Dummy Price (MRP).", "error");
                            return;
                          }
                          
                          // Ensure folder is created
                          if (!formData.folder) {
                            const folderName = formData.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
                            const targetFolder = `products/${folderName}`;
                            setFormData(prev => ({ ...prev, folder: targetFolder }));
                            await createProductFolder(formData.name);
                          }
                        }
                        setCurrentStep(prev => prev + 1);
                      }} 
                      className="px-6 py-2 bg-blue-600 text-white rounded-md font-bold text-xs uppercase tracking-wider hover:bg-blue-700 transition-all shadow-md active:scale-95 flex items-center space-x-2"
                    >
                      <span>Proceed to {currentStep === 1 ? 'Media' : 'Review'}</span>
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleSave()} 
                      className="px-6 py-2 bg-emerald-600 text-white rounded-md font-bold text-xs uppercase tracking-wider hover:bg-emerald-700 transition-all shadow-md active:scale-95 flex items-center space-x-2"
                    >
                      <Save size={14} />
                      <span>{editingProduct ? 'Finalize Update' : 'Live Publish'}</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 sm:p-8 custom-scrollbar">
                <div className="max-w-5xl mx-auto space-y-8 pb-12">
                  
                  {/* Step 1: Core Content */}
                  {currentStep === 1 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-8"
                    >
                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                          <div className="flex items-center space-x-2">
                            <div className="w-1.5 h-6 bg-blue-600 rounded-full" />
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Product Identity</h3>
                          </div>
                        </div>
                        <div className="p-8 space-y-8">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Product Name <span className="text-red-500">*</span></label>
                              <input
                                type="text"
                                value={formData.name || ''}
                                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600/20 rounded-md text-sm font-medium transition-all outline-none text-slate-900"
                                placeholder="e.g. Premium Wireless Headphones"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Category <span className="text-red-500">*</span></label>
                              <div className="relative">
                                <select
                                  value={formData.category || ''}
                                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                                  className="w-full px-4 py-2.5 bg-white border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600/20 rounded-md text-sm font-medium transition-all outline-none text-slate-900 appearance-none cursor-pointer"
                                >
                                  <option value="">Select Category</option>
                                  {config.categories?.map((cat: any, i: number) => {
                                    const catName = typeof cat === 'string' ? cat : cat.name;
                                    const catId = typeof cat === 'string' ? `cat-${i}` : (cat.id || `cat-${i}`);
                                    return <option key={catId} value={catName}>{catName}</option>;
                                  })}
                                </select>
                                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                                  <ChevronDown size={14} />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="space-y-2 pt-4 border-t border-slate-100">
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Internal Reference & Description</label>
                              <button
                                type="button"
                                onClick={generateAIDescription}
                                disabled={isGeneratingDescription}
                                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider transition-all shadow-sm border ${
                                  isGeneratingDescription 
                                    ? 'bg-slate-50 text-slate-400 cursor-wait border-slate-100' 
                                    : 'bg-white text-blue-600 border-blue-100 hover:bg-blue-50'
                                }`}
                              >
                                {isGeneratingDescription ? <RefreshCw size={12} className="animate-spin" /> : <Wand2 size={12} />}
                                <span>{isGeneratingDescription ? 'Writing...' : 'AI smart description'}</span>
                              </button>
                            </div>
                            <textarea
                              value={formData.description || ''}
                              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                              rows={5}
                              className="w-full px-4 py-3 bg-white border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600/20 rounded-md text-sm font-medium transition-all outline-none resize-none text-slate-900"
                              placeholder="Describe your product... (Used in storefront)"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                          <div className="flex items-center space-x-2">
                            <div className="w-1.5 h-6 bg-amber-500 rounded-full" />
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Pricing Configuration</h3>
                          </div>
                        </div>
                        <div className="p-8 space-y-8">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider text-blue-600">My Price (Final Sell) <span className="text-red-500">*</span></label>
                              <input
                                type="number"
                                value={formData.price === 0 ? '' : formData.price}
                                onChange={(e) => {
                                  const val = e.target.value === '' ? 0 : Number(e.target.value);
                                  setFormData(prev => ({ ...prev, price: val }));
                                }}
                                className="w-full px-4 py-2.5 bg-blue-50/30 border border-blue-100 focus:border-blue-600 focus:ring-1 focus:ring-blue-600/20 rounded-md text-sm font-bold outline-none text-slate-900"
                                placeholder="0.00"
                              />
                              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Visible to customer</p>
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Dummy/MRP Price (Crossed)</label>
                              <input
                                type="number"
                                value={formData.mrp === 0 ? '' : formData.mrp}
                                onChange={(e) => {
                                  const val = e.target.value === '' ? 0 : Number(e.target.value);
                                  setFormData(prev => ({ ...prev, mrp: val }));
                                }}
                                className="w-full px-4 py-2.5 bg-white border border-slate-200 focus:border-blue-600 focus:ring-1 focus:ring-blue-600/20 rounded-md text-sm font-medium outline-none text-slate-900"
                                placeholder="0.00"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-rose-500 uppercase tracking-wider">Supplier Cost (Internal ONLY)</label>
                              <input
                                type="number"
                                value={formData.originalCost === 0 ? '' : formData.originalCost}
                                onChange={(e) => {
                                  const val = e.target.value === '' ? 0 : Number(e.target.value);
                                  setFormData(prev => ({ ...prev, originalCost: val }));
                                }}
                                className="w-full px-4 py-2.5 bg-rose-50/30 border border-rose-100 focus:border-rose-600 focus:ring-1 focus:ring-rose-600/20 rounded-md text-sm font-medium outline-none text-slate-900"
                                placeholder="0.00"
                              />
                              <p className="text-xs text-rose-400 font-bold uppercase tracking-widest mt-1">HIDDEN FROM CUSTOMERS</p>
                            </div>
                          </div>

                          {(formData.price > 0 && formData.originalCost > 0) && (
                            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100 flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 bg-white border border-emerald-100 rounded-lg flex items-center justify-center text-emerald-600 font-black text-xs">!</div>
                                <div>
                                  <div className="text-xs font-medium text-emerald-700 uppercase tracking-wider leading-none mb-1">Projected Earnings</div>
                                  <div className="text-xs font-black text-emerald-900 uppercase tracking-tight">
                                    {LOCALIZATION.CURRENCY}{(Number(formData.price || 0) - Number(formData.originalCost || 0)).toLocaleString()} PROFIT PER SALE ({Math.round(((formData.price - formData.originalCost) / formData.price) * 100)}% MARGIN)
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                          <div className="flex items-center space-x-2">
                            <div className="w-1.5 h-6 bg-slate-400 rounded-full" />
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Reselling & Tags</h3>
                          </div>
                        </div>
                        <div className="p-8 space-y-8">
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Supplier/Source URL (Internal Reference)</label>
                            <input
                              type="text"
                              value={formData.sourceUrl || ''}
                              onChange={(e) => setFormData(prev => ({ ...prev, sourceUrl: e.target.value }))}
                              className="w-full px-4 py-2.5 bg-white border border-slate-200 focus:border-blue-600 rounded-md text-sm outline-none text-slate-900"
                              placeholder="Direct supplier product link for re-ordering"
                            />
                            <p className="text-xs text-rose-400 font-bold uppercase tracking-widest mt-1">INTERNAL ONLY - NEVER VISIBLE ON STOREFRONT</p>
                          </div>
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Search Keywords / Tags</label>
                            <input
                              type="text"
                              value={Array.isArray(formData.tags) ? formData.tags.join(', ') : ''}
                              onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value.split(',').map(t => t.trimStart()) }))}
                              className="w-full px-4 py-2.5 bg-white border border-slate-200 focus:border-blue-600 rounded-md text-sm outline-none text-slate-900"
                              placeholder="tech, wireless, sound"
                            />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Step 2: Media Management */}
                  {currentStep === 2 && (
                    <motion.div 
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-8"
                    >
                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-1.5 h-6 bg-indigo-600 rounded-full" />
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Product Assets</h3>
                          </div>
                          {formData.folder && (
                            <button
                              type="button"
                              onClick={() => fetchProductImages(formData.folder)}
                              className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 rounded-md text-xs font-bold uppercase tracking-wider flex items-center gap-2"
                            >
                              <RefreshCw size={12} className={isSyncingMedia ? 'animate-spin' : ''} />
                              Sync Folder
                            </button>
                          )}
                        </div>
                        <div className="p-8 space-y-8">
                          <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-100 flex items-center space-x-4">
                             <Folder size={20} className="text-indigo-600" />
                             <div>
                               <div className="text-xs font-medium text-indigo-700 uppercase tracking-wider leading-none mb-1">Active Storage Path</div>
                               <div className="text-xs font-bold text-indigo-900">Uploading to: {formData.folder || 'Automatic Root'}</div>
                             </div>
                          </div>

                          <div className="min-h-[400px] border border-slate-100 rounded-2xl overflow-hidden shadow-inner bg-slate-50/30">
                             <MediaLibrary 
                               token={token} 
                               onShowNotification={onShowNotification}
                               initialPath={formData.folder || 'products'}
                               onSelect={(url) => {
                                 if (!formData.image) {
                                   setFormData(prev => ({ ...prev, image: url }));
                                   onShowNotification("Set as primary image", "success");
                                 } else {
                                   setFormData(prev => ({ ...prev, images: [...prev.images, url] }));
                                   onShowNotification("Added to gallery", "success");
                                 }
                               }}
                             />
                          </div>

                          <div className="space-y-4 pt-6 border-t border-slate-100">
                             <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Asset Assignments</h4>
                             <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                 {formData.image ? (
                                   <div className="relative aspect-square rounded-xl overflow-hidden border-2 border-blue-500 shadow-lg group">
                                      <img src={formData.image} alt="Primary" className="w-full h-full object-cover" />
                                      <div className="absolute top-1 left-1 bg-blue-500 text-white text-xs font-black uppercase px-1.5 py-0.5 rounded shadow">Main</div>
                                      <button 
                                       onClick={() => setFormData(prev => ({ ...prev, image: '' }))}
                                       className="absolute top-1 right-1 p-1 bg-rose-500 text-white rounded-md opacity-0 group-hover:opacity-100 transition-opacity"
                                      >
                                        <Trash size={10} />
                                      </button>
                                   </div>
                                 ) : null}
                                 {formData.images.map((img, idx) => (
                                    img ? (
                                      <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-slate-200 group">
                                        <img src={img} alt="Gallery" className="w-full h-full object-cover" />
                                        <button 
                                         onClick={() => setFormData(prev => {
                                           const newImgs = [...prev.images];
                                           newImgs.splice(idx, 1);
                                           return { ...prev, images: newImgs };
                                         })}
                                         className="absolute top-1 right-1 p-1 bg-rose-500 text-white rounded-md opacity-0 group-hover:opacity-100 transition-opacity"
                                        >
                                          <Trash size={10} />
                                        </button>
                                     </div>
                                    ) : null
                                 ))}
                             </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Step 3: Review & Advanced */}
                  {currentStep === 3 && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-8"
                    >
                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                           <div className="flex items-center space-x-2">
                              <div className="w-1.5 h-6 bg-purple-600 rounded-full" />
                              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Product Variants (Options)</h3>
                           </div>
                        </div>
                        <div className="p-8 space-y-8">
                           <div className="space-y-6">
                              <div className="flex items-center justify-between">
                                 <div>
                                    <h4 className="text-xs font-medium text-slate-900 uppercase tracking-wider">Size & Style variants</h4>
                                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Add options like Small, Medium, Large etc.</p>
                                 </div>
                                 <button 
                                    type="button"
                                    onClick={() => setFormData(prev => ({ 
                                       ...prev, 
                                       variants: [...(prev.variants || []), { id: Date.now().toString(), name: 'Size', options: [] }] 
                                    }))}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-medium uppercase tracking-wider transition-all"
                                 >
                                    <Plus size={12} />
                                    <span>Add Variant Group</span>
                                 </button>
                              </div>

                              <div className="space-y-4">
                                 {(formData.variants || []).map((variant: any, vIdx: number) => (
                                    <div key={variant.id} className="p-6 border border-slate-100 rounded-2xl bg-slate-50/30 space-y-4">
                                       <div className="flex items-center justify-between">
                                          <div className="flex-1 max-w-xs">
                                             <input 
                                                type="text"
                                                value={variant.name}
                                                onChange={(e) => {
                                                   const newVariants = [...(formData.variants || [])];
                                                   newVariants[vIdx].name = e.target.value;
                                                   setFormData(prev => ({ ...prev, variants: newVariants }));
                                                }}
                                                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium uppercase tracking-wider outline-none focus:border-purple-500"
                                                placeholder="VARIANT NAME (e.g. SIZE)"
                                             />
                                          </div>
                                          <button 
                                             type="button"
                                             onClick={() => setFormData(prev => {
                                                const newVariants = [...(prev.variants || [])];
                                                newVariants.splice(vIdx, 1);
                                                return { ...prev, variants: newVariants };
                                             })}
                                             className="text-rose-500 hover:text-rose-700 p-2"
                                          >
                                             <Trash2 size={14} />
                                          </button>
                                       </div>
                                       
                                       <div className="space-y-2">
                                          <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Options (Comma separated)</label>
                                          <input 
                                             type="text"
                                             value={variant.options?.join(', ') || ''}
                                             onChange={(e) => {
                                                const newVariants = [...(formData.variants || [])];
                                                newVariants[vIdx].options = e.target.value.split(',').map(o => o.trim()).filter(Boolean);
                                                setFormData(prev => ({ ...prev, variants: newVariants }));
                                             }}
                                             className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:border-purple-500"
                                             placeholder="S, M, L, XL"
                                          />
                                       </div>
                                    </div>
                                 ))}
                                 
                                 {(formData.variants || []).length === 0 && (
                                    <div className="py-12 border-2 border-dashed border-slate-100 rounded-2xl flex flex-col items-center justify-center text-slate-300">
                                       <LayoutGrid size={32} className="mb-3 opacity-20" />
                                       <p className="text-xs font-medium uppercase tracking-wider">No variants defined</p>
                                    </div>
                                 )}
                              </div>
                           </div>
                        </div>
                      </div>

                      {/* Price History Section */}
                      {editingProduct && editingProduct.priceHistory && (editingProduct.priceHistory as any[]).length > 0 && (
                        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden mt-8">
                          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                             <div className="flex items-center space-x-2">
                                <Activity size={16} className="text-blue-500" />
                                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Price Change History</h3>
                             </div>
                          </div>
                          <div className="p-8">
                             <div className="space-y-4">
                                {(editingProduct.priceHistory as any[]).map((history: any, hIdx: number) => (
                                   <div key={hIdx} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                                      <div className="flex items-center gap-4">
                                         <div className={`p-2 rounded-lg ${history.updatedPrice > history.previousPrice ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                            {history.updatedPrice > history.previousPrice ? <ArrowUp size={14} /> : <ArrowRight size={14} className="rotate-45" />}
                                         </div>
                                         <div>
                                            <p className="text-xs font-medium text-slate-900 uppercase tracking-wider">
                                               {LOCALIZATION.CURRENCY}{history.previousPrice} → {LOCALIZATION.CURRENCY}{history.updatedPrice}
                                            </p>
                                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                               {new Date(history.timestamp).toLocaleString()}
                                            </p>
                                         </div>
                                      </div>
                                      {history.associatedOrders && (history.associatedOrders as any[]).length > 0 && (
                                         <div className="text-xs font-black text-slate-500 bg-white border border-slate-200 px-2 py-1 rounded-md uppercase tracking-widest">
                                            {(history.associatedOrders as any[]).length} Orders Impacted
                                         </div>
                                      )}
                                   </div>
                                ))}
                             </div>
                          </div>
                        </div>
                      )}

                      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                         <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Final Verification</h3>
                         </div>
                         <div className="p-8 space-y-6">
                            <div className="grid grid-cols-2 gap-8">
                               <div className="space-y-4">
                                  <div className="space-y-1">
                                     <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Visibility Status</label>
                                     <select
                                        value={formData.status || 'active'}
                                        onChange={(e) => {
                                          const newStatus = e.target.value as any;
                                          setFormData(prev => ({ 
                                            ...prev, 
                                            status: newStatus,
                                            isApproved: newStatus === 'active' ? true : false
                                          }));
                                        }}
                                        className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-md text-xs font-bold font-black outline-none"
                                     >
                                        <option value="active">PUBLISH (LIVE NOW)</option>
                                        <option value="draft">DRAFT (HIDDEN)</option>
                                     </select>
                                  </div>
                                  <div className="space-y-1">
                                     <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">Initial Stock Level</label>
                                     <input
                                        type="number"
                                        value={formData.stock === undefined ? '' : formData.stock}
                                        onChange={(e) => setFormData(prev => ({ ...prev, stock: Number(e.target.value) }))}
                                        className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-md text-xs font-bold outline-none"
                                     />
                                  </div>
                               </div>
                               <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                                  <h4 className="text-xs font-medium text-slate-900 uppercase tracking-wider mb-4">Storefront Preview</h4>
                                  <div className="flex gap-4">
                                     <div className="w-20 h-20 rounded-xl bg-white border border-slate-200 overflow-hidden shrink-0 shadow-sm">
                                        <img src={formData.image || LOCALIZATION.FALLBACK_IMAGE} className="w-full h-full object-cover" />
                                     </div>
                                     <div className="space-y-1">
                                        <p className="text-xs font-black text-slate-900 uppercase tracking-tight leading-tight">{formData.name || 'Unnamed Product'}</p>
                                        <p className="text-xs text-slate-500 font-bold uppercase">{formData.category}</p>
                                        <div className="flex items-baseline gap-2 pt-1">
                                           <span className="text-xs font-black text-slate-900">{LOCALIZATION.CURRENCY}{(Number(formData.price) || 0).toLocaleString()}</span>
                                            {formData.mrp > 0 && <span className="text-xs text-slate-400 line-through ml-2">{LOCALIZATION.CURRENCY}{(Number(formData.mrp) || 0).toLocaleString()}</span>}
                                        </div>
                                     </div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                    </motion.div>
                  )}

                </div>
              </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Deactivate Product</h3>
                <button onClick={() => setShowDeleteConfirm(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex items-start gap-4">
                  <div className="p-2 bg-rose-500 text-white rounded-lg">
                    <Trash size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Soft Delete Action</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      Are you sure you want to deactivate this product? It will be hidden from customers but you can still restore it from the "Deactivated" filter later.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setShowDeleteConfirm(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={() => {
                    onDeleteProduct(showDeleteConfirm);
                    setShowDeleteConfirm(null);
                  }}
                  className="px-8 py-3 bg-rose-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-950/20"
                >
                  Deactivate Product
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Modal
        isOpen={isFolderPickerOpen}
        onClose={() => setIsFolderPickerOpen(false)}
        title="Select Folder"
      >
        <div className="max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
          <MediaLibrary 
            token={token} 
            onShowNotification={onShowNotification} 
            onSelect={(path) => {
              setFormData(prev => ({ ...prev, folder: path }));
              setIsFolderPickerOpen(false);
            }}
          />
        </div>
      </Modal>
    </>
  );
};

export default AdminProducts;
