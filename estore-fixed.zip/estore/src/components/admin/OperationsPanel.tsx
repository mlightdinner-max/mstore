import React, { useState, useEffect } from 'react';
import { 
  Package, ShoppingBag, Brain, Activity, Trash2, RefreshCw, ExternalLink, FileText, Zap 
} from 'lucide-react';
import { Product, Order, AIAlert } from '../../types';
import { AdminSectionHeader } from './AdminSectionHeader';

interface OperationsPanelProps {
  products: Product[];
  orders: Order[];
  alerts: AIAlert[];
  config: any;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  token: string | null;
}

export const OperationsPanel = ({ 
  products, 
  orders, 
  alerts, 
  onShowNotification,
  token
}: OperationsPanelProps) => {
  const [logs, setLogs] = useState<{ id: string; type: 'info' | 'warning' | 'error'; message: string; timestamp: string }[]>([]);

  const outOfStockCount = products.filter(p => (p.stock || 0) <= 0).length;
  const lowStockCount = products.filter(p => (p.stock || 0) > 0 && (p.stock || 0) <= 10).length;

  const fetchLogs = React.useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/v1/dashboard/metrics/logs', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (err) {
      console.error("Failed to fetch system logs:", err);
    }
  }, [token]);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (mounted) await fetchLogs();
    };
    load();
    const interval = setInterval(() => {
      if (mounted) fetchLogs();
    }, 30000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [fetchLogs]);

  const clearLogs = async () => {
    if (!token) return;
    try {
      await fetch('/api/v1/dashboard/metrics/logs', {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      setLogs([]);
      onShowNotification('System logs cleared successfully', 'success');
    } catch {
      onShowNotification('Failed to clear logs', 'error');
    }
  };
  
  const calculateHealth = () => {
    let health = 100;
    if (alerts.some(a => a.severity === 'critical')) health -= 30;
    if (alerts.some(a => a.severity === 'high')) health -= 15;
    if (outOfStockCount > 5) health -= 10;
    if (lowStockCount > 10) health -= 5;
    return Math.max(0, health);
  };

  const healthValue = `${calculateHealth()}%`;

  const stats = [
    { label: 'Inventory Health', value: outOfStockCount > 0 ? `${outOfStockCount} Out` : 'Good', icon: Package, color: outOfStockCount > 0 ? 'text-rose-600' : 'text-emerald-600', bg: outOfStockCount > 0 ? 'bg-rose-50' : 'bg-emerald-50' },
    { label: 'Total Orders', value: orders.length, icon: ShoppingBag, color: 'text-primary', bg: 'bg-primary/5' },
    { label: 'Security Alerts', value: alerts.length, icon: Brain, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'System Health', value: healthValue, icon: Activity, color: calculateHealth() > 90 ? 'text-emerald-600' : 'text-amber-600', bg: calculateHealth() > 90 ? 'bg-emerald-50' : 'bg-amber-50' },
  ];

  return (
    <div className="space-y-5 pb-8">
      <AdminSectionHeader 
        title="System Monitor" 
        description="Monitor system health, view logs, and perform operational tasks." 
        icon={Activity}
        options={[{"label":"System Logs","description":"View real-time operational events and system status."},{"label":"Operational Tools","description":"Export reports and optimize performance."}]} 
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
            <div className={`w-8 h-8 ${stat.bg} ${stat.color} rounded-lg flex items-center justify-center mb-3 group-hover:scale-105 transition-transform`}>
              <stat.icon size={16} />
            </div>
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-0.5">{stat.label}</p>
            <h3 className="text-lg font-bold text-slate-900 tracking-tight">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-8 space-y-5">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">System Logs</h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Real-time operational events and system status.</p>
              </div>
              <div className="flex items-center space-x-1.5">
                <button 
                  onClick={clearLogs}
                  className="p-1.5 bg-slate-50 text-slate-400 hover:text-red-600 transition-colors rounded-lg"
                  title="Clear Logs"
                >
                  <Trash2 size={14} />
                </button>
                <button 
                  onClick={() => window.location.reload()}
                  className="p-1.5 bg-slate-50 text-slate-400 hover:text-slate-900 transition-colors rounded-lg"
                  title="Refresh System"
                >
                  <RefreshCw size={14} />
                </button>
              </div>
            </div>
            <div className="p-5">
              <div className="space-y-2">
                {logs.length > 0 ? logs.map(log => (
                  <div key={log.id} className="flex items-start space-x-3 p-2.5 rounded-lg border border-slate-50 hover:bg-slate-50 transition-colors group">
                    <div className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                      log.type === 'error' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]' :
                      log.type === 'warning' ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]' :
                      'bg-primary/80 shadow-[0_0_8px_rgba(16,185,129,0.4)]'
                    }`} />
                    <div className="flex-1">
                      <p className="text-xs font-medium text-slate-900">{log.message}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                        {new Date(log.timestamp).toLocaleTimeString()} • {log.type}
                      </p>
                    </div>
                    <button className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-slate-900 transition-all">
                      <ExternalLink size={10} />
                    </button>
                  </div>
                )) : (
                  <div className="py-12 text-center">
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">No system logs to display</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-5">
          <div className="bg-slate-900 rounded-xl p-5 text-white relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 blur-[40px] rounded-full -mr-12 -mt-12 group-hover:bg-primary/20 transition-all duration-700" />
            <div className="relative z-10 space-y-3">
              <div className="w-8 h-8 bg-white/10 backdrop-blur-md rounded-lg flex items-center justify-center">
                <Activity size={16} className="text-primary/60" />
              </div>
              <div>
                <h3 className="text-base font-bold tracking-tight">Operational Tools</h3>
                <p className="text-slate-400 text-xs mt-0.5 leading-relaxed">Quick access to system-level operational tasks.</p>
              </div>
              <div className="space-y-2 pt-1">
                <button 
                  onClick={() => window.print()}
                  className="w-full py-2 bg-white/5 text-white border border-white/10 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  <FileText size={12} />
                  <span>Export System Report</span>
                </button>
                <button 
                  onClick={() => onShowNotification('System cache cleared', 'success')}
                  className="w-full py-2 bg-white/5 text-white border border-white/10 rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  <Zap size={12} />
                  <span>Optimize Performance</span>
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Server Status</h3>
            <div className="space-y-3">
              {[
                { label: 'API Server', status: 'Operational', color: 'text-primary/80' },
                { label: 'Database', status: 'Operational', color: 'text-primary/80' },
                { label: 'AI Engine', status: 'Operational', color: 'text-primary/80' },
                { label: 'Storage', status: '92% Full', color: 'text-amber-500' },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-600">{item.label}</span>
                  <span className={`text-xs font-medium uppercase tracking-wider ${item.color}`}>{item.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OperationsPanel;
