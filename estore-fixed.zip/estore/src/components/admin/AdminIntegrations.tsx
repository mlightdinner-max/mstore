import React, { useState } from 'react';
import { 
  Globe, Mail, MessageSquare, Shield, Save, RefreshCw, 
  ExternalLink, Key, Server, Lock, Send, LifeBuoy, Activity, CheckCircle2, Info, Bot, Settings2, ShoppingBag
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';

interface AdminIntegrationsProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
  isValidating?: boolean;
}

export const AdminIntegrations = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, isValidating }: AdminIntegrationsProps) => {
  const [activeTab, setActiveTab] = useState<'email' | 'whatsapp' | 'webhook' | 'meta' | 'agent'>('email');

  const updateEmailSetting = (key: string, value: any, type: 'orders' | 'support') => {
    const section = type === 'orders' ? 'orderEmail' : 'supportEmail';
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        [section]: {
          ...(config.integrations?.[section] || {}),
          [key]: value
        }
      }
    });
  };

  const updateWhatsappSetting = (key: string, value: any) => {
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        whatsapp: {
          ...(config.integrations?.whatsapp || {}),
          [key]: value
        }
      }
    });
  };

  const updateWebhookSetting = (key: string, value: any) => {
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        webhook: {
          ...(config.integrations?.webhook || {}),
          [key]: value
        }
      }
    });
  };

  const integrations = config.integrations || {};

  return (
    <AdminPageWrapper
      title="Integrations"
      description="Configure SMTP relays, messaging APIs, and custom webhooks for automated workflows."
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="bg-white border border-slate-200 p-1 rounded-2xl flex items-center gap-1 shadow-sm overflow-x-auto no-scrollbar">
          {[
            { id: 'email',     label: 'Email (SMTP)',    mobileLabel: 'Email',    icon: Mail        },
            { id: 'whatsapp',  label: 'WhatsApp',        mobileLabel: 'WhatsApp', icon: MessageSquare },
            { id: 'webhook',   label: 'Webhooks',        mobileLabel: 'Webhooks', icon: Globe       },
            { id: 'meta',      label: 'Meta Pixel',      mobileLabel: 'Meta',     icon: Activity    },
            { id: 'agent',     label: 'Fulfilment Agent',mobileLabel: 'Agent',    icon: Bot         },
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === tab.id ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <tab.icon size={12} />
              <span className="hidden xs:inline sm:inline">{tab.label}</span>
              <span className="xs:hidden sm:hidden">{tab.mobileLabel}</span>
            </button>
          ))}
        </div>
        
        {hasUnsavedChanges && (
          <button 
            onClick={onSave}
            disabled={isValidating}
            className="btn-primary flex items-center gap-2"
          >
            {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
            <span>Save Integrations</span>
          </button>
        )}
      </div>

      {activeTab === 'email' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          {/* Orders & Marketing SMTP */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Orders & Marketing</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Status Updates & Newsletters</p>
                </div>
              </div>
              <button 
                onClick={() => updateEmailSetting('enabled', !integrations.orderEmail?.enabled, 'orders')}
                className={`w-12 h-6 rounded-full transition-all relative ${integrations.orderEmail?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.orderEmail?.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">SMTP Host</label>
                <div className="relative">
                  <Server className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="smtp.example.com"
                    value={integrations.orderEmail?.host || ''}
                    onChange={(e) => updateEmailSetting('host', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Port</label>
                <input 
                  placeholder="587"
                  type="number"
                  value={integrations.orderEmail?.port || ''}
                  onChange={(e) => updateEmailSetting('port', parseInt(e.target.value), 'orders')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Username / Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="orders@store.com"
                    value={integrations.orderEmail?.user || ''}
                    onChange={(e) => updateEmailSetting('user', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="••••••••"
                    type="password"
                    value={integrations.orderEmail?.pass || ''}
                    onChange={(e) => updateEmailSetting('pass', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="md:col-span-2 space-y-2 pt-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Default Sender Address</label>
                <input 
                  placeholder="Orders & Billing <orders@yourdomain.com>"
                  value={integrations.orderEmail?.from || ''}
                  onChange={(e) => updateEmailSetting('from', e.target.value, 'orders')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            
            <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100 flex items-start gap-4">
              <div className="p-2 bg-blue-100 text-blue-600 rounded-xl">
                <Shield size={16} />
              </div>
              <p className="text-xs text-blue-800 font-medium leading-relaxed">
                This identity will be used for all automated order status changes, shipping alerts, and newsletter campaigns.
              </p>
            </div>
          </div>

          {/* Support SMTP */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
                  <LifeBuoy size={24} className="animate-spin-slow" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Support Desk</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Ticket Responses & Inquiries</p>
                </div>
              </div>
              <button 
                onClick={() => updateEmailSetting('enabled', !integrations.supportEmail?.enabled, 'support')}
                className={`w-12 h-6 rounded-full transition-all relative ${integrations.supportEmail?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.supportEmail?.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">SMTP Host</label>
                <div className="relative">
                  <Server className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="smtp.support-host.com"
                    value={integrations.supportEmail?.host || ''}
                    onChange={(e) => updateEmailSetting('host', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Port</label>
                <input 
                  placeholder="465 (SSL)"
                  type="number"
                  value={integrations.supportEmail?.port || ''}
                  onChange={(e) => updateEmailSetting('port', parseInt(e.target.value), 'support')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Username / Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="support@helpdesk.com"
                    value={integrations.supportEmail?.user || ''}
                    onChange={(e) => updateEmailSetting('user', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="••••••••"
                    type="password"
                    value={integrations.supportEmail?.pass || ''}
                    onChange={(e) => updateEmailSetting('pass', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="md:col-span-2 space-y-2 pt-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Support From Address</label>
                <input 
                  placeholder="Customer Concierge <help@yourdomain.com>"
                  value={integrations.supportEmail?.from || ''}
                  onChange={(e) => updateEmailSetting('from', e.target.value, 'support')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>

            <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100 flex items-start gap-4">
              <div className="p-2 bg-amber-100 text-amber-600 rounded-xl">
                <ExternalLink size={16} />
              </div>
              <p className="text-xs text-amber-800 font-medium leading-relaxed">
                Replies sent from the Ticketing System will use this specific identity, keeping support threads separate from marketing.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'whatsapp' && (
        <div className="max-w-3xl bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                <MessageSquare size={24} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">WhatsApp (Twilio)</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Official Messaging API</p>
              </div>
            </div>
            <button 
              onClick={() => updateWhatsappSetting('enabled', !integrations.whatsapp?.enabled)}
              className={`w-12 h-6 rounded-full transition-all relative ${integrations.whatsapp?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.whatsapp?.enabled ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
            <div className="md:col-span-2 space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Account SID</label>
              <div className="relative">
                <ExternalLink className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="AC00000000000000000000000000000000"
                  value={integrations.whatsapp?.accountSid || ''}
                  onChange={(e) => updateWhatsappSetting('accountSid', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Auth Token</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="••••••••••••••••••••••••••••••••"
                  type="password"
                  value={integrations.whatsapp?.apiKey || ''}
                  onChange={(e) => updateWhatsappSetting('apiKey', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Sender Mobile Number</label>
              <div className="relative">
                <Send className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="+14150000000"
                  value={integrations.whatsapp?.fromNumber || ''}
                  onChange={(e) => updateWhatsappSetting('fromNumber', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'webhook' && (
        <div className="max-w-3xl bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center">
                <Globe size={24} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Outgoing Webhooks</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Real-time Event Streams</p>
              </div>
            </div>
            <button 
              onClick={() => updateWebhookSetting('enabled', !integrations.webhook?.enabled)}
              className={`w-12 h-6 rounded-full transition-all relative ${integrations.webhook?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.webhook?.enabled ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="space-y-6 pt-4 border-t border-slate-50">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Payload URL</label>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="https://api.yourbackend.com/webhooks/orders"
                  value={integrations.webhook?.url || ''}
                  onChange={(e) => updateWebhookSetting('url', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Secret Signature</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="shsec_12345..."
                  type="password"
                  value={integrations.webhook?.secret || ''}
                  onChange={(e) => updateWebhookSetting('secret', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="p-5 bg-purple-50/50 rounded-2xl border border-purple-100">
              <h4 className="text-xs font-medium text-purple-900 uppercase tracking-wider mb-2">Events Subscribed</h4>
              <div className="flex flex-wrap gap-2">
                {['order.created', 'order.updated', 'customer.registered', 'inventory.low'].map(event => (
                  <span key={event} className="px-3 py-1 bg-white border border-purple-100 rounded-lg text-xs font-bold text-purple-600 tracking-tight">
                    {event}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      {activeTab === 'meta' && (
        <div className="space-y-6">
          {/* Header card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl shrink-0">
                <Activity size={22} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight mb-1">Meta Pixel</h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  The Meta Pixel tracks customer actions on your store (views, add to cart, purchases) and sends
                  them to Meta so your Instagram and Facebook ads can find buyers like yours automatically.
                  It is the single most important setup step before running paid ads.
                </p>
              </div>
            </div>

            {/* Pixel ID input */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">
                Meta Pixel ID
              </label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input
                  type="text"
                  value={config.metaPixelId || ''}
                  onChange={e => onUpdateConfig({ ...config, metaPixelId: e.target.value.trim() })}
                  placeholder="e.g. 1234567890123456"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-900"
                />
              </div>
              <p className="text-xs text-slate-400 font-medium ml-1">
                Found in Meta Business Manager → Events Manager → your Pixel → Settings.
              </p>
            </div>

            {/* Live status indicator */}
            {config.metaPixelId ? (
              <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 rounded-xl border border-emerald-100">
                <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                <div>
                  <p className="text-xs font-black text-emerald-800 uppercase tracking-wide">Pixel Active</p>
                  <p className="text-xs text-emerald-700 font-medium">ID: {config.metaPixelId} — tracking events on every storefront page.</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 px-4 py-3 bg-amber-50 rounded-xl border border-amber-100">
                <Info size={16} className="text-amber-600 shrink-0" />
                <p className="text-xs font-medium text-amber-700">
                  No Pixel ID configured. Enter your ID above and save to start tracking.
                </p>
              </div>
            )}
          </div>

          {/* Events fired */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-4">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">Events Tracked Automatically</h4>
            <div className="space-y-3">
              {[
                { event: 'PageView',         when: 'Every page load and navigation',             value: false },
                { event: 'ViewContent',      when: 'Customer opens a product detail page',       value: true  },
                { event: 'AddToCart',        when: 'Customer adds any product to cart',          value: true  },
                { event: 'InitiateCheckout', when: 'Customer reaches the checkout page',         value: true  },
                { event: 'Purchase',         when: 'Customer places an order successfully',      value: true  },
                { event: 'Search',           when: 'Customer uses the search bar',               value: false },
              ].map(({ event, when, value }) => (
                <div key={event} className="flex items-start justify-between gap-4 py-3 border-b border-slate-50 last:border-0">
                  <div>
                    <p className="text-xs font-black text-slate-900 font-mono">{event}</p>
                    <p className="text-xs text-slate-500 font-medium mt-0.5">{when}</p>
                  </div>
                  <span className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${value ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    {value ? 'With Value' : 'Standard'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Setup guide */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-4">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">How to Find Your Pixel ID</h4>
            <ol className="space-y-3">
              {[
                'Go to business.facebook.com and log in with your Facebook account.',
                'Open the top-left menu → "Events Manager".',
                'If you have no Pixel yet, click "Connect data sources" → "Web" → "Meta Pixel" → name it and click Create.',
                'Click your Pixel name → go to the "Settings" tab.',
                'Copy the 15–16 digit number shown under "Pixel ID".',
                'Paste it in the field above and click Save Configuration.',
              ].map((step, i) => (
                <li key={i} className="flex gap-3 text-xs text-slate-600 font-medium leading-relaxed">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-black">{i + 1}</span>
                  {step}
                </li>
              ))}
            </ol>
            <a
              href="https://business.facebook.com/events_manager"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors mt-2"
            >
              <ExternalLink size={12} />
              Open Meta Events Manager
            </a>
          </div>
        </div>
      )}
      {activeTab === 'agent' && (
        <div className="space-y-6">

          {/* Master toggle */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-violet-50 text-violet-600 rounded-xl shrink-0">
                  <Bot size={22} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight mb-1">Meesho Fulfilment Agent</h3>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed max-w-lg">
                    Automatically places orders on Meesho when you confirm via Telegram.
                    Handles cancellations and returns too. Runs as a separate process alongside your store.
                  </p>
                </div>
              </div>
              <button
                onClick={() => onUpdateConfig({ ...config, agentSettings: { ...(config.agentSettings ?? { maxAttempts: 3, retryDelayMinutes: 15 }), enabled: !(config.agentSettings?.enabled), autoPlace: config.agentSettings?.autoPlace ?? false } })}
                className={`relative w-14 h-7 rounded-full transition-colors shrink-0 ${config.agentSettings?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-md transition-all ${config.agentSettings?.enabled ? 'left-8' : 'left-1'}`} />
              </button>
            </div>
          </div>

          {/* Telegram settings */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-sky-50 text-sky-600 rounded-xl">
                <MessageSquare size={18} />
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">Telegram Bot</h4>
                <p className="text-xs text-slate-500 font-medium">Set env vars TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID on your server, or enter them here.</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Bot Token</label>
                <div className="relative">
                  <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input
                    type="password"
                    value={config.telegramSettings?.botToken || ''}
                    onChange={e => onUpdateConfig({ ...config, telegramSettings: { ...(config.telegramSettings ?? {}), botToken: e.target.value } })}
                    placeholder="From @BotFather e.g. 123456:ABC..."
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Your Chat ID</label>
                <div className="relative">
                  <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input
                    type="text"
                    value={config.telegramSettings?.chatId || ''}
                    onChange={e => onUpdateConfig({ ...config, telegramSettings: { ...(config.telegramSettings ?? {}), chatId: e.target.value } })}
                    placeholder="e.g. 987654321"
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                  />
                </div>
              </div>
            </div>
            <div className="p-4 bg-sky-50 rounded-xl border border-sky-100 text-xs text-sky-800 font-medium space-y-1">
              <p className="font-black">How to get your Chat ID:</p>
              <p>1. Create a bot via <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" className="underline">@BotFather</a> — copy the token above</p>
              <p>2. Send any message to your new bot</p>
              <p>3. Visit: <code className="bg-white px-1 rounded">https://api.telegram.org/bot&lt;TOKEN&gt;/getUpdates</code></p>
              <p>4. Find <code className="bg-white px-1 rounded">result[0].message.chat.id</code> — that's your Chat ID</p>
            </div>
          </div>

          {/* Meesho credentials */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-pink-50 text-pink-600 rounded-xl">
                <ShoppingBag size={18} />
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">Meesho Account</h4>
                <p className="text-xs text-slate-500 font-medium">The account the agent will use to place orders. Set env vars MEESHO_EMAIL and MEESHO_PASSWORD for higher security.</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Meesho Email / Phone</label>
                <input
                  type="email"
                  value={config.meeshoSettings?.email || ''}
                  onChange={e => onUpdateConfig({ ...config, meeshoSettings: { ...(config.meeshoSettings ?? {}), email: e.target.value } })}
                  placeholder="your@email.com"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Meesho Password</label>
                <input
                  type="password"
                  value={config.meeshoSettings?.password || ''}
                  onChange={e => onUpdateConfig({ ...config, meeshoSettings: { ...(config.meeshoSettings ?? {}), password: e.target.value } })}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                />
              </div>
            </div>
            <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-xl border border-amber-100">
              <Info size={14} className="text-amber-600 mt-0.5 shrink-0" />
              <p className="text-xs text-amber-700 font-medium">
                For maximum security, set these as environment variables on your server instead of saving here.
                Environment variables take precedence if both are set.
              </p>
            </div>
          </div>

          {/* Agent behaviour settings */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 text-slate-600 rounded-xl">
                <Settings2 size={18} />
              </div>
              <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">Behaviour</h4>
            </div>

            {/* Auto-place toggle */}
            <div className="flex items-center justify-between py-3 border-b border-slate-100">
              <div>
                <p className="text-xs font-black text-slate-900">Auto-Place Orders</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  OFF (recommended) — send Telegram notification first, wait for your confirmation.<br/>
                  ON — place on Meesho immediately without waiting for confirmation.
                </p>
              </div>
              <button
                onClick={() => onUpdateConfig({ ...config, agentSettings: { ...(config.agentSettings ?? { enabled: false, maxAttempts: 3, retryDelayMinutes: 15 }), autoPlace: !config.agentSettings?.autoPlace } })}
                className={`relative w-14 h-7 rounded-full transition-colors ml-4 shrink-0 ${config.agentSettings?.autoPlace ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-md transition-all ${config.agentSettings?.autoPlace ? 'left-8' : 'left-1'}`} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Max Retry Attempts</label>
                <input
                  type="number" min={1} max={10}
                  value={config.agentSettings?.maxAttempts ?? 3}
                  onChange={e => onUpdateConfig({ ...config, agentSettings: { ...(config.agentSettings ?? { enabled: false, autoPlace: false, retryDelayMinutes: 15 }), maxAttempts: parseInt(e.target.value) || 3 } })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Retry Delay (minutes)</label>
                <input
                  type="number" min={1} max={120}
                  value={config.agentSettings?.retryDelayMinutes ?? 15}
                  onChange={e => onUpdateConfig({ ...config, agentSettings: { ...(config.agentSettings ?? { enabled: false, autoPlace: false, maxAttempts: 3 }), retryDelayMinutes: parseInt(e.target.value) || 15 } })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                />
              </div>
            </div>
          </div>

          {/* How to run */}
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-4">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">How to Start the Agent</h4>
            <ol className="space-y-3">
              {[
                'Install dependencies: npm install playwright && npx playwright install chromium',
                'Add TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, MEESHO_EMAIL, MEESHO_PASSWORD to your .env file',
                'Run: npm run agent  (or: npx tsx agent/index.ts)',
                'The agent will send a confirmation message to your Telegram when it starts',
                'Keep the agent running alongside your store server — use PM2 for process management',
              ].map((step, i) => (
                <li key={i} className="flex gap-3 text-xs text-slate-600 font-medium leading-relaxed">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-black">{i + 1}</span>
                  {step}
                </li>
              ))}
            </ol>
            <div className="mt-4 p-4 bg-slate-900 rounded-xl">
              <pre className="text-xs text-emerald-400 font-mono leading-relaxed">{`# Run store + agent together with PM2
npm install -g pm2
pm2 start dist/server.js --name estore
pm2 start agent/index.ts --interpreter tsx --name agent
pm2 save`}</pre>
            </div>
          </div>

        </div>
      )}
    </AdminPageWrapper>
  );
};
