import React, { useMemo } from 'react';
import { DollarSign, ShoppingBag, 
  Users, Activity, 
  BarChart3, BarChart2, PieChart as PieChartIcon, Calendar 
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, 
  CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { Order, Product } from '../../types';
import { LOCALIZATION } from '../../constants';
import { StatsCard } from './StatsCard';

interface AdminAnalyticsProps {
  orders: Order[];
  products?: Product[];
  hideMetrics?: boolean;
  hideStats?: boolean;
  height?: number;
}

import { AdminPageWrapper } from './AdminPageWrapper';

const AdminAnalytics = ({ orders, hideMetrics = false, hideStats = false, height = 300 }: AdminAnalyticsProps) => {
  const stats = useMemo(() => {
    const validOrders = orders.filter(o => o.status !== 'Cancelled' && o.status !== 'Returned');
    const totalRevenue = validOrders.reduce((sum, o) => sum + o.total, 0);
    const totalOrders = validOrders.length;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const totalCustomers = new Set(validOrders.map(o => o.email)).size;

    // Build a daily sales chart from the orders already passed in (which may already be
    // filtered by a date range from the parent). Show up to the last 30 unique days present
    // in the data, so the chart always reflects the active date filter rather than a hardcoded window.
    const dayMap = new Map<string, { sales: number; orders: number; ts: number }>();
    validOrders.forEach(o => {
      const d = new Date(o.createdAt);
      const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const existing = dayMap.get(dateStr) || { sales: 0, orders: 0, ts: d.getTime() };
      dayMap.set(dateStr, {
        sales: existing.sales + o.total,
        orders: existing.orders + 1,
        ts: Math.min(existing.ts, d.getTime()),
      });
    });
    const chartDays = Array.from(dayMap.entries())
      .map(([name, v]) => ({ name, sales: v.sales, orders: v.orders, ts: v.ts }))
      .sort((a, b) => a.ts - b.ts)
      .slice(-30)  // cap at 30 data points
      .map(({ name, sales, orders }) => ({ name, sales, orders }));

    // Category Distribution - top 5
    const categoryData: Record<string, number> = {};
    validOrders.forEach(o => {
      o.items.forEach(item => {
        const cat = item.category || 'Uncategorized';
        categoryData[cat] = (categoryData[cat] || 0) + (item.price * item.quantity);
      });
    });
    const pieData = Object.entries(categoryData)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);

    return { totalRevenue, totalOrders, avgOrderValue, totalCustomers, last7Days: chartDays, pieData };
  }, [orders]);

  const COLORS = ['#0f172a', '#334155', '#64748b', '#94a3b8', '#cbd5e1'];

  const Content = (
    <div className="space-y-10">
      {!hideStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Total Revenue" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalRevenue.toLocaleString()}`} 
          icon={DollarSign} 
          color="emerald"
          delay={0.1}
        />
        <StatsCard 
          label="Total Orders" 
          value={stats.totalOrders} 
          icon={ShoppingBag} 
          color="blue"
          delay={0.2}
        />
        <StatsCard 
          label="Avg Order Value" 
          value={`${LOCALIZATION.CURRENCY}${Math.round(stats.avgOrderValue).toLocaleString()}`} 
          icon={Activity} 
          color="amber"
          delay={0.3}
        />
        <StatsCard 
          label="Active Customers" 
          value={stats.totalCustomers} 
          icon={Users} 
          color="indigo"
          delay={0.4}
        />
      </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-slate-900 text-white rounded-xl">
                <BarChart3 size={20} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-950 uppercase tracking-widest">Sales Performance</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Revenue trend over the last 7 days</p>
              </div>
            </div>
          </div>
          <div style={{height: `${height}px`}} className="w-full">
            {stats.last7Days.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-300">
                <BarChart2 size={32} className="mb-2 opacity-40" />
                <p className="text-xs font-medium text-slate-400">No orders in this date range</p>
              </div>
            ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.last7Days}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0f172a" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                  tickFormatter={(value) => `${LOCALIZATION.CURRENCY}${value >= 1000 ? (value/1000).toFixed(1) + 'k' : value}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    border: 'none', 
                    borderRadius: '12px', 
                    color: '#fff',
                    fontSize: '10px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em'
                  }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#0f172a" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorSales)" 
                />
              </AreaChart>
            </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="bg-white p-4 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-4 overflow-hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-900 text-white rounded-xl">
              <PieChartIcon size={20} />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-950 uppercase tracking-widest">Revenue by Category</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Sales distribution across categories</p>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {stats.pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    border: 'none', 
                    borderRadius: '12px', 
                    color: '#fff',
                    fontSize: '10px',
                    fontWeight: 700
                  }}
                />
                <Legend 
                  verticalAlign="bottom" 
                  height={36}
                  formatter={(value) => <span className="text-xs font-medium uppercase tracking-wider text-slate-500">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );

  if (hideMetrics) return Content;

  return (
    <AdminPageWrapper
      title="Analytics & Reports"
      description="Comprehensive insights into your business growth, sales performance, and product popularity."
      icon={BarChart3}
      options={[
        {"label":"Date Filtering","description":"Analyze performance over specific time periods."},
        {"label":"Export CSV","description":"Download report data for external analysis."}
      ]}
      actions={
        <div className="bg-white px-6 py-2.5 rounded-xl border border-slate-200 text-xs font-medium uppercase tracking-wider flex items-center gap-2 shadow-sm text-slate-600">
          <Calendar size={14} className="text-slate-400" />
          7-Day Trends
        </div>
      }
    >
      {Content}
    </AdminPageWrapper>
  );
};

export default AdminAnalytics;
