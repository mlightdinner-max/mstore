import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, Zap, Shield, AlertCircle,
  CheckCircle2, ArrowUpRight,
  ShieldCheck, Trash2, Terminal, Tag
} from 'lucide-react';
import { AIAlert } from '../../types';
import { StatsCard } from './StatsCard';

interface CommandCenterProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  onSave?: () => Promise<void>;
  alerts: AIAlert[];
  onClearAlerts: () => void;
  onDeleteAlert: (id: string) => void;
  aiStatus: any;
  onRefreshAiStatus: (apiKey?: string) => Promise<void>;
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

const CommandCenter = ({ 
  config, 
  onUpdateConfig, 
  onSave,
  alerts, 
  onClearAlerts, 
  onDeleteAlert,
  aiStatus,
  onRefreshAiStatus
}: CommandCenterProps) => {
  const [activeTab, setActiveTab] = useState<'alerts' | 'config' | 'logs'>('alerts');
  const [searchQuery, setSearchQuery] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<{ success: boolean; message: string; type?: string } | null>(null);

  const handleValidateKey = async () => {
    if (!config.aiSettings?.enabled) return;
    setIsValidating(true);
    setValidationResult(null);
    try {
      const res = await fetch('/api/v1/ai/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: config.geminiApiKey })
      });
      const data = await res.json();
      setValidationResult({
        success: data.success,
        message: data.success ? "API connection verified and active." : (data.error || "Validation failed."),
        type: data.type
      });
      
      // Refresh global status with the current key
      if (data.success) {
        onRefreshAiStatus(config.geminiApiKey);
      }
    } catch {
      setValidationResult({ success: false, message: "Network error during validation." });
    } finally {
      setIsValidating(false);
    }
  };

  const features = [
    { key: 'useProductDescriptions', label: 'Product Copy Engine', desc: 'Auto-generate SEO descriptions for your catalog.', icon: Tag },
    { key: 'useCheckoutValidation', label: 'Checkout Sentinel', desc: 'Detect gibberish and fraud attempts in real-time.', icon: ShieldCheck },
    { key: 'useRecommendations', label: 'Personalization Hub', desc: 'AI-driven product discovery for your customers.', icon: Zap },
    { key: 'useBlogGeneration', label: 'Content Orchestrator', desc: 'Generate full blog posts from simple titles.', icon: Brain }
  ];

  const filteredAlerts = alerts.filter(a => 
    a.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (a.details && JSON.stringify(a.details).toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getCooldownStatus = () => {
    if (!aiStatus || !aiStatus.cooldownUntil) return null;
    const now = new Date().getTime();
    const remaining = Math.max(0, Math.ceil((aiStatus.cooldownUntil - now) / 60000));
    return remaining > 0 ? `${remaining}m cooldown` : null;
  };

  const updateAiSetting = (key: string, value: any) => {
    onUpdateConfig({
      ...config,
      aiSettings: {
        ...(config.aiSettings || { enabled: false, useProductDescriptions: false, useCheckoutValidation: false, useRecommendations: false, useBlogGeneration: false }),
        [key]: value
      }
    });
  };

  const tabIcons = {
    alerts: AlertCircle,
    config: Zap,
    logs: Terminal
  };

  return (
    <AdminPageWrapper
      title="AI Command Center"
      description="Monitor AI-driven fraud alerts, configure AI features, and run system diagnostics."
      icon={Brain}
      options={[
        { label: 'View Alerts', description: 'Review and dismiss AI-generated security and fraud alerts.' },
        { label: 'Run Diagnostics', description: 'Manually trigger an AI analysis of your store data.' }
      ]}
      toolbar={
        <AdminToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder={
            activeTab === 'alerts' ? "Search intelligence alerts..." : 
            activeTab === 'config' ? "Search AI features..." : 
            "Search system logs..."
          }
          leftActions={
            <div className="flex items-center space-x-1 p-1 bg-slate-200/50 rounded-2xl">
              {(['alerts', 'config', 'logs'] as const).map((tab) => {
                const Icon = tabIcons[tab];
                return (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center space-x-2 ${
                      activeTab === tab ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <Icon size={12} />
                    <span>{tab}</span>
                  </button>
                );
              })}
            </div>
          }
          filters={
            activeTab === 'alerts' && alerts.length > 0 ? (
              <button 
                onClick={onClearAlerts}
                className="px-6 py-2.5 bg-slate-50 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all border border-slate-200 text-xs font-medium uppercase tracking-wider flex items-center gap-2"
              >
                <Trash2 size={14} />
                <span>Clear All</span>
              </button>
            ) : null
          }
        />
      }
    >
      {/* AI Status Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`rounded-2xl p-6 text-white relative overflow-hidden group shadow-2xl transition-all duration-500 ${
          !config.aiSettings?.enabled ? 'bg-slate-800' :
          aiStatus?.isHealthy ? 'bg-slate-900 shadow-slate-900/20' : 'bg-rose-950 shadow-rose-900/20'
        }`}>
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-500">
            <Brain size={120} />
          </div>
          <div className="relative z-10 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-white/10 rounded-xl backdrop-blur-md">
                <Brain size={20} className={aiStatus?.isHealthy ? 'text-blue-400' : 'text-rose-400'} />
              </div>
              <span className={`text-xs font-medium uppercase tracking-wider ${aiStatus?.isHealthy ? 'text-blue-400' : 'text-rose-400'}`}>
                Core Intelligence
              </span>
            </div>
            <div>
              <h3 className="text-2xl font-black italic tracking-tighter uppercase leading-none">Gemini 1.5 Flash</h3>
              <div className="flex items-center justify-between mt-2">
                <p className="text-xs font-bold text-slate-100/90 uppercase tracking-widest leading-none flex items-center gap-2">
                  {!config.aiSettings?.enabled ? (
                    'System Disabled'
                  ) : aiStatus?.status === 'no-key' ? (
                    <>
                      <AlertCircle size={10} className="text-amber-400" />
                      <span>No API Key</span>
                    </>
                  ) : aiStatus?.status === 'quota' ? (
                    'API Quota Exceeded'
                  ) : aiStatus?.status === 'auth' ? (
                    'Invalid API Key'
                  ) : aiStatus?.isHealthy ? (
                    <>
                      <CheckCircle2 size={10} className="text-emerald-400" />
                      <span>Active & Monitoring</span>
                    </>
                  ) : (
                    'System Degraded'
                  )}
                </p>
                {aiStatus?.isUnsavedKey && (
                  <div className="px-2 py-1 bg-indigo-500/20 border border-indigo-500/30 rounded-lg">
                    <p className="text-xs font-black text-indigo-100 uppercase tracking-tighter animate-pulse leading-none">
                      Save Required to Activate
                    </p>
                  </div>
                )}
              </div>
            </div>
            <div className="pt-4 flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full animate-pulse ${
                !config.aiSettings?.enabled ? 'bg-slate-500' :
                aiStatus?.isAvailable ? 'bg-emerald-500' : 'bg-rose-500'
              }`} />
              <span className={`text-xs font-medium uppercase tracking-wider ${
                !config.aiSettings?.enabled ? 'text-slate-500' :
                aiStatus?.isAvailable ? 'text-emerald-500' : 'text-rose-500'
              }`}>
                {!config.aiSettings?.enabled ? 'Offline' : 
                 aiStatus?.status === 'no-key' ? 'No API Key' :
                 aiStatus?.status === 'quota' ? 'API Quota Exceeded' :
                 aiStatus?.status === 'auth' ? 'Invalid API Key' :
                 aiStatus?.isAvailable ? 'System Nominal' : getCooldownStatus() || 'Error'}
              </span>
            </div>
          </div>
        </div>

        <StatsCard 
          label="Active Alerts" 
          value={alerts.length} 
          icon={AlertCircle} 
          color={alerts.length > 5 ? "rose" : "amber"}
          subtext={`Health: ${Math.max(0, 100 - alerts.length * 5)}%`}
          delay={0.1}
        />

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Free Tier Policy</p>
              <h4 className="text-sm font-black text-slate-900 mt-2 uppercase italic tracking-tighter">
                Rate Limited
              </h4>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">
                15 RPM / 1M TPM
              </p>
            </div>
            <div className={`p-3 rounded-2xl bg-slate-50 text-slate-400`}>
              <Zap size={20} />
            </div>
          </div>
          <p className="mt-4 text-xs text-slate-500 font-medium leading-relaxed italic">
            "Reduced features active to respect free tier limitations. Monitoring frequency is optimized."
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 min-h-[400px]">
        <AnimatePresence mode="wait">
            {activeTab === 'alerts' && (
              <motion.div 
                key="alerts"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                {filteredAlerts.length > 0 ? filteredAlerts.map((alert, idx) => (
                  <div 
                    key={`${alert.id}-${idx}`}
                    className={`p-5 rounded-3xl border flex items-start space-x-4 group transition-all hover:shadow-lg hover:shadow-slate-900/5 ${
                      alert.severity === 'critical' ? 'bg-red-50/30 border-red-100' :
                      alert.severity === 'high' ? 'bg-amber-50/30 border-amber-100' :
                      'bg-blue-50/30 border-blue-100'
                    }`}
                  >
                    <div className={`p-3 rounded-2xl ${
                      alert.severity === 'critical' ? 'bg-red-100 text-red-600' :
                      alert.severity === 'high' ? 'bg-amber-100 text-amber-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {alert.severity === 'critical' ? <Shield size={20} /> :
                       alert.severity === 'high' ? <AlertCircle size={20} /> :
                       <Zap size={20} />}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-slate-900 tracking-tight">{alert.message}</h4>
                        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <div className="text-xs text-slate-500 leading-relaxed bg-slate-50/50 p-3 rounded-xl border border-slate-100 overflow-x-auto">
                        {alert.details ? (
                          typeof alert.details === 'string' ? alert.details :
                          <div className="space-y-2">
                            {alert.details.issues && Array.isArray(alert.details.issues) && (
                              <div className="space-y-1">
                                <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Flagged Issues:</span>
                                <ul className="list-disc list-inside">
                                  {alert.details.issues.map((issue: string, i: number) => (
                                    <li key={i}>{issue}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            {alert.details.formData && (
                              <div className="space-y-1 pt-2 border-t border-slate-200/60">
                                <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Customer Input Data:</span>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                                  {Object.entries(alert.details.formData).map(([key, val]: [string, any]) => (
                                    <div key={key} className="flex space-x-2">
                                      <span className="font-bold text-slate-400 shrink-0">{key}:</span>
                                      <span className="truncate">{String(val)}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            {!alert.details.issues && !alert.details.formData && (
                              <pre className="text-xs">{JSON.stringify(alert.details, null, 2)}</pre>
                            )}
                          </div>
                        ) : 'No additional details available.'}
                      </div>
                      <div className="pt-3 flex items-center space-x-4">
                        <button className="text-xs font-medium text-slate-900 uppercase tracking-wider hover:underline flex items-center space-x-1">
                          <span>Take Action</span>
                          <ArrowUpRight size={12} />
                        </button>
                        <button 
                          onClick={() => onDeleteAlert(alert.id)}
                          className="text-xs font-medium text-slate-400 uppercase tracking-wider hover:text-red-500"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  </div>
                )) : (
                  <div className="flex flex-col items-center justify-center py-20 space-y-4">
                    <div className="p-6 bg-slate-50 rounded-full">
                      <CheckCircle2 size={48} className="text-primary/80" />
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-medium uppercase tracking-wider text-slate-900">All Systems Clear</p>
                      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mt-1">No intelligence alerts detected at this time</p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'config' && (
              <motion.div 
                key="config"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-10"
              >
                {/* Master Switch */}
                <div className="relative group">
                  <div className={`absolute -inset-1 rounded-[2.8rem] bg-gradient-to-r from-primary/50 to-indigo-500/50 opacity-20 blur transition duration-1000 group-hover:opacity-40 group-hover:duration-200 ${config.aiSettings?.enabled ? 'animate-pulse' : 'hidden'}`}></div>
                  <div className="relative flex items-center justify-between p-8 bg-slate-950 rounded-2xl text-white shadow-2xl border border-white/10">
                    <div className="flex items-center gap-6">
                      <div className={`p-4 rounded-3xl transition-all duration-500 ${config.aiSettings?.enabled ? "bg-primary text-white shadow-[0_0_30px_rgba(59,130,246,0.6)]" : "bg-slate-800 text-slate-500 rotate-12"}`}>
                        <Brain size={28} className={config.aiSettings?.enabled ? "animate-pulse" : ""} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <h4 className="text-xl font-semibold tracking-tight italic text-white drop-shadow-sm">Master Orchestration</h4>
                          {config.aiSettings?.enabled ? (
                            <span className="px-3 py-1 bg-blue-600 text-white rounded-full text-xs font-medium uppercase tracking-wider border border-blue-400/30 animate-pulse shadow-[0_0_15px_rgba(37,99,235,0.4)]">Engaged</span>
                          ) : (
                            <span className="px-3 py-1 bg-slate-800 text-slate-400 rounded-full text-xs font-medium uppercase tracking-wider border border-slate-700">Hibernating</span>
                          )}
                        </div>
                        <p className="text-xs text-white/90 font-bold uppercase tracking-widest leading-tight drop-shadow-sm">Master override for all AI-supported subsystems and cognitive modules.</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-end gap-3">
                      <button 
                        onClick={() => updateAiSetting('enabled', !config.aiSettings?.enabled)}
                        className={`w-16 h-8 rounded-full transition-all relative overflow-hidden group/btn ${config.aiSettings?.enabled ? 'bg-primary' : 'bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-lg transition-all transform active:scale-95 z-10 ${config.aiSettings?.enabled ? 'left-9' : 'left-1'}`} />
                        {config.aiSettings?.enabled && (
                          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-primary animate-gradient-x" />
                        )}
                      </button>
                      <span className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">{config.aiSettings?.enabled ? 'Systems Online' : 'Manual Override Active'}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {/* Feature Toggles */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Integrated Skillsets</h4>
                    <div className="space-y-3">
                      {features.map((feature) => (
                        <div key={feature.key} className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-3xl group hover:border-primary/20 transition-all">
                          <div className="flex items-center gap-4">
                            <div className={`p-3 rounded-2xl ${config.aiSettings?.[feature.key] ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-400 shadow-sm'}`}>
                              <feature.icon size={16} />
                            </div>
                            <div>
                              <p className="text-xs font-bold text-slate-900 group-hover:text-primary transition-colors">{feature.label}</p>
                              <p className="text-xs text-slate-400 font-medium leading-tight mt-0.5">{feature.desc}</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => updateAiSetting(feature.key, !config.aiSettings?.[feature.key])}
                            className={`w-10 h-5 rounded-full transition-all relative ${config.aiSettings?.[feature.key] ? 'bg-primary' : 'bg-slate-200'}`}
                          >
                            <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${config.aiSettings?.[feature.key] ? 'left-5.5' : 'left-0.5'}`} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* API Key & Credentials */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between ml-1">
                      <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Signal Authentication</h4>
                      {aiStatus?.isHealthy && <span className="text-xs font-medium text-emerald-500 uppercase tracking-wider">Connected</span>}
                    </div>
                    <div className="p-6 bg-slate-50 border border-slate-100 rounded-2xl space-y-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                          <div className="flex items-center gap-3">
                            <div className={`w-2 h-2 rounded-full ${aiStatus?.usingEnvKey ? 'bg-indigo-500 shadow-sm shadow-indigo-500/50' : 'bg-slate-200'}`} />
                            <span className="text-xs font-medium text-slate-600 uppercase tracking-wider">Environment Key</span>
                          </div>
                          <span className={`text-xs font-medium uppercase tracking-wider ${aiStatus?.usingEnvKey ? 'text-indigo-600' : 'text-slate-400'}`}>
                            {aiStatus?.usingEnvKey ? 'Active' : 'N/A'}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Manual Override</label>
                        <div className="relative">
                          <Shield className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                          <input 
                            type="password"
                            placeholder={!config.aiSettings?.enabled ? "AI Orchestration Disabled" : "Enter Gemini API Key..."}
                            value={config.geminiApiKey || ''} 
                            onChange={(e) => onUpdateConfig({ ...config, geminiApiKey: e.target.value })}
                            disabled={!config.aiSettings?.enabled}
                            className={`w-full pl-10 pr-4 py-4 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/10 font-bold text-xs shadow-sm transition-all ${
                              !config.aiSettings?.enabled 
                                ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed' 
                                : 'bg-white border-slate-200'
                            }`} 
                          />
                        </div>
                        <p className="text-xs text-slate-400 font-medium italic mt-2 px-1">
                          "Manual keys override system-managed credentials."
                        </p>
                      </div>

                      {aiStatus?.isUnsavedKey && aiStatus?.status === 'healthy' && (
                        <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-indigo-100 text-indigo-600 rounded-xl">
                              <Shield size={16} />
                            </div>
                            <div>
                              <p className="text-xs font-black text-indigo-900 uppercase tracking-tight">Configuration Pending</p>
                              <p className="text-xs text-indigo-600 font-bold uppercase tracking-widest">A save is required to apply the new API credentials.</p>
                            </div>
                          </div>
                          <button 
                            onClick={onSave}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-black transition-all shadow-lg"
                          >
                            Save Configuration
                          </button>
                        </div>
                      )}

                      <button 
                        onClick={handleValidateKey}
                        disabled={!config.aiSettings?.enabled || isValidating}
                        className={`w-full py-4 rounded-2xl text-xs font-medium uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                          !config.aiSettings?.enabled 
                            ? 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-50' 
                            : isValidating ? 'bg-slate-700 text-white cursor-wait animate-pulse' : 'bg-slate-900 text-white hover:bg-slate-800'
                        }`}
                      >
                        {isValidating ? <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}><Zap size={14} /></motion.div> : <Zap size={14} />}
                        {isValidating ? 'Validating...' : 'Test Connectivity'}
                      </button>

                      {validationResult && (
                        <motion.div 
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className={`p-4 rounded-2x border text-xs font-medium uppercase tracking-wider ${
                            validationResult.success ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-rose-50 border-rose-100 text-rose-600'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {validationResult.success ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
                            <span>{validationResult.message}</span>
                          </div>
                        </motion.div>
                      )}
                    </div>
                  </div>
                </div>

                {/* System Prompts */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 border-t border-slate-100 pt-10">
                  <div className="space-y-4">
                    <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Traffic Monitor Context</h4>
                    <textarea 
                      value={config.aiPrompts?.monitor || ''} 
                      onChange={(e) => onUpdateConfig({ ...config, aiPrompts: { ...config.aiPrompts, monitor: e.target.value } })}
                      rows={4}
                      placeholder="Enter behavioral guidelines for visitor tracking..."
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-3xl focus:outline-none focus:ring-2 focus:ring-primary/10 font-bold text-xs leading-relaxed resize-none" 
                    />
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Order Guard Logic</h4>
                    <textarea 
                      value={config.aiPrompts?.validation || ''} 
                      onChange={(e) => onUpdateConfig({ ...config, aiPrompts: { ...config.aiPrompts, validation: e.target.value } })}
                      rows={4}
                      placeholder="Define strict constraints for fraud detection..."
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-3xl focus:outline-none focus:ring-2 focus:ring-primary/10 font-bold text-xs leading-relaxed resize-none" 
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'logs' && (
              <motion.div 
                key="logs"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col items-center justify-center py-20 space-y-4"
              >
                <div className="p-6 bg-slate-50 rounded-full border border-slate-100">
                  <Terminal size={48} className="text-slate-300" />
                </div>
                <div className="text-center max-w-sm">
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-900">System Logs</p>
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mt-2 leading-relaxed">Activity logs and AI orchestration requests will appear here when telemetry is enabled.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
    </AdminPageWrapper>
  );
};

export default CommandCenter;
