import React from 'react';
import { Palette, Type } from 'lucide-react';
import { Config } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';
import { ImageInput } from './ImageInput';

interface AdminBrandingProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  token: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

export const AdminBranding = ({ config, onUpdateConfig, token, onShowNotification }: AdminBrandingProps) => {
  return (
    <AdminPageWrapper
      title="Store Branding"
      description="Customise your store's visual identity, including logos, colours, and typography."
      icon={Palette}
      options={[{"label":"Upload Logo","description":"Set your primary store logo."},{"label":"Change Colours","description":"Define the primary and secondary brand colours."}]}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
              <Type size={20} />
            </div>
            <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Visual Identity</h3>
          </div>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Store Name</label>
              <input 
                type="text"
                value={config.storeName || ''}
                onChange={e => onUpdateConfig({ ...config, storeName: e.target.value })}
                placeholder="Enterprise Store"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black tracking-tight focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-950"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Brand Tagline</label>
              <input 
                type="text"
                value={config.storeTagline || ''}
                onChange={e => onUpdateConfig({ ...config, storeTagline: e.target.value })}
                placeholder="Excellence in every detail"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-600"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Store Description</label>
              <textarea 
                value={config.storeDescription || ''}
                onChange={e => onUpdateConfig({ ...config, storeDescription: e.target.value })}
                rows={3}
                placeholder="Describe your store's mission and value proposition..."
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium leading-relaxed focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none text-slate-600"
              />
            </div>

            <ImageInput 
              label="Primary Logo URL"
              value={config.logoUrl || ''}
              onChange={(url) => onUpdateConfig({ ...config, logoUrl: url })}
              token={token}
              onShowNotification={onShowNotification}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
              <ImageInput 
                label="Favicon URL"
                value={config.faviconUrl || ''}
                onChange={(url) => onUpdateConfig({ ...config, faviconUrl: url })}
                token={token}
                onShowNotification={onShowNotification}
              />
              <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-xl border border-slate-100 h-[68px]">
                <div className="w-10 h-10 bg-white border border-slate-200 rounded-lg flex items-center justify-center p-2 shadow-sm overflow-hidden">
                  {config.faviconUrl ? (
                    <img src={config.faviconUrl} alt="Favicon" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-4 h-4 bg-slate-100 rounded-sm" />
                  )}
                </div>
                <div className="space-y-0.5">
                  <p className="text-xs font-black text-slate-900 uppercase tracking-tight leading-none mb-1">Favicon Preview</p>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none">Simulated site icon</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
              <Palette size={20} />
            </div>
            <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Theme Colours</h3>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">Primary Colour</label>
              <div className="flex items-center space-x-2 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                <input 
                  type="color" 
                  value={config.themeColor || '#000000'} 
                  onChange={(e) => onUpdateConfig({ ...config, themeColor: e.target.value })}
                  className="w-10 h-10 rounded-lg cursor-pointer border-none bg-transparent" 
                />
                <input 
                  type="text" 
                  value={config.themeColor || '#000000'} 
                  onChange={(e) => onUpdateConfig({ ...config, themeColor: e.target.value })}
                  className="flex-1 bg-transparent font-mono text-xs uppercase focus:outline-none font-black text-slate-900" 
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">Accent Colour</label>
              <div className="flex items-center space-x-2 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                <input 
                  type="color" 
                  value={config.accentColor || '#000000'} 
                  onChange={(e) => onUpdateConfig({ ...config, accentColor: e.target.value })}
                  className="w-10 h-10 rounded-lg cursor-pointer border-none bg-transparent" 
                />
                <input 
                  type="text" 
                  value={config.accentColor || '#000000'} 
                  onChange={(e) => onUpdateConfig({ ...config, accentColor: e.target.value })}
                  className="flex-1 bg-transparent font-mono text-xs uppercase focus:outline-none font-black text-slate-900" 
                />
              </div>
            </div>
          </div>

          <div className="p-4 bg-slate-900 rounded-xl text-white space-y-4">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-400">Preview</p>
            <div className="flex items-center space-x-3">
              <div className="px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-widest" style={{ backgroundColor: config.themeColor, color: '#fff' }}>Primary Button</div>
              <div className="px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-widest border" style={{ borderColor: config.accentColor, color: config.accentColor }}>Accent Outline</div>
            </div>
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};
