import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Layout, Lock, RotateCcw, Brain, Shield, Zap, Globe, 
  Terminal, Gauge, ChevronRight, Activity,
  Cpu
} from 'lucide-react';
import { Config } from '../../types';
import Modal from '../common/Modal';
import { AdminPageWrapper } from './AdminPageWrapper';
import { LOCALIZATION } from '../../constants';

const AdminSystemConfig = ({ config, onUpdateConfig, onResetApp, isSuperAdmin, setActiveTab, aiStatus }: { 
  config: Config; 
  onUpdateConfig: (c: any) => void; 
  onResetApp: (p: string) => void; 
  isSuperAdmin: boolean;
  setActiveTab?: (t: string) => void;
  aiStatus?: any;
}) => {
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetPassword, setResetPassword] = useState('');

  const navigateTo = (tab: string) => {
    if (setActiveTab) {
      setActiveTab(tab);
    } else {
      // Fallback: emit custom event
      window.dispatchEvent(new CustomEvent('admin-tab-change', { detail: tab }));
    }
  };

  return (
    <AdminPageWrapper
      title="System Configuration"
      description="Master control for platform architecture, server health, and core security protocols."
      options={[
        {"label":"Core Systems","description":"Manage base operational parameters."},
        {"label":"Security Protocol","description":"Master access and encryption settings."},
        {"label":"Health Monitor","description":"Infrastructure and runtime diagnostics."}
      ]}
    >
      {/* System Health Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
        {[
          { label: 'Environment', value: 'Production', icon: Globe, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'Server Status', value: 'Nominal', icon: Shield, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Store Status', value: config.isLive ? 'Online' : 'Offline', icon: Activity, color: config.isLive ? 'text-emerald-600' : 'text-rose-600', bg: config.isLive ? 'bg-emerald-50' : 'bg-rose-50' },
        ].map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4`}
          >
            <div className={`p-4 ${stat.bg} ${stat.color} rounded-2xl border border-black/5`}>
              <stat.icon size={20} />
            </div>
            <div className="flex-1">
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{stat.label}</p>
              <p className={`text-sm font-black tracking-tight ${stat.color}`}>{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
        {/* Main Controls - Left Column */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Operating Controls */}
          <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 pb-4 sm:p-8 sm:pb-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-slate-900 text-white rounded-xl shadow-lg shadow-slate-900/10">
                  <Cpu size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter leading-none">Operating Controls</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Core backend behaviors</p>
                </div>
              </div>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200 opacity-50 cursor-not-allowed">
                    <div className="space-y-0.5">
                      <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Main Currency</p>
                      <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Global display currency</p>
                    </div>
                    <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-black tracking-widest uppercase">Default ({LOCALIZATION.CURRENCY})</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <div className="space-y-0.5">
                      <p className="font-black text-slate-950 text-xs uppercase tracking-tight">System Notifications</p>
                      <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Enable critical system alerts</p>
                    </div>
                    <button 
                      onClick={() => onUpdateConfig({ ...config, adminAlerts: !config.adminAlerts })}
                      className={`w-10 h-5 rounded-full transition-all relative ${config.adminAlerts ? 'bg-slate-900 shadow-md' : 'bg-slate-200'}`}
                    >
                      <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm transition-all ${config.adminAlerts ? 'left-6' : 'left-1'}`} />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <div className="space-y-0.5">
                      <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Store Visibility</p>
                      <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">{config.isLive ? 'Public Access Enabled' : 'Maintenance Mode Active'}</p>
                    </div>
                    <button 
                      onClick={() => onUpdateConfig({ ...config, isLive: !config.isLive })}
                      className={`w-10 h-5 rounded-full transition-all relative ${config.isLive ? 'bg-emerald-500 shadow-md' : 'bg-rose-500'}`}
                    >
                      <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm transition-all ${config.isLive ? 'left-6' : 'left-1'}`} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-slate-900 text-white rounded-xl">
                        <Brain size={14} />
                      </div>
                      <div className="space-y-0.5">
                        <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Intelligence Orchestration</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Global AI Subsystems</p>
                          <div className={`w-1 h-1 rounded-full ${aiStatus?.isAvailable ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                          <span className={`text-xs font-medium uppercase tracking-wider ${aiStatus?.isAvailable ? 'text-emerald-600' : 'text-slate-400'}`}>
                            {config.aiSettings?.enabled ? (aiStatus?.isAvailable ? 'Operational' : 'Attention Required') : 'Disabled'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => navigateTo('ai-settings')}
                      className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl hover:border-slate-900 transition-all group shadow-sm hover:shadow-md"
                    >
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-600 group-hover:text-slate-950">Enter Hub</span>
                      <ChevronRight size={12} className="text-slate-400 group-hover:text-slate-950 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              </div>
            </section>

          {/* Infrastructure Health & Logs */}
          <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 pb-4 sm:p-8 sm:pb-4 border-b border-slate-100">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100">
                  <Activity size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter leading-none">System Diagnostics</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Real-time infrastructure performance</p>
                </div>
              </div>
            </div>
            
            <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Platform Details</h4>
                <div className="space-y-3">
                  {[
                    { label: 'Platform Version', value: 'v4.2.0-stable' },
                    { label: 'Node Runtime', value: 'Node.js 20.11.0' },
                    { label: 'Database Status', value: 'Connected (PostgreSQL 15)', color: 'text-emerald-500' },
                    { label: 'Cache Layer', value: 'Redis 7.2 (Warm)' }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-500">{item.label}</span>
                      <span className={`font-black ${item.color || 'text-slate-900'}`}>{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">System Load</h4>
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-500 font-medium">
                  Real-time CPU, memory, and disk metrics require a server-side health endpoint
                  (e.g. <code className="font-mono text-slate-700">GET /api/v1/health/system</code>). 
                  Connect it to display live infrastructure data here.
                </div>
              </div>
            </div>
            <div className="px-8 pb-8">
              <button 
                onClick={() => navigateTo('audit')}
                className="w-full py-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-900 uppercase tracking-wider hover:bg-slate-100 transition-all flex items-center justify-center gap-2"
              >
                <Terminal size={14} />
                View Full Audit Logs
              </button>
            </div>
          </section>

        </div>

        {/* Sidebar Controls - Right Column */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* Navigation Portal */}
          <section className="bg-slate-900 rounded-2xl p-5 sm:p-8 text-white space-y-6 shadow-xl shadow-slate-900/20">
            <div className="space-y-1">
              <h3 className="text-lg font-black tracking-tighter uppercase italic leading-none">Navigation Portal</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Direct access to related modules</p>
            </div>
            
            <div className="space-y-3">
              {[
                { id: 'layout', label: 'Navigation & Layout', icon: Layout, desc: 'Menu & footer architecture' },
                { id: 'taxonomy', label: 'Taxonomy System', icon: Terminal, desc: 'Categories & structural tagging' },
                { id: 'branding', label: 'Identity & Brand', icon: Zap, desc: 'Logos, colours & visual soul' },
                { id: 'operations', label: 'Health Panel', icon: Gauge, desc: 'Real-time infrastructure pulse' }
              ].map((link) => (
                <button
                  key={link.id}
                  onClick={() => navigateTo(link.id)}
                  className="w-full flex items-center p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all text-left group"
                >
                  <div className="p-2 bg-white/10 rounded-xl group-hover:scale-110 transition-transform">
                    <link.icon size={16} className="text-white" />
                  </div>
                  <div className="ml-4 flex-1">
                    <p className="text-xs font-medium uppercase tracking-wider">{link.label}</p>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">{link.desc}</p>
                  </div>
                  <ChevronRight size={14} className="text-slate-500 group-hover:translate-x-1 transition-transform" />
                </button>
              ))}
            </div>
          </section>

          {/* Access Perimeter */}
          <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-8 space-y-8 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
                <Lock size={20} />
              </div>
              <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Access Perimeter</h3>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Admin Access Code</label>
                <div className="relative group">
                  <Terminal className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                  <input 
                    type="password"
                    value={config.adminAccessCode || ''} 
                    onChange={(e) => onUpdateConfig({ ...config, adminAccessCode: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 font-black text-xs tracking-[0.3em]" 
                  />
                </div>
              </div>

              {isSuperAdmin && (
                <div className="pt-6 border-t border-slate-100 space-y-4">
                  <div className="space-y-1">
                    <h4 className="text-xs font-medium text-rose-500 uppercase tracking-wider">Hard Reset</h4>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                      Factory reset architectural state. Irreversible.
                    </p>
                  </div>
                  <button 
                    onClick={() => setIsResetModalOpen(true)}
                    className="w-full flex items-center justify-center space-x-2 py-3 bg-rose-50 text-rose-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-rose-100 transition-all border border-rose-100 shadow-sm"
                  >
                    <RotateCcw size={14} />
                    <span>Initiate Factory Reset</span>
                  </button>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>

      <Modal isOpen={isResetModalOpen} onClose={() => setIsResetModalOpen(false)} title="System Factory Reset">
        <div className="space-y-6 p-2">
          <div className="p-5 bg-rose-50 rounded-2xl border border-rose-100 flex gap-4">
            <div className="p-3 bg-rose-100 text-rose-600 rounded-2xl h-fit">
              <Shield size={24} />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-black text-rose-950 uppercase tracking-tight">Critical System Hazard</p>
              <p className="text-xs text-rose-700 leading-relaxed font-bold uppercase tracking-wider">
                This operation will purge ALL records: Inventory, Orders, Analytics, and Media. This bypasses all safety rails.
              </p>
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Master Password</label>
            <input 
              type="password"
              value={resetPassword}
              onChange={e => setResetPassword(e.target.value)}
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-rose-500/10 font-bold text-sm tracking-widest text-center" 
              placeholder="••••••••••••"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => setIsResetModalOpen(false)}
              className="py-4 bg-slate-100 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Abort Action
            </button>
            <button 
              onClick={() => onResetApp(resetPassword)}
              disabled={!resetPassword}
              className="py-4 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-xl shadow-rose-600/20 disabled:opacity-50"
            >
              Confirm Purge
            </button>
          </div>
        </div>
      </Modal>
    </AdminPageWrapper>
  );
};

export default AdminSystemConfig;
