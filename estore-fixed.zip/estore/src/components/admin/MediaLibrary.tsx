import React, { useState, useEffect } from 'react';
import { 
  ChevronRight, FolderPlus, Upload, ShieldAlert, ImageIcon, Folder, 
  Copy, Trash2, Check 
} from 'lucide-react';
import Modal from '../common/Modal';
import { AdminSectionHeader } from './AdminSectionHeader';

interface MediaLibraryProps {
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  token: string | null;
  onSelect?: (url: string) => void;
  initialPath?: string;
}

export const MediaLibrary = ({ onShowNotification, token, onSelect, initialPath }: MediaLibraryProps) => {
  const [media, setMedia] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPath, setCurrentPath] = useState<string>(initialPath || '');
  const [isNewFolderModalOpen, setIsNewFolderModalOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  // Update path if initialPath changes (mount)
  useEffect(() => {
    if (initialPath) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCurrentPath(initialPath);
    }
  }, [initialPath]);

  const fetchMedia = React.useCallback(async (path: string = currentPath) => {
    try {
      const res = await fetch(`/api/v1/media?path=${encodeURIComponent(path)}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const contentType = res.headers.get("content-type");
      if (!res.ok) {
        if (contentType && contentType.includes("application/json")) {
          const errorData = await res.json();
          setError(errorData.error || `Server error: ${res.status}`);
        } else {
          setError(`Server error: ${res.status}. Please check if the server is running correctly.`);
        }
        setMedia([]);
        return;
      }

      if (!contentType || !contentType.includes("application/json")) {
        setError("Expected JSON response from server, but received something else. This might be due to a server configuration issue.");
        setMedia([]);
        return;
      }

      const data = await res.json();
      if (Array.isArray(data)) {
        setMedia(data);
        setError(null);
      } else if (data.error) {
        setError(data.error);
        setMedia([]);
      } else {
        setMedia([]);
      }
    } catch (err) {
      console.error('Failed to fetch media:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch media assets');
      setMedia([]);
    }
  }, [currentPath, token]);

  useEffect(() => {
    if (token) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      fetchMedia();
    }
  }, [token, fetchMedia]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    const formData = new FormData();
    formData.append('image', file);
    formData.append('path', currentPath);

    try {
      const res = await fetch('/api/v1/media/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });
      if (!res.ok) throw new Error('Upload failed');
      await fetchMedia(currentPath);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (item: any) => {
    if (!window.confirm(`Are you sure you want to delete this ${item.isDirectory ? 'folder' : 'image'}?`)) return;
    try {
      await fetch(`/api/v1/media/${item.name}?path=${encodeURIComponent(currentPath)}`, { 
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      await fetchMedia(currentPath);
    } catch (err) {
      console.error('Failed to delete media:', err);
    }
  };

  const createFolder = async () => {
    if (!newFolderName) return;
    try {
      const res = await fetch('/api/v1/media/folders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name: newFolderName, path: currentPath })
      });
      if (!res.ok) throw new Error('Failed to create folder');
      setNewFolderName('');
      setIsNewFolderModalOpen(false);
      await fetchMedia(currentPath);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const breadcrumbs = currentPath.split('/').filter(Boolean);

  return (
    <div className="space-y-6 pb-10">
      <AdminSectionHeader 
        title="Media Library" 
        description="Manage your product images, banners, and other media assets." 
        options={[{"label":"Quick Upload","description":"Drag and drop images directly into the current folder."},{"label":"Asset Sync","description":"All images are automatically compressed for high performance."}]} 
      />
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-medium uppercase tracking-wider text-slate-400 mt-1.5 ml-1">
            <button 
              onClick={() => setCurrentPath('')}
              className={`hover:text-slate-900 transition-colors ${currentPath === '' ? 'text-primary' : ''}`}
            >
              Root
            </button>
            {breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={idx}>
                <ChevronRight size={10} className="text-slate-300" />
                <button 
                  onClick={() => setCurrentPath(breadcrumbs.slice(0, idx + 1).join('/'))}
                  className={`hover:text-slate-900 transition-colors ${idx === breadcrumbs.length - 1 ? 'text-primary' : ''}`}
                >
                  {crumb}
                </button>
              </React.Fragment>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-2 ml-auto">
          <button 
            onClick={() => setIsNewFolderModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 text-slate-900 font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-slate-50 transition-all shadow-sm"
          >
            <FolderPlus size={14} />
            <span>New Folder</span>
          </button>
          <label className="cursor-pointer flex items-center space-x-2 px-5 py-2 bg-slate-900 text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-black transition-all shadow-lg shadow-slate-900/10">
            <Upload size={14} />
            <span>{uploading ? 'Uploading...' : 'Upload Image'}</span>
            <input type="file" className="hidden" accept="image/*" onChange={handleUpload} disabled={uploading} />
          </label>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 text-red-600 rounded-xl text-xs font-medium uppercase tracking-wider border border-red-100 flex items-center gap-2">
          <ShieldAlert size={14} />
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {/* Back Button for Subfolders */}
        {currentPath && (
          <div className="bg-slate-50 rounded-xl border border-slate-200 shadow-sm overflow-hidden group hover:bg-slate-100 transition-all cursor-pointer">
            <div 
              onClick={() => {
                const parts = currentPath.split('/');
                parts.pop();
                setCurrentPath(parts.join('/'));
              }}
              className="aspect-square flex flex-col items-center justify-center"
            >
              <div className="w-10 h-10 bg-white shadow-sm text-slate-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Folder size={20} className="rotate-180" />
              </div>
              <p className="mt-2 text-xs font-medium text-slate-400 uppercase tracking-wider">Go Back</p>
            </div>
          </div>
        )}

        {!Array.isArray(media) || media.length === 0 ? (
          !currentPath && (
            <div className="col-span-full bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto border border-slate-100">
                <ImageIcon size={24} className="text-slate-300" />
              </div>
              <div>
                <p className="text-slate-900 text-sm font-bold">No items found</p>
                <p className="text-slate-400 text-xs font-medium uppercase tracking-wider mt-1">This folder is currently empty.</p>
              </div>
            </div>
          )
        ) : (
          media
            .sort((a, b) => {
              if (a.isDirectory && !b.isDirectory) return -1;
              if (!a.isDirectory && b.isDirectory) return 1;
              return a.name.localeCompare(b.name);
            })
            .map((item) => {
              // Internal preview URL (absolute)
              const previewUrl = item.isDirectory ? null : `${window.location.origin}${item.url}`;
              // Database-safe relative URL
              const relativeUrl = item.url;
              
              return (
                <div key={item.name} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden group hover:shadow-lg hover:shadow-slate-900/5 transition-all">
                  <div className="aspect-square relative overflow-hidden bg-slate-50">
                    {item.isDirectory ? (
                      <div 
                        onClick={() => setCurrentPath(currentPath ? `${currentPath}/${item.name}` : item.name)}
                        className="w-full h-full flex flex-col items-center justify-center cursor-pointer hover:bg-slate-100 transition-colors"
                      >
                        <div className="w-10 h-10 bg-slate-100 text-slate-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                          <Folder size={20} fill="currentColor" fillOpacity={0.2} />
                        </div>
                      </div>
                    ) : (
                      <img 
                        src={previewUrl!} 
                        alt={item.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                    )}
                    
                    <div className="absolute top-2 right-2 flex space-x-1.5 opacity-0 group-hover:opacity-100 transition-all translate-y-1 group-hover:translate-y-0">
                      {onSelect && (
                        <button 
                          onClick={() => onSelect(relativeUrl!)}
                          className="p-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors shadow-lg"
                          title={item.isDirectory ? "Select Folder" : "Select Image"}
                        >
                          <Check size={12} />
                        </button>
                      )}
                      {!item.isDirectory && (
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(previewUrl!);
                            onShowNotification('URL copied to clipboard!', 'success');
                          }}
                          className="p-2 bg-white text-slate-900 rounded-lg hover:bg-slate-50 transition-colors shadow-lg"
                          title="Copy URL"
                        >
                          <Copy size={12} />
                        </button>
                      )}
                      <button 
                        onClick={() => handleDelete(item)}
                        className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors shadow-lg"
                        title="Delete"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="text-xs font-black text-slate-900 truncate tracking-tight uppercase">{item.name}</p>
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mt-0.5">
                      {item.isDirectory ? 'Folder' : `${(item.size / 1024).toFixed(1)} KB`}
                    </p>
                  </div>
                </div>
              );
            })
        )}
      </div>

      <Modal 
        isOpen={isNewFolderModalOpen} 
        onClose={() => setIsNewFolderModalOpen(false)} 
        title="Create New Folder"
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-wider ml-1 text-slate-400">Folder Name</label>
            <input 
              type="text"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-slate-900/5 outline-none transition-all"
              placeholder="Enter folder name..."
              autoFocus
            />
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={() => setIsNewFolderModalOpen(false)}
              className="flex-1 py-2.5 bg-slate-100 text-slate-600 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button 
              onClick={createFolder}
              disabled={!newFolderName.trim()}
              className="flex-1 py-2.5 bg-slate-900 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-black transition-all shadow-lg shadow-slate-900/10 disabled:opacity-50"
            >
              Create Folder
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default MediaLibrary;
