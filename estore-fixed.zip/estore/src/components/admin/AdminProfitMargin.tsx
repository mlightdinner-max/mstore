import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  DollarSign, ShoppingBag, 
  Zap, Target, Brain, Download, TrendingUp
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Product, Order } from '../../types';
import { LOCALIZATION } from '../../constants';
import { AdminPageWrapper } from './AdminPageWrapper';
import { StatsCard } from './StatsCard';

interface AdminProfitMarginProps {
  orders: Order[];
  products: Product[];
  config: any;
}

const AdminProfitMargin = ({ orders }: AdminProfitMarginProps) => {
  const [timeRange, setTimeRange] = useState('30d');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const filteredOrders = useMemo(() => {
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    return orders.filter(o =>
      new Date(o.createdAt) >= cutoff &&
      (o.status === 'CLOSED') &&
      (categoryFilter === 'All' || o.items.some(item => item.category === categoryFilter))
    );
  }, [orders, timeRange, categoryFilter]);

  const stats = useMemo(() => {
    let totalRevenue = 0;
    let totalCost = 0;
    let totalCommission = 0;
    let totalDiscount = 0;
    let totalNetMargin = 0;

    filteredOrders.forEach(order => {
      totalRevenue += order.total;
      totalCommission += order.commissionAmount || 0;
      totalDiscount += order.discount || 0;
      totalNetMargin += order.netMargin || (order.total - order.items.reduce((sum, item) => sum + ((item.originalCostAtPurchase || 0) * item.quantity), 0) - (order.commissionAmount || 0));
      
      order.items.forEach(item => {
        totalCost += (item.originalCostAtPurchase || 0) * item.quantity;
      });
    });

    const grossProfit = totalNetMargin;
    const margin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

    return {
      totalRevenue,
      totalCost,
      totalCommission,
      totalDiscount,
      grossProfit,
      margin
    };
  }, [filteredOrders]);

  const handleExportCSV = () => {
    const headers = ['Order ID', 'Date', 'Customer', 'Sold Price', 'Discounted Price', 'Affiliate Payout', 'Net Margin', 'Status', 'Items'];
    const rows = filteredOrders.map(o => [
      o.id,
      new Date(o.createdAt).toLocaleDateString(),
      o.customerName,
      `${LOCALIZATION.CURRENCY}${(o.soldPrice || o.items.reduce((sum, i) => sum + (i.price * i.quantity), 0)).toLocaleString()}`,
      `${LOCALIZATION.CURRENCY}${(o.discountedPrice || o.total).toLocaleString()}`,
      `${LOCALIZATION.CURRENCY}${(o.affiliatePayout || o.commissionAmount || 0).toLocaleString()}`,
      `${LOCALIZATION.CURRENCY}${(o.netMargin || (o.total - o.items.reduce((sum, i) => sum + ((i.originalCostAtPurchase || 0) * i.quantity), 0) - (o.commissionAmount || 0))).toLocaleString()}`,
      o.status,
      o.items.map(i => `${i.name} (x${i.quantity})`).join('; ')
    ]);

    const csvContent = [headers, ...rows].map(e => e.map(cell => `"${cell}"`).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `profit_report_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const chartData = useMemo(() => {
    const data: { [key: string]: any } = {};
    filteredOrders.forEach(order => {
      const date = new Date(order.createdAt).toLocaleDateString();
      if (!data[date]) {
        data[date] = { date, revenue: 0, cost: 0, profit: 0 };
      }
      data[date].revenue += order.total;
      let orderCost = 0;
      order.items.forEach(item => {
        orderCost += (item.originalCostAtPurchase || 0) * item.quantity;
      });
      data[date].cost += orderCost;
      data[date].profit += order.netMargin || (order.total - orderCost - (order.commissionAmount || 0));
    });
    return Object.values(data).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredOrders]);

  return (
    <AdminPageWrapper
      title="Profit Margins"
      description="Analyse your profitability by tracking costs, revenue, and affiliate commissions."
      icon={TrendingUp}
      options={[{"label":"Net Margin Tracking","description":"View actual profit after discounts and affiliate payouts."},{"label":"Filter by Date","description":"Analyse profitability over specific timeframes."}]}
    >
      <div className="flex justify-end mb-6">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <select 
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-6 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
          >
            <option value="All">All Categories</option>
            {Array.from(new Set(orders.flatMap(o => o.items.map(i => i.category)))).map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleExportCSV}
              className="flex items-center space-x-2 px-4 py-3 bg-white text-slate-900 rounded-2xl border border-slate-200 font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm"
            >
              <Download size={14} />
              <span>Export CSV</span>
            </button>
            <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 overflow-x-auto no-scrollbar">
              {['7d', '30d', '90d', 'all'].map(range => (
                <button 
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all ${timeRange === range ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  {range}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Gross Revenue" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalRevenue.toLocaleString()}`} 
          icon={DollarSign} 
          color="blue"
          delay={0.1}
        />
        <StatsCard 
          label="Total Cost" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalCost.toLocaleString()}`} 
          icon={ShoppingBag} 
          color="slate"
          delay={0.2}
        />
        <StatsCard 
          label="Net Profit" 
          value={`${LOCALIZATION.CURRENCY}${stats.grossProfit.toLocaleString()}`} 
          icon={Zap} 
          color="emerald"
          trend={{ value: `${stats.margin.toFixed(1)}%`, isPositive: stats.margin > 15 }}
          delay={0.3}
        />
        <StatsCard 
          label="Profit Margin" 
          value={`${stats.margin.toFixed(1)}%`} 
          icon={Target} 
          color="purple"
          delay={0.4}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-10">
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-6">Profit Trend</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#94a3b8' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#94a3b8' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ fontSize: '11px', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorProfit)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-6">Cost Breakdown</h3>
          <div className="space-y-4">
            {[
              { label: 'Product Cost', value: stats.totalCost, color: 'bg-slate-900' },
              { label: 'Affiliate Payouts', value: stats.totalCommission, color: 'bg-blue-500' },
              { label: 'Discounts Given', value: stats.totalDiscount, color: 'bg-rose-500' },
              { label: 'Net Profit', value: stats.grossProfit, color: 'bg-primary/80' }
            ].map((item, idx) => {
              const total = stats.totalRevenue || 1;
              const percentage = (item.value / total) * 100;
              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-medium uppercase tracking-wider">
                    <span className="text-slate-500">{item.label}</span>
                    <span className="text-slate-900">{LOCALIZATION.CURRENCY}{item.value.toLocaleString()}</span>
                  </div>
                  <div className="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${percentage}%` }}
                      className={`h-full ${item.color} rounded-full`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 p-4 bg-slate-900 rounded-2xl text-white">
            <div className="flex items-center space-x-2 mb-2">
              <Brain size={14} className="text-primary/60" />
              <p className="text-xs font-medium uppercase tracking-wider">AI Profit Insight</p>
            </div>
            <p className="text-xs font-medium text-slate-300 leading-relaxed">
              Your net margin is <span className="text-primary/60 font-bold">{stats.margin.toFixed(1)}%</span>. Reducing affiliate commission by 1% could increase monthly profit by {LOCALIZATION.CURRENCY}{(stats.totalRevenue * 0.01).toLocaleString()}.
            </p>
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AdminProfitMargin;
