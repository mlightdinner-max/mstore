import React, { useState } from 'react';
import { Image as ImageIcon, X } from 'lucide-react';
import Modal from '../common/Modal';
import { MediaLibrary } from './MediaLibrary';

interface ImageInputProps {
  value: string;
  onChange: (url: string) => void;
  label: string;
  placeholder?: string;
  token: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

export const ImageInput = ({ 
  value, 
  onChange, 
  label, 
  placeholder = "Enter image URL...", 
  token,
  onShowNotification
}: ImageInputProps) => {
  const [isPickerOpen, setIsPickerOpen] = useState(false);

  return (
    <div className="space-y-2">
      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">{label}</label>
      <div className="flex items-center space-x-2">
        <div className="relative flex-1 group">
          <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={16} />
          <input 
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
          />
          {value && (
            <button 
              onClick={() => onChange('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-500 transition-colors"
            >
              <X size={14} />
            </button>
          )}
        </div>
        <button
          type="button"
          onClick={() => setIsPickerOpen(true)}
          className="px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all border border-slate-200 shadow-sm"
        >
          Browse
        </button>
      </div>

      <Modal
        isOpen={isPickerOpen}
        onClose={() => setIsPickerOpen(false)}
        title="Select Image from Library"
        maxWidth="max-w-6xl"
      >
        <div className="max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
          <MediaLibrary 
            onShowNotification={onShowNotification} 
            token={token} 
            onSelect={(url) => {
              onChange(url);
              setIsPickerOpen(false);
            }}
          />
        </div>
      </Modal>
    </div>
  );
};
