import React from 'react';
import { Home, Settings, Package, ShoppingBag, Users } from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { StatsCard } from './StatsCard';

export const AdminHome = ({ user, config, products, orders, customers }: any) => {
  const isAdmin = user?.role === 'Admin' || user?.role === 'Super Admin';
  const isAffiliate = user?.role === 'Affiliate';

  return (
    <AdminPageWrapper
      title={config?.homeWelcomeMessage || "Home"}
      description={config?.homeSummaryMessage || "Welcome to your control panel!"}
      icon={Home}
    >
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-lg font-bold text-slate-900 mb-2">Welcome, {user?.email}! {isAdmin ? "Ready to set up your store?" : ""}</h2>
          <p className="text-sm text-slate-600 mb-4 tracking-whide">
            Thank you for logging in. This is your setup dashboard. Here you can configure your store, view recent activity, and manage your components.
          </p>
          {isAdmin && (
            <div className="flex gap-4">
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('admin-tab-change', { detail: 'general-settings' }))}
                className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors"
              >
                <Settings size={16} />
                <span>Go to Settings</span>
              </button>
            </div>
          )}
        </div>

        {isAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <StatsCard title="Total Products" value={products?.length || 0} icon={Package} trend={{ value: 0, isPositive: true }} />
            <StatsCard title="Total Orders" value={orders?.length || 0} icon={ShoppingBag} trend={{ value: 0, isPositive: true }} />
            <StatsCard title="Total Customers" value={customers?.length || 0} icon={Users} trend={{ value: 0, isPositive: true }} />
          </div>
        )}

        {isAffiliate && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <StatsCard title="Referred Orders" value={orders?.filter((o: any) => o.affiliateId === user?.affiliateId).length || 0} icon={ShoppingBag} trend={{ value: 0, isPositive: true }} />
          </div>
        )}
      </div>
    </AdminPageWrapper>
  );
};
export default AdminHome;
