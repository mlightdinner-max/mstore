import React from 'react';

interface TableProps {
  children: React.ReactNode;
  className?: string;
}

// The outer div handles horizontal scroll on mobile. min-w-[600px] on table ensures
// columns don't crush below a readable width on small screens.
export const Table = ({ children, className = "" }: TableProps) => (
  <div className={`w-full overflow-x-auto -mx-0 rounded-xl ${className}`}>
    <table className="w-full min-w-[600px] text-left border-collapse">
      {children}
    </table>
  </div>
);

export const TableHeader = ({ children }: { children: React.ReactNode }) => (
  <thead>
    <tr className="bg-slate-50 border-b border-slate-200">
      {children}
    </tr>
  </thead>
);

export const TableHead = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <th scope="col" className={`px-3 sm:px-4 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap ${className}`}>
    {children}
  </th>
);

export const TableBody = ({ children }: { children: React.ReactNode }) => (
  <tbody className="divide-y divide-slate-100">
    {children}
  </tbody>
);

export const TableRow = ({ children, className = "", onClick }: {
  children: React.ReactNode;
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLTableRowElement>) => void;
}) => (
  <tr
    className={`hover:bg-slate-50/50 transition-colors ${onClick ? 'cursor-pointer' : ''} ${className}`}
    onClick={onClick}
  >
    {children}
  </tr>
);

export const TableCell = ({ children, className = "", colSpan }: {
  children: React.ReactNode;
  className?: string;
  colSpan?: number;
}) => (
  <td colSpan={colSpan} className={`px-3 sm:px-4 py-3 sm:py-4 text-sm align-middle ${className}`}>
    {children}
  </td>
);
