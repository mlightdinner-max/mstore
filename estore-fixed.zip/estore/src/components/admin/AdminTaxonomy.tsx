import React, { useState, useEffect } from 'react';
import { Tag, Layers, Plus, X, ClipboardList, Edit2, Brain, RefreshCw, Trash2, Save } from 'lucide-react';
import { motion } from 'motion/react';
import { Config, Product, OrderStatusBlueprint } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';
import { ImageInput } from './ImageInput';
import { aiService } from '../../services/aiService';

interface AdminTaxonomyProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  orders: any[];
  products: Product[];
  onUpdateProducts?: (products: Product[]) => void;
  onNavigateToOrders: (status: string) => void;
  token?: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

export const AdminTaxonomy = ({ config, onUpdateConfig, orders, products, onUpdateProducts, onNavigateToOrders, token, onShowNotification }: AdminTaxonomyProps) => {
  const [newCategory, setNewCategory] = useState('');
  const [newTag, setNewTag] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editCategoryData, setEditCategoryData] = useState<{ name: string, image: string }>({ name: '', image: '' });
  const [isSuggestingCategories, setIsSuggestingCategories] = useState(false);
  const [isSuggestingTags, setIsSuggestingTags] = useState(false);
  const [taxonomySuggestions, setTaxonomySuggestions] = useState<{ type: string, items: string[] } | null>(null);
  const [aiStatus, setAiStatus] = useState<any>(null);

  useEffect(() => {
    aiService.getStatus().then(setAiStatus);
  }, []);

  const handleSuggestTaxonomy = async (type: 'categories' | 'tags') => {
    if (type === 'categories') setIsSuggestingCategories(true);
    else setIsSuggestingTags(true);

    try {
      const suggestions = await aiService.suggestTaxonomy(type, aiStatus?.isUnsavedKey ? config.geminiApiKey : undefined);
      if (suggestions && suggestions.length > 0) {
        setTaxonomySuggestions({ type, items: suggestions });
      } else {
        onShowNotification('AI could not generate suggestions at this time.', 'info');
      }
    } catch {
      onShowNotification('AI Suggestion failed.', 'error');
    } finally {
      if (type === 'categories') setIsSuggestingCategories(false);
      else setIsSuggestingTags(false);
    }
  };

  const applySuggestion = (item: string) => {
    if (!taxonomySuggestions) return;
    
    if (taxonomySuggestions.type === 'categories') {
      const exists = config.categories?.some((c: any) => (typeof c === 'string' ? c : c.name) === item);
      if (!exists) {
        onUpdateConfig({ 
          ...config, 
          categories: [...(config.categories || []), { id: crypto.randomUUID(), name: item, image: '' }] 
        });
        onShowNotification(`Added category: ${item}`, 'success');
      }
    } else {
      const exists = (config.tags || []).includes(item);
      if (!exists) {
        onUpdateConfig({ 
          ...config, 
          tags: [...(config.tags || []), item] 
        });
        onShowNotification(`Added tag: ${item}`, 'success');
      }
    }
    
    // Remove from suggestions
    setTaxonomySuggestions(prev => prev ? { ...prev, items: prev.items.filter(i => i !== item) } : null);
  };

  const [newStatus, setNewStatus] = useState<OrderStatusBlueprint>({
    id: '',
    label: '',
    color: '#0f172a',
    isTerminal: false,
    triggersEmail: false,
    triggersWhatsApp: false,
    triggersPayout: false,
    requiresNote: false
  });
  const [editingStatusId, setEditingStatusId] = useState<string | null>(null);

  const getOrderStatusCount = (statusLabel: string) => {
    return orders.filter(o => o.status === statusLabel).length;
  };

  const resetNewStatus = () => {
    setNewStatus({
      id: '',
      label: '',
      color: '#0f172a',
      isTerminal: false,
      triggersEmail: false,
      triggersWhatsApp: false,
      triggersPayout: false,
      requiresNote: false
    });
  };

  const handleAddStatus = () => {
    if (newStatus.label) {
      const id = newStatus.label.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const exists = (config.orderStatuses || []).some(s => s.id === id);
      if (exists) {
        onShowNotification('A status with this name/ID already exists.', 'error');
        return;
      }

      const blueprint: OrderStatusBlueprint = {
        ...newStatus,
        id
      };

      onUpdateConfig({ 
        ...config, 
        orderStatuses: [...(config.orderStatuses || []), blueprint] 
      });
      resetNewStatus();
      onShowNotification(`Order status "${blueprint.label}" added`, 'success');
    }
  };

  const SYSTEM_STATUSES = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled', 'Returned', 'Completed'];
  const isSystemStatus = (label: string) => SYSTEM_STATUSES.includes(label);

  const handleEditStatus = (status: OrderStatusBlueprint) => {
    setEditingStatusId(status.id);
    setNewStatus({
      ...status,
      requiresNote: !!status.requiresNote // Ensure defined
    });
  };

  const handleSaveStatusEdit = () => {
    if (editingStatusId && newStatus.label) {
      if (isSystemStatus(newStatus.label) && newStatus.label !== (config.orderStatuses || []).find(s => s.id === editingStatusId)?.label) {
        onShowNotification('Cannot rename a protected system status label.', 'error');
        return;
      }
      const updatedStatuses = (config.orderStatuses || []).map(s => 
        s.id === editingStatusId ? { ...s, ...newStatus } : s
      );
      onUpdateConfig({ ...config, orderStatuses: updatedStatuses });
      setEditingStatusId(null);
      resetNewStatus();
      onShowNotification('Status blueprint updated', 'success');
    }
  };

  const handleDeleteStatus = (id: string, label: string) => {
    if (isSystemStatus(label)) {
      onShowNotification('Cannot delete core system status. This status is required for business logic (Revenue, Payouts, AI).', 'error');
      return;
    }
    const count = getOrderStatusCount(label);
    if (count > 0) {
      onShowNotification(`Cannot delete status "${label}". ${count} orders are currently using it.`, 'error');
      return;
    }

    const confirmed = window.confirm(`Delete the "${label}" status? This cannot be undone.`); if (confirmed) {
      onUpdateConfig({
        ...config,
        orderStatuses: (config.orderStatuses || []).filter(s => s.id !== id)
      });
      onShowNotification('Status removed', 'success');
    }
  };

  const handleEditCategory = (cat: any) => {
    const catName = typeof cat === 'string' ? cat : cat.name;
    const catImage = typeof cat === 'string' ? '' : (cat.image || '');
    const catId = typeof cat === 'string' ? catName : (cat.id || catName);
    setEditingCategoryId(catId);
    setEditCategoryData({ name: catName, image: catImage });
  };

  const handleSaveCategoryEdit = (id: string) => {
    const oldCategory = config.categories?.find((c: any) => {
      const cId = typeof c === 'string' ? c : (c.id || c.name);
      return cId === id;
    });
    const oldName = oldCategory ? (typeof oldCategory === 'string' ? oldCategory : oldCategory.name) : null;

    const updatedCategories = config.categories?.map((c: any) => {
      const cId = typeof c === 'string' ? c : (c.id || c.name);
      if (cId === id) {
        return { ...c, name: editCategoryData.name, image: editCategoryData.image };
      }
      return c;
    });
    onUpdateConfig({ ...config, categories: updatedCategories });

    // Cascade rename to all products that still carry the old category name
    if (oldName && oldName !== editCategoryData.name && onUpdateProducts) {
      const updatedProducts = products.map(p =>
        p.category === oldName ? { ...p, category: editCategoryData.name } : p
      );
      onUpdateProducts(updatedProducts);
    }

    setEditingCategoryId(null);
    onShowNotification('Category updated successfully', 'success');
  };

  const createCategoryFolder = async (name: string) => {
    if (!name || !token) return;
    const folderName = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    try {
      await fetch('/api/v1/media/folders', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ path: 'categories', name: folderName })
      });
    } catch (error) {
      console.error('Failed to create category folder:', error);
    }
  };

  const handleDeleteCategory = (name: string) => {
    // Check for dependencies (products using this category)
    const productsUsingCategory = products.filter(p => p.category === name);
    
    if (productsUsingCategory.length > 0) {
      onShowNotification(
        `Cannot delete "${name}". It is currently assigned to ${productsUsingCategory.length} products. Reassign these products first.`, 
        'error'
      );
      return;
    }

    const confirmed = window.confirm(`Delete the "${name}" category? This cannot be undone.`); if (confirmed) {
      const newCategories = (config.categories || []).filter((c: any) => (typeof c === 'string' ? c : c.name) !== name);
      onUpdateConfig({ ...config, categories: newCategories });
      onShowNotification('Category removed successfully', 'success');
    }
  };

  const handleDeleteTag = (tag: string) => {
    // Check for dependencies (products using this tag)
    const productsUsingTag = products.filter(p => p.tags && p.tags.includes(tag));

    if (productsUsingTag.length > 0) {
      onShowNotification(
        `Cannot delete "${tag}". It is linked to ${productsUsingTag.length} products. Remove the tag from these products first.`, 
        'error'
      );
      return;
    }

    const confirmed = window.confirm(`Delete the "${tag}" tag? This cannot be undone.`); if (confirmed) {
      const newTags = (config.tags || []).filter((t: string) => t !== tag);
      onUpdateConfig({ ...config, tags: newTags });
      onShowNotification('Tag removed successfully', 'success');
    }
  };

  const handleAddCategory = async () => {
    if (newCategory) {
      const exists = config.categories?.some((c: any) => (typeof c === 'string' ? c : c.name).toLowerCase() === newCategory.toLowerCase());
      if (exists) {
        onShowNotification('A category with this name already exists.', 'error');
        return;
      }
      onUpdateConfig({ 
        ...config, 
        categories: [...(config.categories || []), { id: crypto.randomUUID(), name: newCategory, image: '' }] 
      });
      await createCategoryFolder(newCategory);
      setNewCategory('');
      onShowNotification(`Added category: ${newCategory}. You can now add an image below.`, 'success');
    }
  };

  return (
    <AdminPageWrapper
      title="Categories & Tags"
      description="Organise your products with categories and tags for better navigation."
      icon={Layers}
      options={[{"label":"Add Category","description":"Create new product categories with name first."},{"label":"Edit Tags","description":"Manage the tags used for filtering products."}]}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        {/* Categories */}
        <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6 h-fit">
          <div className="flex items-center justify-between group">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <Layers size={20} />
              </div>
              <h3 className="text-lg font-semibold text-slate-900">Product Categories</h3>
            </div>
            {aiStatus?.isAvailable && (
              <button
                onClick={() => handleSuggestTaxonomy('categories')}
                disabled={isSuggestingCategories}
                className="p-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors flex items-center justify-center font-medium"
                title="AI Suggest Categories"
              >
                {isSuggestingCategories ? <RefreshCw size={16} className="animate-spin" /> : <Brain size={16} />}
              </button>
            )}
          </div>

          {taxonomySuggestions?.type === 'categories' && taxonomySuggestions.items.length > 0 && (
            <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">AI Suggested Categories</span>
                <button onClick={() => setTaxonomySuggestions(null)} className="text-indigo-400 hover:text-indigo-600 transition-colors"><X size={14} /></button>
              </div>
              <div className="flex flex-wrap gap-2">
                {taxonomySuggestions.items.map(item => (
                  <button
                    key={item}
                    onClick={() => applySuggestion(item)}
                    className="px-3 py-1.5 bg-white border border-indigo-200 text-indigo-700 text-sm font-medium rounded-lg hover:bg-indigo-50 transition-colors shadow-sm"
                  >
                    + {item}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Category Name"
                className="flex-1 h-11 px-4 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm transition-all"
                value={newCategory}
                onChange={e => setNewCategory(e.target.value)}
              />
              <button 
                onClick={handleAddCategory}
                className="h-11 px-5 bg-slate-900 text-white rounded-xl hover:bg-slate-800 text-sm font-medium transition-all shadow-sm"
              >
                Add
              </button>
            </div>
            <p className="text-[13px] text-slate-500 px-1">
              * Add name first. Images can be added after creation.
            </p>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {config.categories?.map((cat: any, idx) => {
              const catName = typeof cat === 'string' ? cat : cat.name;
              const catImage = typeof cat === 'string' ? null : cat.image;
              const catId = typeof cat === 'string' ? `cat-${idx}-${catName}` : (cat.id || `cat-${idx}-${catName}`);
              const isEditing = editingCategoryId === catId;

              return (
                <div key={catId} className="space-y-2">
                  <div className={`group flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                    isEditing ? 'bg-slate-50 border-slate-300 shadow-sm' : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm'
                  }`}>
                    <div 
                      className="flex items-center gap-3.5 flex-1 cursor-pointer"
                      onClick={() => {
                        if (isEditing) setEditingCategoryId(null);
                        else handleEditCategory(cat);
                      }}
                    >
                      <div className={`w-10 h-10 rounded-lg overflow-hidden border flex items-center justify-center shrink-0 ${isEditing ? 'bg-white border-slate-200' : 'bg-slate-50 border-slate-200'}`}>
                        {catImage ? (
                          <img src={catImage} alt={catName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <Layers size={18} className="text-slate-400" />
                        )}
                      </div>
                      <div className="space-y-0.5 min-w-0">
                        <p className="text-sm font-semibold text-slate-900 truncate">{catName}</p>
                        <p className="text-xs text-slate-500">
                          {products.filter(p => p.category === catName).length} Products
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                      <button 
                        onClick={(e) => { 
                          e.stopPropagation(); 
                          if (isEditing) setEditingCategoryId(null); 
                          else handleEditCategory(cat); 
                        }}
                        className={`p-2 rounded-lg transition-colors ${isEditing ? 'bg-slate-200 text-slate-900' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'}`}
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDeleteCategory(catName); }}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  {isEditing && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-5 bg-slate-50 rounded-xl space-y-4 border border-slate-200"
                    >
                      <div className="space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-sm font-medium text-slate-700">Category Name</label>
                          <input 
                            type="text" 
                            className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                            value={editCategoryData.name}
                            onChange={e => setEditCategoryData({ ...editCategoryData, name: e.target.value })}
                          />
                        </div>
                        <div className="space-y-1.5">
                          <ImageInput 
                            label="Category Image"
                            value={editCategoryData.image}
                            onChange={(url) => setEditCategoryData({ ...editCategoryData, image: url })}
                            token={token}
                            onShowNotification={onShowNotification}
                          />
                        </div>
                        <div className="flex gap-2 pt-2">
                          <button 
                            onClick={() => handleSaveCategoryEdit(catId)}
                            className="flex-1 h-10 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm"
                          >
                            Save Updates
                          </button>
                          <button 
                            onClick={() => setEditingCategoryId(null)}
                            className="px-5 h-10 bg-white border border-slate-200 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Global Tags */}
        <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6 h-fit">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                <Tag size={20} />
              </div>
              <h3 className="text-lg font-semibold text-slate-900">Product Tags</h3>
            </div>
            {aiStatus?.isAvailable && (
              <button
                onClick={() => handleSuggestTaxonomy('tags')}
                disabled={isSuggestingTags}
                className="p-2 bg-purple-50 text-purple-600 rounded-lg hover:bg-purple-100 transition-colors flex items-center justify-center font-medium"
                title="AI Suggest Tags"
              >
                {isSuggestingTags ? <RefreshCw size={16} className="animate-spin" /> : <Brain size={16} />}
              </button>
            )}
          </div>

          {taxonomySuggestions?.type === 'tags' && taxonomySuggestions.items.length > 0 && (
            <div className="p-4 bg-purple-50/50 border border-purple-100 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-purple-600 uppercase tracking-wider">AI Suggested Tags</span>
                <button onClick={() => setTaxonomySuggestions(null)} className="text-purple-400 hover:text-purple-600 transition-colors"><X size={14} /></button>
              </div>
              <div className="flex flex-wrap gap-2">
                {taxonomySuggestions.items.map(item => (
                  <button
                    key={item}
                    onClick={() => applySuggestion(item)}
                    className="px-3 py-1.5 bg-white border border-purple-200 text-purple-700 text-sm font-medium rounded-lg hover:bg-purple-50 transition-colors shadow-sm"
                  >
                    + {item}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Add a new tag"
                className="flex-1 h-11 px-4 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 text-sm transition-all"
                value={newTag}
                onChange={e => setNewTag(e.target.value)}
              />
              <button 
                onClick={() => {
                  if (newTag) {
                    onUpdateConfig({ ...config, tags: [...(config.tags || []), newTag] });
                    setNewTag('');
                    onShowNotification('Tag added', 'success');
                  }
                }}
                className="h-11 px-5 bg-slate-900 text-white rounded-xl hover:bg-slate-800 text-sm font-medium transition-all shadow-sm"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {(config.tags || []).map((tag: string, idx: number) => {
                const count = products.filter(p => p.tags && p.tags.includes(tag)).length;
                return (
                  <div key={`${tag}-${idx}`} className="group inline-flex items-center bg-slate-50 hover:bg-slate-100 pl-3 pr-1 py-1 rounded-full border border-slate-200 transition-colors">
                    <span className="text-sm font-medium text-slate-700 mr-2">{tag}</span>
                    <span className="px-1.5 py-0.5 bg-white text-slate-500 rounded-full border border-slate-200 text-xs font-semibold">{count}</span>
                    <button 
                      onClick={() => handleDeleteTag(tag)}
                      className="p-1 ml-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-full transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Order Statuses */}
        <div className="lg:col-span-2 bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6 h-fit">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <ClipboardList size={20} />
            </div>
            <h3 className="text-lg font-semibold text-slate-900">Order Status Blueprints</h3>
          </div>
          
          <div className="p-5 md:p-6 bg-slate-50 rounded-xl border border-slate-200 space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-700">Status Label</label>
                <input 
                  type="text" 
                  placeholder="e.g. Out for Delivery"
                  className="w-full h-10 px-3 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-sm transition-all"
                  value={newStatus.label}
                  onChange={e => setNewStatus({ ...newStatus, label: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-700">UI Color</label>
                <div className="flex gap-2">
                  <input 
                    type="color" 
                    className="h-10 w-12 p-1.5 bg-white border border-slate-200 rounded-lg cursor-pointer"
                    value={newStatus.color}
                    onChange={e => setNewStatus({ ...newStatus, color: e.target.value })}
                  />
                  <input 
                    type="text" 
                    className="flex-1 h-10 px-3 bg-white border border-slate-200 rounded-lg text-sm font-mono text-slate-600 focus:outline-none"
                    value={newStatus.color}
                    readOnly
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-3 pt-1">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                    checked={newStatus.isTerminal}
                    onChange={e => setNewStatus({ ...newStatus, isTerminal: e.target.checked })}
                  />
                  <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">Terminal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                    checked={newStatus.triggersEmail}
                    onChange={e => setNewStatus({ ...newStatus, triggersEmail: e.target.checked })}
                  />
                  <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">Email</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                    checked={newStatus.triggersPayout}
                    onChange={e => setNewStatus({ ...newStatus, triggersPayout: e.target.checked })}
                  />
                  <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">Payout</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                    checked={newStatus.triggersWhatsApp}
                    onChange={e => setNewStatus({ ...newStatus, triggersWhatsApp: e.target.checked })}
                  />
                  <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">WhatsApp</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                    checked={newStatus.requiresNote}
                    onChange={e => setNewStatus({ ...newStatus, requiresNote: e.target.checked })}
                  />
                  <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">Note Required</span>
                </label>
              </div>
            </div>
            <div className="pt-2">
              <button 
                onClick={editingStatusId ? handleSaveStatusEdit : handleAddStatus}
                className={`w-full md:w-auto px-6 h-11 rounded-lg flex items-center justify-center gap-2 text-sm font-medium transition-all shadow-sm ${
                  editingStatusId ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                {editingStatusId ? <Save size={18} /> : <Plus size={18} />}
                {editingStatusId ? 'Save Status Blueprint Updates' : 'Add Order Status Blueprint'}
              </button>
            </div>
            {editingStatusId && (
              <button 
                onClick={() => {
                  setEditingStatusId(null);
                  setNewStatus({ id: '', label: '', color: '#0f172a', isTerminal: false, triggersEmail: false, triggersWhatsApp: false, triggersPayout: false });
                }}
                className="w-full md:w-auto px-6 h-10 mt-3 md:mt-2 bg-white border border-slate-200 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors"
              >
                Cancel Editing
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(config.orderStatuses || []).map((status: OrderStatusBlueprint) => {
              const count = getOrderStatusCount(status.label);
              return (
                <div 
                  key={status.id}
                  className={`group relative p-5 border rounded-xl transition-all ${
                    editingStatusId === status.id ? 'bg-indigo-50/50 border-indigo-200 shadow-sm' : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full shadow-sm" 
                        style={{ backgroundColor: status.color }} 
                      />
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-semibold text-slate-900">{status.label}</h4>
                        <p className="text-xs text-slate-500">{count} Orders</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleEditStatus(status)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="Edit Blueprint"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => onNavigateToOrders(status.label)}
                        className="p-1.5 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        title="View Orders"
                      >
                        <ClipboardList size={16} />
                      </button>
                      <button 
                        onClick={() => handleDeleteStatus(status.id, status.label)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Status"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {status.isTerminal && (
                      <span className="px-2.5 py-1 bg-slate-900 text-white text-xs font-medium rounded border border-slate-900">Terminal</span>
                    )}
                    {status.triggersEmail && (
                      <span className="px-2.5 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded border border-blue-200">Email</span>
                    )}
                    {status.triggersWhatsApp && (
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs font-medium rounded border border-emerald-200">WhatsApp</span>
                    )}
                    {status.triggersPayout && (
                      <span className="px-2.5 py-1 bg-amber-50 text-amber-700 text-xs font-medium rounded border border-amber-200">Payout</span>
                    )}
                    {status.requiresNote && (
                      <span className="px-2.5 py-1 bg-purple-50 text-purple-700 text-xs font-medium rounded border border-purple-200">Note Req.</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};