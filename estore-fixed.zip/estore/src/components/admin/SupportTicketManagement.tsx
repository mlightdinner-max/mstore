import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  LifeBuoy, Search, Send, Trash2, ShieldCheck,
  Mail, Archive, Paperclip,
  CheckCheck, Clock, RotateCcw, ExternalLink
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';

interface SupportTicketManagementProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  token: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  fetchData?: () => Promise<void>;
}

const SupportTicketManagement = ({ config, onUpdateConfig, token, onShowNotification, fetchData }: SupportTicketManagementProps) => {
  const { id: routeTicketId } = useParams();
  const navigate = useNavigate();
  const basePath = window.location.pathname.startsWith('/home') ? '/home' : window.location.pathname.includes('/affiliate') ? '/affiliate' : '/home';

  const tickets = config.supportTickets || [];

  // Derive selected ticket from URL — avoids setState inside an effect
  const urlTicket = routeTicketId ? (tickets.find((t: any) => t.id === routeTicketId) ?? null) : null;
  const [selectedTicket, setSelectedTicket] = useState<any>(urlTicket);
  const [replyText, setReplyText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'closed'>('all');
  const [isSending, setIsSending] = useState(false);

  const handleReply = async () => {
    if (!replyText || !selectedTicket) return;
    
    setIsSending(true);
    
    try {
      const res = await fetch(`/api/v1/support/tickets/${selectedTicket.id}/reply`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ message: replyText })
      });

      if (res.ok) {
        const updatedTicket = await res.json();
        
        const newTickets = tickets.map((t: any) => 
          t.id === updatedTicket.id ? updatedTicket : t
        );
        
        onUpdateConfig({ ...config, supportTickets: newTickets });
        setReplyText('');
        setSelectedTicket(updatedTicket);
        onShowNotification('Reply dispatched via Support SMTP Relay', 'success');
        if (fetchData) await fetchData();
      } else {
        const error = await res.json();
        onShowNotification(error.error || 'Failed to dispatch reply', 'error');
      }
    } catch (error) {
      console.error('Error sending reply:', error);
      onShowNotification('Network error while dispatching reply', 'error');
    } finally {
      setIsSending(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/v1/support/tickets/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        const updatedTicket = await res.json();
        const newTickets = tickets.map((t: any) => 
          t.id === id ? updatedTicket : t
        );
        onUpdateConfig({ ...config, supportTickets: newTickets });
        if (selectedTicket?.id === id) {
          setSelectedTicket(updatedTicket);
        }
        onShowNotification(`Ticket status updated to ${newStatus}`, 'success');
        if (fetchData) await fetchData();
      } else {
        const error = await res.json();
        onShowNotification(error.error || 'Failed to update status', 'error');
      }
    } catch (error) {
      console.error('Error updating status:', error);
      onShowNotification('Network error while updating status', 'error');
    }
  };

  const handleDeleteTicket = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this ticket?')) return;

    try {
      const res = await fetch(`/api/v1/support/tickets/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (res.ok) {
        const newTickets = tickets.filter((t: any) => t.id !== id);
        onUpdateConfig({ ...config, supportTickets: newTickets });
        if (selectedTicket?.id === id) {
          setSelectedTicket(null);
        }
        onShowNotification('Ticket deleted successfully', 'success');
        if (fetchData) await fetchData();
      } else {
        onShowNotification('Failed to delete ticket', 'error');
      }
    } catch (error) {
      console.error('Error deleting ticket:', error);
      onShowNotification('Network error while deleting ticket', 'error');
    }
  };

  const filteredTickets = tickets.filter((t: any) => {
    const searchVal = searchQuery.toLowerCase();
    const matchesSearch = 
      t.subject.toLowerCase().includes(searchVal) || 
      t.email?.toLowerCase().includes(searchVal) ||
      t.customerName?.toLowerCase().includes(searchVal);
    
    // 'open' = genuinely unresolved (Open / New); 'answered' = waiting for customer reply; 'closed' = resolved
    const matchesStatus = statusFilter === 'all' ||
      (statusFilter === 'open'   && (t.status === 'Open' || t.status === 'New')) ||
      (statusFilter === 'closed' && (t.status === 'Closed' || t.status === 'Answered'));
    
    return matchesSearch && matchesStatus;
  }).sort((a: any, b: any) => new Date(b.lastUpdate || b.createdAt).getTime() - new Date(a.lastUpdate || a.createdAt).getTime());

  return (
    <AdminPageWrapper
      title="Support Tickets"
      description="Unified communication hub for customer inquiries, support requests, and conflict resolution."
      icon={LifeBuoy}
      options={[]}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-2">
        <div className="flex items-center gap-4">
          <div className="bg-white border border-slate-200 p-1 rounded-2xl flex items-center gap-1 shadow-sm overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'All Inboxes', icon: Mail },
              { id: 'open', label: 'Pending Response', icon: Clock },
              { id: 'closed', label: 'Resolved', icon: ShieldCheck }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id as any)}
                className={`px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${
                  statusFilter === tab.id ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <tab.icon size={12} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={14} />
            <input 
              type="text"
              placeholder="SEARCH BY SUBJECT OR EMAIL..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all shadow-sm w-64"
            />
          </div>
        </div>
      </div>

      <div className="flex bg-white rounded-2xl border border-slate-200 overflow-hidden h-[calc(100vh-280px)] shadow-sm mt-6">
        {/* Thread Sidebar */}
        <div className="w-[380px] border-r border-slate-100 flex flex-col bg-white">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-[0.1em]">Inbox</h3>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-md text-xs font-bold">{filteredTickets.length}</span>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {filteredTickets.map((ticket: any) => (
              <button
                key={ticket.id}
                onClick={() => navigate(`${basePath}/support/${ticket.id}`)}
                className={`w-full text-left p-4 border-b border-slate-50 transition-all hover:bg-slate-50 ${
                  selectedTicket?.id === ticket.id ? 'bg-blue-50/50' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-xs font-bold truncate ${selectedTicket?.id === ticket.id ? 'text-slate-900' : 'text-slate-700'}`}>
                    {ticket.customerName || ticket.email}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    {new Date(ticket.lastUpdate || ticket.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                <div className="text-xs font-semibold text-slate-900 truncate mb-1">
                  {ticket.subject}
                </div>
                <div className="text-xs text-slate-500 truncate">
                  {ticket.messages?.[0]?.text?.substring(0, 60)}...
                </div>
              </button>
            ))}
            {filteredTickets.length === 0 && (
              <div className="p-12 text-center text-slate-400">
                <Mail size={32} className="mx-auto mb-3 opacity-20" />
                <p className="text-xs font-medium uppercase tracking-widest">No messages</p>
              </div>
            )}
          </div>
        </div>

        {/* Thread Content */}
        <div className="flex-1 flex flex-col min-w-0 bg-white">
          {selectedTicket ? (
            <>
              {/* Email Toolbar */}
              <div className="px-6 py-3 border-b border-slate-100 flex items-center justify-between bg-white text-slate-600">
                <div className="flex items-center gap-2">
                  <button onClick={() => navigate(`${basePath}/support`)} className="p-1.5 hover:bg-slate-100 rounded-md">
                    <RotateCcw size={16} />
                  </button>
                  <button className="p-1.5 hover:bg-slate-100 rounded-md"><Archive size={16} /></button>
                  <button className="p-1.5 hover:bg-slate-100 rounded-md" onClick={() => handleDeleteTicket(selectedTicket.id)}><Trash2 size={16} /></button>
                  <div className="h-4 w-px bg-slate-200 mx-1" />
                  <button 
                  onClick={() => handleStatusChange(selectedTicket.id, selectedTicket.status === 'Closed' ? 'Open' : 'Closed')}
                  className={`px-3 py-1 rounded-md text-xs font-bold ${
                    selectedTicket.status === 'Closed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {selectedTicket.status === 'Closed' ? 'Resolved' : 'Mark Resolved'}
                </button>
                </div>
                <div className="text-xs text-slate-400 font-medium">#{selectedTicket.id.slice(0, 8)}</div>
              </div>

              {/* Message Thread */}
              <div className="flex-1 overflow-y-auto px-10 py-8 custom-scrollbar space-y-8 bg-white">
                <h1 className="text-2xl font-black text-slate-950 tracking-tight pb-6 border-b border-slate-100">{selectedTicket.subject}</h1>

                <div className="space-y-6">
                  {(selectedTicket.messages || []).map((msg: any, idx: number) => (
                    <div key={msg.id || idx} className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
                      <div className="flex items-center justify-between p-4 bg-slate-50 border-b border-slate-100">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black uppercase ${msg.sender === 'agent' ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-600'}`}>
                            {msg.sender === 'agent' ? 'S' : selectedTicket.customerName?.charAt(0) || 'C'}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 text-xs">
                              {msg.sender === 'agent' ? `${config.storeName || 'Store'} Support` : (selectedTicket.customerName || 'Customer')}
                            </div>
                            <div className="text-xs text-slate-500">
                              {msg.sender === 'agent' ? `to ${selectedTicket.email}` : `from ${selectedTicket.email}`}
                            </div>
                          </div>
                        </div>
                        <span className="text-xs text-slate-400 font-medium">
                          {new Date(msg.timestamp).toLocaleDateString()} at {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                      </div>
                      <div className="p-6 text-[13px] text-slate-800 leading-relaxed whitespace-pre-wrap font-medium">
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reply Section */}
              <div className="p-8 border-t border-slate-100 bg-white">
                <div className="max-w-4xl mx-auto w-full space-y-4">
                  <div className="flex items-center gap-3 px-4">
                    <button className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-100 transition-all">
                      <Paperclip size={12} />
                      <span>Attach Assets</span>
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-100 transition-all">
                      <ExternalLink size={12} />
                      <span>Insert Shortcut</span>
                    </button>
                  </div>
                  <div className="relative group">
                    <textarea 
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder={`REPLY TO ${selectedTicket.customerName.toUpperCase()}...`}
                      rows={6}
                      className="w-full px-6 py-5 bg-white border border-slate-200 focus:border-slate-400 rounded-xl text-sm font-medium focus:outline-none transition-all resize-none placeholder:text-slate-400 shadow-sm"
                    />
                    <div className="absolute right-4 bottom-4 flex items-center gap-3">
                      {isSending && (
                        <div className="flex items-center gap-2 text-slate-400">
                          <RotateCcw size={12} className="animate-spin" />
                          <span className="text-xs font-medium uppercase tracking-wider">Sending...</span>
                        </div>
                      )}
                      <button 
                        onClick={handleReply}
                        disabled={!replyText || isSending}
                        className="flex items-center gap-2 px-6 py-2.5 bg-slate-900 text-white rounded-lg hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm active:scale-95"
                      >
                        <Send size={14} />
                        <span className="text-xs font-bold">Send Reply</span>
                      </button>
                    </div>
                  </div>
                  <div className="px-4 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-slate-400 font-bold">
                      <CheckCheck size={14} className="text-emerald-500" />
                      <span>Response will use Support SMTP Relay: <strong>{config.integrations?.supportEmail?.from || 'support@store.com'}</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-300 space-y-6">
              <div className="w-24 h-24 bg-slate-50 rounded-2xl flex items-center justify-center rotate-3 border border-slate-100">
                <LifeBuoy size={48} className="text-slate-200" />
              </div>
              <div className="text-center max-w-xs px-8">
                <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-2">Central Inbox</p>
                <p className="text-xs font-medium text-slate-400 uppercase tracking-wider leading-relaxed">Select a communication thread from the sidebar to engage with clients.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default SupportTicketManagement;
