import React, { useMemo, useState } from 'react';
import { Calendar, DollarSign, ShoppingCart, Users, CreditCard } from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { LOCALIZATION } from '../../constants';
import { StatsCard } from './StatsCard';
import AdminAnalytics from './AdminAnalytics';

interface AdminRevenueProps {
  orders: any[];
}

export const AdminRevenue = ({ orders }: AdminRevenueProps) => {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('7d');

  const filteredOrders = useMemo(() => {
    if (timeRange === 'all') return orders;
    const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    return orders.filter(o => new Date(o.createdAt || o.date) >= cutoff);
  }, [orders, timeRange]);

  const stats = useMemo(() => {
    const activeOrders = filteredOrders.filter(o => o.status !== 'Cancelled' && o.status !== 'Returned');
    const totalRevenue = activeOrders.reduce((sum, o) => sum + o.total, 0);
    const totalOrders = activeOrders.length;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const uniqueCustomers = new Set(activeOrders.map(o => o.email || o.phone)).size;

    return { totalRevenue, totalOrders, avgOrderValue, uniqueCustomers };
  }, [filteredOrders]);

  return (
    <AdminPageWrapper
      title="Revenue & Sales"
      description="Comprehensive analysis of store sales, revenue velocity, and overall financial performance."
      icon={DollarSign}
      options={[{"label":"Real-time Tracking","description":"Monitor every transaction as it happens."},{"label":"Trend Analysis","description":"Identify sales patterns over various timeframes."}]}
    >
      <div className="flex justify-end mb-6">
        <div className="inline-flex bg-slate-100 p-1 rounded-2xl border border-slate-200 overflow-x-auto no-scrollbar">
            {(['7d', '30d', '90d', 'all'] as const).map(range => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all ${
                  timeRange === range ? 'bg-white shadow-sm text-slate-900 border border-slate-200' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {range === 'all' ? 'All Time' : range}
              </button>
            ))}
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Gross Revenue" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalRevenue.toLocaleString()}`} 
          icon={DollarSign} 
          color="emerald"
          delay={0.1}
        />
        <StatsCard 
          label="Total Orders" 
          value={stats.totalOrders.toLocaleString()} 
          icon={ShoppingCart} 
          color="blue"
          delay={0.2}
        />
        <StatsCard 
          label="Avg. Order Value" 
          value={`${LOCALIZATION.CURRENCY}${stats.avgOrderValue.toLocaleString()}`} 
          icon={CreditCard} 
          color="purple"
          delay={0.3}
        />
        <StatsCard 
          label="Active Customers" 
          value={stats.uniqueCustomers.toLocaleString()} 
          icon={Users} 
          color="slate"
          delay={0.4}
        />
      </div>

      <div className="space-y-8 mt-10">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-sm">
          <AdminAnalytics orders={filteredOrders} height={350} hideStats />
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-sm">
          <h3 className="text-sm font-medium uppercase tracking-wider text-slate-900 mb-8 flex items-center gap-3">
            <Calendar size={18} className="text-slate-400" />
            Recent Sales Feed
          </h3>
          {filteredOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-12 text-slate-300">
              <Calendar size={48} className="mb-4 opacity-20" />
              <p className="text-xs font-medium uppercase tracking-wider text-slate-400">No sales data found.</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {filteredOrders.filter(o => o.status !== 'Cancelled').slice(0, 15).map((order: any, i: number) => (
                <div key={i} className="flex justify-between items-center p-5 border border-slate-50 bg-slate-50/30 rounded-3xl hover:bg-white hover:border-slate-200 transition-all group">
                  <div>
                    <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Order #{order.id.slice(-6)}</p>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">{new Date(order.createdAt || order.date).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-emerald-600 text-base tracking-tighter">{LOCALIZATION.CURRENCY}{order.total.toLocaleString()}</p>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">{order.items?.length || 0} items</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AdminPageWrapper>
  );
};
