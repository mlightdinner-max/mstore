import React from 'react';
import { Search, Filter, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdminToolbarProps {
    searchQuery: string;
    onSearchChange: (val: string) => void;
    searchPlaceholder?: string;
    filters?: React.ReactNode;
    advancedFilters?: React.ReactNode;
    showAdvanced?: boolean;
    setShowAdvanced?: (val: boolean) => void;
    leftActions?: React.ReactNode;
}

export const AdminToolbar: React.FC<AdminToolbarProps> = ({
    searchQuery,
    onSearchChange,
    searchPlaceholder = "Search records...",
    filters,
    advancedFilters,
    showAdvanced,
    setShowAdvanced,
    leftActions
}) => {
    return (
        <div className="w-full bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col lg:flex-row gap-4">
                {leftActions && (
                    <div className="flex items-center gap-4">
                        {leftActions}
                    </div>
                )}
                <div className="flex-1 relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={16} />
                    <input
                        type="text"
                        placeholder={searchPlaceholder}
                        value={searchQuery}
                        onChange={(e) => onSearchChange(e.target.value)}
                        className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all placeholder:text-slate-400"
                    />
                </div>
                <div className="flex flex-wrap items-center gap-3">
                    {filters}
                    {advancedFilters && setShowAdvanced && (
                        <button
                            onClick={() => setShowAdvanced(!showAdvanced)}
                            className={`px-6 py-2.5 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center space-x-2 border ${
                                showAdvanced ? 'bg-slate-900 text-white border-slate-900 shadow-lg' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                        >
                            <Filter size={14} />
                            <span>Filters</span>
                            <div className="transition-transform duration-300" style={{ transform: showAdvanced ? 'rotate(180deg)' : 'rotate(0deg)' }}>
                                <ChevronDown size={14} />
                            </div>
                        </button>
                    )}
                </div>
            </div>
            <AnimatePresence>
                {showAdvanced && advancedFilters && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                    >
                        <div className="pt-6 border-t border-slate-100">
                            {advancedFilters}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};
