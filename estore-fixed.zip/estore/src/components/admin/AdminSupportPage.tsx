import React, { useState } from 'react';
import { AdminSectionHeader } from './AdminSectionHeader';
import { Config } from '../../types';

interface AdminSupportPageProps {
  config: Config;
  onUpdateConfig: (c: any) => Promise<boolean>;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

import { HelpCircle, Plus, Trash2 } from 'lucide-react';

export const AdminSupportPage = ({ config, onUpdateConfig, onShowNotification }: AdminSupportPageProps) => {
  const [formData, setFormData] = useState({
    supportHeading: config.supportHeading || '',
    supportSubheading: config.supportSubheading || '',
    supportEmail: config.supportEmail || ''
  });

  const [faqs, setFaqs] = useState<any[]>(config.faqs || []);
  const [isSaving, setIsSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAddFaq = () => {
    setFaqs([...faqs, { id: crypto.randomUUID(), question: '', answer: '' }]);
  };

  const handleFaqChange = (id: string, field: string, value: string) => {
    setFaqs(faqs.map(f => f.id === id ? { ...f, [field]: value } : f));
  };

  const handleDeleteFaq = (id: string) => {
    setFaqs(faqs.filter(f => f.id !== id));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const success = await onUpdateConfig({ 
        ...config, 
        ...formData,
        faqs,
        supportPhone: config.supportPhone || '',
        storeAddress: config.storeAddress || '',
        supportHoursWorkingDays: config.supportHoursWorkingDays || '',
        supportHoursWorkingTime: config.supportHoursWorkingTime || '',
        supportHoursWeekendDays: config.supportHoursWeekendDays || '',
        supportHoursWeekendTime: config.supportHoursWeekendTime || ''
      });
      
      if (success) {
        onShowNotification('Support page content updated', 'success');
      } else {
        onShowNotification('Failed to update support page content', 'error');
      }
    } catch (error) {
      console.error('Error saving support page:', error);
      onShowNotification('Network error while saving', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-10 pb-12">
      <AdminSectionHeader 
        title="Help Centre Content" 
        description="Craft your customer support experience. Manage headings, contact details, and create a robust FAQ list." 
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
        {/* Left Column: Config */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-8">
            <div className="space-y-4">
              <h3 className="text-xs font-medium uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <HelpCircle size={14} className="text-slate-400" />
                <span>Page Header</span>
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium uppercase tracking-wider text-slate-500 mb-2 ml-1">Heading</label>
                  <input 
                    type="text" 
                    name="supportHeading"
                    value={formData.supportHeading}
                    onChange={handleChange}
                    placeholder="Get in Touch"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium uppercase tracking-wider text-slate-500 mb-2 ml-1">Subheading</label>
                  <textarea 
                    name="supportSubheading"
                    value={formData.supportSubheading}
                    onChange={handleChange}
                    placeholder="We're here to help..."
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    rows={3}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xs font-medium uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Trash2 size={14} className="text-slate-400 opacity-0" /> {/* Spacer */}
                <span>Contact Details</span>
              </h3>
              <div>
                <label className="block text-xs font-medium uppercase tracking-wider text-slate-500 mb-2 ml-1">Support Email</label>
                <input 
                  type="text" 
                  name="supportEmail"
                  value={formData.supportEmail}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                  placeholder="support@yourbrand.com"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl text-xs font-medium uppercase tracking-wider hover:bg-slate-800 transition-all shadow-xl shadow-slate-950/20 disabled:opacity-50"
              >
                {isSaving ? 'Dispatching Changes...' : 'Save Changes'}
              </button>
            </div>
          </div>
          
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-3">
             <div className="flex items-center gap-2 text-slate-400">
               <HelpCircle size={14} />
               <span className="text-xs font-medium uppercase tracking-wider">Policy Note</span>
             </div>
             <p className="text-xs text-slate-500 font-medium leading-relaxed italic">
                "Mobile and Address options are currently hidden as your store follows an email-first support model. This ensures a consistent audit trail for all customer inquiries."
             </p>
          </div>
        </div>

        {/* Right Column: FAQs */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="p-5 sm:p-8 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">FAQ Knowledge Base</h3>
                <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mt-1">Add common questions and answers for self-service support.</p>
              </div>
              <button 
                onClick={handleAddFaq}
                className="flex items-center space-x-2 px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-800 transition-all"
              >
                <Plus size={14} />
                <span>Add FAQ</span>
              </button>
            </div>

            <div className="p-8 space-y-6 max-h-[600px] overflow-y-auto custom-scrollbar">
              {faqs.length > 0 ? faqs.map((faq, index) => (
                <div key={faq.id} className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-4 group relative">
                  <button 
                    onClick={() => handleDeleteFaq(faq.id)}
                    className="absolute top-4 right-4 p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={14} />
                  </button>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-slate-400 mb-1.5 ml-1">Question {index + 1}</label>
                      <input 
                        type="text"
                        value={faq.question}
                        onChange={(e) => handleFaqChange(faq.id, 'question', e.target.value)}
                        placeholder="e.g. What is your return policy?"
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wider text-slate-400 mb-1.5 ml-1">Answer</label>
                      <textarea 
                        value={faq.answer}
                        onChange={(e) => handleFaqChange(faq.id, 'answer', e.target.value)}
                        placeholder="Provide a clear, concise answer..."
                        rows={3}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                      />
                    </div>
                  </div>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center py-20 text-slate-300">
                  <div className="p-6 bg-slate-50 rounded-full mb-4">
                    <HelpCircle size={48} className="text-slate-200" />
                  </div>
                  <p className="text-xs font-medium uppercase tracking-wider">No FAQs established</p>
                  <p className="text-xs font-medium uppercase tracking-wider mt-1">Establish a knowledge base to reduce support load.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
