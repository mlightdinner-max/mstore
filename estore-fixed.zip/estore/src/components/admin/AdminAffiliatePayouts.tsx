import React, { useState } from 'react';
import { Search, Info } from 'lucide-react';
import { AdminSectionHeader } from './AdminSectionHeader';
import { LOCALIZATION } from '../../constants';

interface AdminAffiliatePayoutsProps {
  users: any[];
  payouts: any[];
  onProcessPayout: (p: any) => Promise<void>;
}

export const AdminAffiliatePayouts = ({ users, payouts, onProcessPayout }: AdminAffiliatePayoutsProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const pendingPayouts = payouts.filter(p => p.status === 'pending' || p.status === 'Pending').map(p => {
    const affiliate = users.find(u => u.affiliateId === p.affiliateId);
    return { ...p, affiliate };
  }).filter(p => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return p.affiliate?.name.toLowerCase().includes(term) || 
           p.affiliate?.email.toLowerCase().includes(term) || 
           p.affiliateId.toLowerCase().includes(term);
  });

  const paidPayouts = payouts.filter(p => p.status === 'paid' || p.status === 'Paid').map(p => {
    const affiliate = users.find(u => u.affiliateId === p.affiliateId);
    return { ...p, affiliate };
  });

  return (
    <div className="space-y-6 pb-12">
      <AdminSectionHeader 
        title="Affiliate Payouts" 
        description="Process and track commission payouts to your affiliate partners." 
        options={[{"label":"Process Payout","description":"Mark pending commissions as paid."},{"label":"View History","description":"Review past payout records and amounts."}]} 
      />

      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-5">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
          <input 
            type="text"
            placeholder="Search pending payouts by affiliate name or ID..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 text-xs font-medium"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-slate-100">
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Affiliate</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Payout ID</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Request Date</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Amount</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Payment Instructions</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400 text-right pr-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {pendingPayouts.map(p => (
                <tr key={p.id} className="group hover:bg-slate-50 transition-colors">
                  <td className="py-3 pr-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-slate-900">{p.affiliate?.name || 'Unknown'}</span>
                      <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{p.affiliateId}</span>
                    </div>
                  </td>
                  <td className="py-3 text-xs font-mono text-slate-500 pr-4">{p.id}</td>
                  <td className="py-3 text-xs text-slate-500 pr-4">{new Date(p.requestedAt || p.createdAt).toLocaleDateString()}</td>
                  <td className="py-3 text-xs font-bold text-amber-600 pr-4">{LOCALIZATION.CURRENCY}{p.amount?.toFixed(2) || '0.00'}</td>
                  <td className="py-3 pr-4">
                    <div className="text-xs flex items-start gap-1 p-2 bg-slate-100 rounded border border-slate-200 max-w-[200px]">
                      <Info size={12} className="text-slate-400 shrink-0 mt-0.5" />
                      <span className="text-slate-600 whitespace-pre-wrap font-mono leading-relaxed line-clamp-3 hover:line-clamp-none cursor-pointer" title="Click to expand">{p.affiliate?.paymentInfo || 'No instructions provided.'}</span>
                    </div>
                  </td>
                  <td className="py-3 text-right pr-4">
                    <button 
                      onClick={() => onProcessPayout({
                        ...p,
                        status: 'paid',
                        paidAt: new Date().toISOString()
                      })}
                      className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-medium uppercase tracking-wider hover:bg-emerald-700 transition-all shadow-sm"
                    >
                      Mark as Paid
                    </button>
                  </td>
                </tr>
              ))}
              {pendingPayouts.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-xs text-slate-400 font-bold uppercase tracking-widest">
                    No pending payout requests
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Paid Payouts History */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
         <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Completed Payouts</h4>
         <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-slate-100">
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Affiliate</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Payout ID</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Paid Date</th>
                <th className="pb-3 text-xs font-medium uppercase tracking-wider text-slate-400">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {paidPayouts.map(p => (
                 <tr key={p.id}>
                    <td className="py-3 pr-4">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-900">{p.affiliate?.name || 'Unknown'}</span>
                        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{p.affiliateId}</span>
                      </div>
                    </td>
                    <td className="py-3 text-xs font-mono text-slate-500 pr-4">{p.id}</td>
                    <td className="py-3 text-xs text-slate-500 pr-4">{new Date(p.paidAt).toLocaleDateString()}</td>
                    <td className="py-3 text-xs font-bold text-emerald-600 pr-4">{LOCALIZATION.CURRENCY}{p.amount?.toFixed(2) || '0.00'}</td>
                 </tr>
               ))}
               {paidPayouts.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-xs text-slate-400 font-bold uppercase tracking-widest">
                    No completed payouts
                  </td>
                </tr>
              )}
            </tbody>
          </table>
         </div>
      </div>
    </div>
  );
};

