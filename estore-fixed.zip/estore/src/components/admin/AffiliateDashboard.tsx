import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DollarSign, TrendingUp, ShoppingBag, CheckCircle2, Copy, Clock, Package, CreditCard
} from 'lucide-react';
import { Product, Order } from '../../types';
import { LOCALIZATION } from '../../constants';

import { AdminPageWrapper } from './AdminPageWrapper';
import { StatsCard } from './StatsCard';

interface AffiliateDashboardProps {
  user: any;
  products: Product[];
  orders: Order[];
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  payouts: any[];
  token: string;
  onRefresh: () => void;
}

const AffiliateDashboard = ({ user, products, orders, onShowNotification, payouts, token, onRefresh }: AffiliateDashboardProps) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'links' | 'payouts'>('overview');
  const [copied, setCopied] = useState<string | null>(null);
  const [paymentInfo, setPaymentInfo] = useState(user.paymentInfo || '');
  const [isSavingInfo, setIsSavingInfo] = useState(false);
  const [isRequestingPayout, setIsRequestingPayout] = useState(false);

  const affiliateOrders = useMemo(() => {
    // Guard: if affiliateId is missing, return empty array — never show all orders
    if (!user.affiliateId) return [];
    return orders.filter(o => o.affiliateId === user.affiliateId);
  }, [orders, user.affiliateId]);

  const stats = useMemo(() => {
    const totalSales = affiliateOrders.reduce((sum, o) => sum + o.total, 0);
    const totalCommission = affiliateOrders.reduce((sum, o) => sum + (o.affiliatePayout || o.commissionAmount || 0), 0);
    const pendingPayout = payouts
      .filter(p => p.affiliateId === user.affiliateId && p.status === 'pending')
      .reduce((sum, p) => sum + p.amount, 0);
    const paidPayout = payouts
      .filter(p => p.affiliateId === user.affiliateId && p.status === 'paid')
      .reduce((sum, p) => sum + p.amount, 0);

    return { totalSales, totalCommission, pendingPayout, paidPayout };
  }, [affiliateOrders, payouts, user.affiliateId]);

  const eligibleOrdersForPayout = useMemo(() => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    return affiliateOrders.filter(o => {
      if (o.status?.toUpperCase() !== 'CLOSED') return false;
      if ((o as any).affiliatePayoutStatus && (o as any).affiliatePayoutStatus !== 'None') return false;
      // An order is eligible after the 7-day holding period has passed (closingDate <= oneWeekAgo)
      const closingDate = new Date((o as any).closingDate || (o as any).updatedAt || new Date().toISOString());
      return closingDate <= oneWeekAgo;
    });
  }, [affiliateOrders]);

  const handleCopyLink = (productId: string) => {
    const link = `${window.location.origin}/product/${productId}?ref=${user.affiliateId}`;
    navigator.clipboard.writeText(link);
    setCopied(productId);
    onShowNotification('Affiliate link copied to clipboard!', 'success');
    setTimeout(() => setCopied(null), 2000);
  };

  const handleSavePaymentInfo = async () => {
    setIsSavingInfo(true);
    try {
      const res = await fetch(`/api/v1/users/${user.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ ...user, paymentInfo })
      });
      if (res.ok) {
        onShowNotification('Payment instructions saved successfully', 'success');
        onRefresh();
      } else {
        onShowNotification('Failed to save payment instructions', 'error');
      }
    } catch {
      onShowNotification('An error occurred', 'error');
    } finally {
      setIsSavingInfo(false);
    }
  };

  const handleRequestPayout = async () => {
    if (eligibleOrdersForPayout.length === 0) return;
    setIsRequestingPayout(true);
    try {
      const orderIds = eligibleOrdersForPayout.map(o => o.id);
      const res = await fetch(`/api/v1/affiliates/payouts/request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ orderIds })
      });
      if (res.ok) {
        onShowNotification('Payout requested successfully!', 'success');
        onRefresh();
      } else {
        const err = await res.json();
        onShowNotification(err.error || 'Failed to request payout', 'error');
      }
    } catch {
      onShowNotification('An error occurred', 'error');
    } finally {
      setIsRequestingPayout(false);
    }
  };

  return (
    <AdminPageWrapper
      title="Welcome to the Partner Portal"
      description="Track your performance, manage your links, and view your payout history."
      options={[
        { label: "Performance Tracking", description: "Monitor your sales and commissions in real-time." },
        { label: "Link Management", description: "Generate and copy your unique affiliate links." }
      ]}
      toolbar={
        <div className="flex flex-col md:flex-row md:items-center justify-end gap-6 w-full">
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 overflow-x-auto no-scrollbar">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'overview' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('links')}
            className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'links' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            My Links
          </button>
          <button 
            onClick={() => setActiveTab('payouts')}
            className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'payouts' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Payouts
          </button>
        </div>
      </div>
    }>

      {/* Stats Header */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Total Earnings" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalCommission.toLocaleString()}`} 
          icon={DollarSign} 
          color="emerald"
          delay={0.1}
        />
        <StatsCard 
          label="Total Sales" 
          value={affiliateOrders.length} 
          icon={ShoppingBag} 
          color="blue"
          subtext={`Value: ${LOCALIZATION.CURRENCY}${stats.totalSales.toLocaleString()}`}
          delay={0.2}
        />
        <StatsCard 
          label="Pending Payout" 
          value={`${LOCALIZATION.CURRENCY}${stats.pendingPayout.toLocaleString()}`} 
          icon={Clock} 
          color="amber"
          delay={0.3}
        />
        <StatsCard 
          label="Paid Payouts" 
          value={`${LOCALIZATION.CURRENCY}${stats.paidPayout.toLocaleString()}`} 
          icon={CheckCircle2} 
          color="emerald"
          delay={0.4}
        />
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 min-h-[400px]">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div 
                key="overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
                    <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-4">Recent Referrals</h4>
                    <div className="space-y-3">
                      {affiliateOrders.slice(0, 5).map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">
                              <ShoppingBag size={14} />
                            </div>
                            <div>
                              <p className="text-xs font-bold text-slate-900">Order #{order.id.slice(-6)}</p>
                              <p className="text-xs text-slate-400 font-medium">{order.status}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xs font-bold text-slate-900">{LOCALIZATION.CURRENCY}{order.total.toFixed(2)}</p>
                            <p className="text-xs text-primary/80 font-bold uppercase tracking-widest">+{LOCALIZATION.CURRENCY}{(order.affiliatePayout || order.commissionAmount || 0).toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                      {affiliateOrders.length === 0 && (
                        <div className="py-12 text-center">
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No referrals yet</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
                      <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-4">Your Affiliate Info</h4>
                      <div className="space-y-4">
                        <div className="p-4 bg-white rounded-2xl border border-slate-100 space-y-2">
                          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Affiliate ID</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-black text-slate-900 tracking-tight font-mono">{user.affiliateId}</span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(user.affiliateId);
                                onShowNotification('ID copied!', 'success');
                              }}
                              className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-all"
                            >
                              <Copy size={16} />
                            </button>
                          </div>
                        </div>
                        <div className="p-4 bg-white rounded-2xl border border-slate-100 space-y-2">
                          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Commission Rate</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-black text-slate-900 tracking-tight">{user.commissionRate}%</span>
                            <div className="p-2 bg-primary/5 text-primary rounded-lg">
                              <TrendingUp size={16} />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 space-y-4">
                      <div className="flex items-center gap-2 mb-2">
                        <CreditCard size={14} className="text-slate-400" />
                        <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Payout Instructions</h4>
                      </div>
                      <p className="text-xs text-slate-500 mb-2">Provide your preferred method to receive payouts (e.g. Bank Account details, PayPal email).</p>
                      <textarea
                        value={paymentInfo}
                        onChange={(e) => setPaymentInfo(e.target.value)}
                        placeholder="Enter your payment instructions here..."
                        className="w-full h-24 px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all resize-none"
                      />
                      <button
                        onClick={handleSavePaymentInfo}
                        disabled={isSavingInfo}
                        className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isSavingInfo ? 'Saving...' : 'Save Instructions'}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'links' && (
              <motion.div 
                key="links"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.filter(p => p.isApproved !== false).map((product) => (
                    <div key={product.id} className="bg-slate-50 rounded-3xl p-4 border border-slate-100 group hover:shadow-xl hover:shadow-slate-900/5 transition-all">
                      <div className="aspect-square bg-white rounded-2xl overflow-hidden mb-4 relative">
                        {product.image ? (
                          <img src={product.image} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-300">
                             <Package size={32} />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button 
                            onClick={() => handleCopyLink(product.id)}
                            className="px-6 py-2.5 bg-white text-slate-900 rounded-xl text-xs font-medium uppercase tracking-wider shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-all"
                          >
                            {copied === product.id ? 'Copied!' : 'Copy Link'}
                          </button>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <h5 className="text-xs font-bold text-slate-900 line-clamp-1">{product.name}</h5>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-400">{LOCALIZATION.CURRENCY}{product.price}</span>
                          <span className="text-xs font-medium text-emerald-600 uppercase tracking-wider">Earn {LOCALIZATION.CURRENCY}{(product.price * (user.commissionRate / 100)).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'payouts' && (
              <motion.div 
                key="payouts"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-6 flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="text-sm font-black text-emerald-900 uppercase tracking-widest">Eligible For Payout</h3>
                    <p className="text-xs text-emerald-700 font-medium">Orders closed in the last 7 days are eligible for a payout request.</p>
                    <p className="text-xl font-black text-emerald-600 mt-2">
                       {LOCALIZATION.CURRENCY}{eligibleOrdersForPayout.reduce((total, o) => total + (o.affiliatePayout || o.commissionAmount || 0), 0).toFixed(2)}
                       <span className="text-xs text-emerald-700 font-bold ml-2">({eligibleOrdersForPayout.length} orders)</span>
                    </p>
                  </div>
                  <button
                    onClick={handleRequestPayout}
                    disabled={eligibleOrdersForPayout.length === 0 || isRequestingPayout || !user.paymentInfo}
                    className="px-6 py-3 bg-emerald-600 text-white rounded-xl text-xs font-medium uppercase tracking-wider disabled:opacity-50 hover:bg-emerald-700 transition-colors shadow-lg"
                  >
                    {!user.paymentInfo ? 'Add Payment Info First' : (isRequestingPayout ? 'Requesting...' : 'Request Payout')}
                  </button>
                </div>
                
                <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
                  <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-4">Payout History</h4>
                  <div className="space-y-3">
                    {payouts.filter(p => p.affiliateId === user.affiliateId).map(payout => (
                      <div key={payout.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 gap-4">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${payout.status === 'paid' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                            {payout.status === 'paid' ? <CheckCircle2 size={18} /> : <Clock size={18} />}
                          </div>
                          <div>
                            <p className="text-xs font-medium text-slate-900 uppercase tracking-wider">{payout.id}</p>
                            <p className="text-xs font-bold text-slate-400 uppercase">{new Date(payout.requestedAt).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider ${payout.status === 'paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                              {payout.status}
                            </span>
                            <span className="text-lg font-black text-slate-900">
                              {LOCALIZATION.CURRENCY}{payout.amount.toFixed(2)}
                            </span>
                        </div>
                      </div>
                    ))}
                    {payouts.filter(p => p.affiliateId === user.affiliateId).length === 0 && (
                      <div className="py-12 text-center">
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No payout history</p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AffiliateDashboard;
