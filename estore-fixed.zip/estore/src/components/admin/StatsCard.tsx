import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  label?: string;
  title?: string;
  value: string | number;
  icon: LucideIcon;
  color?: string;
  trend?: {
    value: string | number;
    isPositive: boolean;
  };
  subtext?: string;
  delay?: number;
}

export const StatsCard = ({ 
  label,
  title,
  value, 
  icon: Icon, 
  color = 'slate', 
  trend, 
  subtext,
  delay = 0 
}: StatsCardProps) => {
  const displayLabel = label ?? title ?? '';
  const colorMap: Record<string, { bg: string; text: string }> = {
    emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600' },
    blue: { bg: 'bg-blue-50', text: 'text-blue-600' },
    amber: { bg: 'bg-amber-50', text: 'text-amber-600' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600' },
    rose: { bg: 'bg-rose-50', text: 'text-rose-600' },
    slate: { bg: 'bg-slate-50', text: 'text-slate-600' },
    indigo: { bg: 'bg-indigo-50', text: 'text-indigo-600' },
  };

  const colors = colorMap[color] || colorMap.slate;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 group hover:border-slate-900 transition-all"
    >
      <div className="flex items-center justify-between">
        <div className={`p-3 ${colors.bg} ${colors.text} rounded-2xl group-hover:bg-slate-900 group-hover:text-white transition-all`}>
          <Icon size={20} />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium uppercase tracking-wider ${
            trend.isPositive ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
          }`}>
            {trend.isPositive ? '+' : '-'}{trend.value}
          </div>
        )}
      </div>
      <div>
        <p className="section-label mb-1 min-h-[2rem] flex items-start">{displayLabel}</p>
        <div className="flex items-baseline gap-2 mt-1">
          <h3 className="premium-heading text-3xl sm:text-4xl text-slate-950">{value}</h3>
          {subtext && (
            <span className="section-label">{subtext}</span>
          )}
        </div>
      </div>
    </motion.div>
  );
};
