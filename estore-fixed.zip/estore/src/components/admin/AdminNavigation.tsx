import React from 'react';
import { Menu, Layout, TrendingUp, Trash2, Link as LinkIcon, X, Save, RefreshCw, Share2, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { Config, Product } from '../../types';
import { AdminSectionHeader } from './AdminSectionHeader';

interface AdminNavigationProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
  products: Product[];
  isValidating?: boolean;
}

export const AdminNavigation = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, products, isValidating }: AdminNavigationProps) => {
  return (
    <div className="space-y-8 pb-12">
      <AdminSectionHeader 
        title="Navigation & Layout" 
        description="Configure the main menu, footer links, and overall site layout structure." 
        options={[{"label":"Edit Menu","description":"Add, remove, or reorder main navigation links."},{"label":"Manage Footer","description":"Update the links displayed in the site footer."}]} 
      />
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1 ml-auto">
          {hasUnsavedChanges && (
            <button 
              onClick={onSave}
              disabled={isValidating}
              className="btn-primary flex items-center gap-2"
            >
              {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
              <span>Save Changes</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
              <Menu size={20} />
            </div>
            <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Main Navigation</h3>
          </div>
          
          <div className="space-y-4">
            {config.navigation?.map((nav, idx) => (
              <div key={nav.path + idx} className="flex gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-200 group hover:bg-white transition-all shadow-sm">
                <div className="flex-1 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">Label</label>
                      <input 
                        type="text" 
                        value={nav.label || ''} 
                        onChange={(e) => {
                          const newNav = [...(config.navigation || [])];
                          newNav[idx].label = e.target.value;
                          onUpdateConfig({ ...config, navigation: newNav });
                        }}
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-500/10 font-black text-xs text-slate-900" 
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">Path</label>
                      <input 
                        type="text" 
                        value={nav.path || ''} 
                        onChange={(e) => {
                          const newNav = [...(config.navigation || [])];
                          newNav[idx].path = e.target.value;
                          onUpdateConfig({ ...config, navigation: newNav });
                        }}
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-500/10 font-bold text-xs text-slate-500" 
                      />
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => onUpdateConfig({ ...config, navigation: config.navigation.filter((_, i) => i !== idx) })}
                  className="p-3 text-slate-300 hover:text-rose-500 transition-colors self-center bg-white border border-slate-100 rounded-xl shadow-sm hover:border-rose-100 transition-all font-black"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
            <button 
              onClick={() => onUpdateConfig({ ...config, navigation: [...(config.navigation || []), { label: 'New Link', path: '/' }] })}
              className="w-full py-4 border-2 border-dashed border-slate-200 text-slate-400 font-black text-xs uppercase tracking-widest rounded-2xl hover:border-slate-900 hover:text-slate-900 transition-all font-black"
            >
              Add Menu Item
            </button>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
                <Layout size={20} />
              </div>
              <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Layout Settings</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="space-y-0.5">
                  <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Show Search</p>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Enable global product search in header.</p>
                </div>
                <button 
                  onClick={() => onUpdateConfig({ ...config, showSearch: !config.showSearch })}
                  className={`w-12 h-6 rounded-full transition-all relative ${config.showSearch ? 'bg-slate-900 shadow-lg' : 'bg-slate-200'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${config.showSearch ? 'left-7' : 'left-1'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="space-y-0.5">
                  <p className="font-black text-slate-950 text-xs uppercase tracking-tight">Sticky Header</p>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Keep navigation visible while scrolling.</p>
                </div>
                <button 
                  onClick={() => onUpdateConfig({ ...config, stickyHeader: !config.stickyHeader })}
                  className={`w-12 h-6 rounded-full transition-all relative ${config.stickyHeader ? 'bg-slate-900 shadow-lg' : 'bg-slate-200'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${config.stickyHeader ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/5 text-primary rounded-lg border border-primary/10">
                <TrendingUp size={18} />
              </div>
              <h3 className="text-sm font-bold tracking-tight">Top Reordered Products</h3>
            </div>
            <p className="text-xs text-slate-500 font-medium">Manually select up to 2 products to feature at the top of the reordered section.</p>
            
            <div className="space-y-4">
              {[0, 1].map(idx => (
                <div key={idx} className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">Custom Product {idx + 1}</label>
                  <select 
                    value={(config.customTopReorderedIds || [])[idx] || ''}
                    onChange={(e) => {
                      const newIds = [...(config.customTopReorderedIds || ['', ''])];
                      newIds[idx] = e.target.value;
                      onUpdateConfig({ ...config, customTopReorderedIds: newIds });
                    }}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-500/10 text-xs font-bold"
                  >
                    <option value="">Select a product (Optional)</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Links */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
              <LinkIcon size={20} />
            </div>
            <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Footer Navigation</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Shop Links */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Shop & Collections</h4>
                <button 
                  onClick={() => {
                    const newLinks = [...(config.footerLinks?.shop || []), { label: 'New Link', link: '/' }];
                    onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, shop: newLinks } });
                  }}
                  className="btn-primary"
                >
                  Add Link
                </button>
              </div>
              <div className="space-y-3">
                {config.footerLinks?.shop?.map((link: any, idx: number) => (
                  <div key={`shop-${idx}`} className="flex gap-2 group">
                    <input 
                      type="text" 
                      value={link.label} 
                      onChange={(e) => {
                        const newLinks = [...(config.footerLinks?.shop || [])];
                        newLinks[idx].label = e.target.value;
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, shop: newLinks } });
                      }}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all" 
                      placeholder="Label"
                    />
                    <input 
                      type="text" 
                      value={link.link} 
                      onChange={(e) => {
                        const newLinks = [...(config.footerLinks?.shop || [])];
                        newLinks[idx].link = e.target.value;
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, shop: newLinks } });
                      }}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-500" 
                      placeholder="/link"
                    />
                    <button 
                      onClick={() => {
                        const newLinks = config.footerLinks?.shop?.filter((_: any, i: number) => i !== idx);
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, shop: newLinks } });
                      }}
                      className="p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Company Links */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Company & Legal</h4>
                <button 
                  onClick={() => {
                    const newLinks = [...(config.footerLinks?.company || []), { label: 'New Link', link: '/' }];
                    onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, company: newLinks } });
                  }}
                  className="btn-primary"
                >
                  Add Link
                </button>
              </div>
              <div className="space-y-3">
                {config.footerLinks?.company?.map((link: any, idx: number) => (
                  <div key={`company-${idx}`} className="flex gap-2 group">
                    <input 
                      type="text" 
                      value={link.label} 
                      onChange={(e) => {
                        const newLinks = [...(config.footerLinks?.company || [])];
                        newLinks[idx].label = e.target.value;
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, company: newLinks } });
                      }}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all" 
                      placeholder="Label"
                    />
                    <input 
                      type="text" 
                      value={link.link} 
                      onChange={(e) => {
                        const newLinks = [...(config.footerLinks?.company || [])];
                        newLinks[idx].link = e.target.value;
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, company: newLinks } });
                      }}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-500" 
                      placeholder="/link"
                    />
                    <button 
                      onClick={() => {
                        const newLinks = config.footerLinks?.company?.filter((_: any, i: number) => i !== idx);
                        onUpdateConfig({ ...config, footerLinks: { ...config.footerLinks, company: newLinks } });
                      }}
                      className="p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Social Presence */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
              <Share2 size={20} />
            </div>
            <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Social Channels</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { id: 'facebook', label: 'Facebook', icon: Facebook },
              { id: 'twitter', label: 'Twitter / X', icon: Twitter },
              { id: 'instagram', label: 'Instagram', icon: Instagram },
              { id: 'youtube', label: 'YouTube', icon: Youtube }
            ].map((social) => (
              <div key={social.id} className="space-y-1.5">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider px-1">{social.label}</label>
                <div className="relative group">
                  <social.icon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={14} />
                  <input 
                    type="text" 
                    value={config.socialLinks?.[social.id] || ''} 
                    onChange={(e) => {
                      onUpdateConfig({ 
                        ...config, 
                        socialLinks: { ...config.socialLinks, [social.id]: e.target.value } 
                      });
                    }}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-600" 
                    placeholder="https://..."
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
