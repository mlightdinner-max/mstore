import React from 'react';
import { LucideIcon } from 'lucide-react';
import { AdminSectionHeader } from './AdminSectionHeader';
import { motion, AnimatePresence } from 'motion/react';

interface AdminPageWrapperProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  actions?: React.ReactNode;
  toolbar?: React.ReactNode;
  children: React.ReactNode;
  isLoading?: boolean;
  isEmpty?: boolean;
  emptyState?: React.ReactNode;
  options?: { label: string; description: string }[];
}

export const AdminPageWrapper: React.FC<AdminPageWrapperProps> = ({
  title,
  description,
  icon,
  actions,
  toolbar,
  children,
  isLoading,
  isEmpty,
  emptyState,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5 pb-8 min-h-screen"
    >
      <AdminSectionHeader
        title={title}
        description={description}
        icon={icon}
      />

      {(actions || toolbar) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-1">
          {/* Toolbar (search, filters) — full width on mobile */}
          <div className="flex items-center gap-3 flex-1 w-full min-w-0">
            {toolbar}
          </div>
          {/* Actions (buttons) — right-aligned on desktop, full-width on mobile */}
          {actions && (
            <div className="flex items-center gap-2 sm:gap-3 shrink-0 flex-wrap sm:flex-nowrap">
              {actions}
            </div>
          )}
        </div>
      )}

      <div className="relative">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-24 space-y-4 bg-white rounded-2xl border border-slate-100 shadow-sm"
            >
              <div className="w-10 h-10 border-4 border-slate-200 border-t-slate-900 rounded-full animate-spin" />
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider animate-pulse">Loading…</p>
            </motion.div>
          ) : isEmpty ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm p-10 sm:p-20 text-center space-y-4"
            >
              {emptyState}
            </motion.div>
          ) : (
            <motion.div
              key="content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              {children}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};
