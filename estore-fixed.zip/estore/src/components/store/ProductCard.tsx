import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShoppingCart, Check, Plus, Minus, Trash2 } from 'lucide-react';
import { Product } from '../../types';
import { LOCALIZATION } from '../../constants';
import Button from '../common/Button';

interface ProductCardProps {
  key?: string | number;
  product: Product;
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  cartQuantity: number;
}

const ProductCard = ({ 
  product, 
  onAddToCart, 
  onUpdateQuantity, 
  onRemoveItem, 
  cartQuantity 
}: ProductCardProps) => {
  const isOutOfStock = product.isOutOfStock || product.stock === 0;
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    setIsAdding(true);
    onAddToCart(product);
    setTimeout(() => setIsAdding(false), 600);
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-xl hover:shadow-slate-900/5 transition-all duration-300 ${isOutOfStock ? 'opacity-75' : ''}`}
    >
      <Link to={`/product/${product.id}`} className="aspect-square overflow-hidden relative block group-hover:opacity-90 transition-opacity">
        {product.image ? (
          <img 
            src={product.image} 
            alt={product.name} 
            className={`w-full h-full object-cover transition-transform duration-700 ${!isOutOfStock ? 'group-hover:scale-110' : ''}`}
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = LOCALIZATION.FALLBACK_IMAGE;
            }}
          />
        ) : null}
        
        {isOutOfStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center z-10">
            <span className="bg-white text-slate-900 px-5 py-2.5 rounded-xl text-xs font-medium uppercase tracking-wider shadow-2xl transform -rotate-6 border-2 border-slate-900">
              Out of Stock
            </span>
          </div>
        )}

        {cartQuantity > 0 && !isOutOfStock && (
          <div className="absolute top-2.5 left-2.5">
            <motion.span 
              initial={{ scale: 0, rotate: -10 }}
              animate={{ scale: 1, rotate: 0 }}
              className="bg-primary text-white px-2.5 py-1 rounded-lg text-xs font-black shadow-xl flex items-center space-x-1.5 border border-white/20"
            >
              <Check size={10} strokeWidth={3} />
              <span className="tracking-widest uppercase">{cartQuantity} IN CART</span>
            </motion.span>
          </div>
        )}
      </Link>
      <div className="p-4">
        <div className="flex justify-between items-start mb-1.5 gap-2">
          <Link to={`/product/${product.id}`} className="flex-1 min-w-0">
            <h3 className="premium-heading text-[12px] group-hover:text-primary transition-colors line-clamp-1 not-italic">
              {product.name}
            </h3>
          </Link>
          <div className="flex flex-col items-end">
            {(product.mrp ?? 0) > 0 && (product.mrp ?? 0) > product.price && (
              <span className="text-slate-400 font-bold text-xs line-through whitespace-nowrap leading-none mb-0.5">
                {LOCALIZATION.CURRENCY}{(product.mrp ?? 0).toLocaleString()}
              </span>
            )}
            <span className="text-primary font-bold text-xs whitespace-nowrap leading-none">
              {LOCALIZATION.CURRENCY}{product.price.toLocaleString()}
            </span>
          </div>
        </div>
        
        <p className="text-xs text-slate-500 line-clamp-2 mb-3 min-h-[2.5rem] font-medium leading-relaxed">
          {product.description}
        </p>

        {cartQuantity > 0 ? (
          <div className="flex items-center space-x-1.5">
            <button 
              onClick={() => cartQuantity === 1 ? onRemoveItem(product.id) : onUpdateQuantity(product.id, -1)}
              aria-label={cartQuantity === 1 ? `Remove ${product.name} from cart` : `Decrease quantity of ${product.name}`}
              className="flex-1 py-2 flex items-center justify-center bg-slate-100 text-slate-600 rounded-xl hover:bg-red-50 hover:text-red-600 transition-all border border-slate-200"
            >
              {cartQuantity === 1 ? <Trash2 size={14} /> : <Minus size={14} />}
            </button>
            <div className="flex-[0.5] text-center font-bold text-slate-900 text-xs">
              {cartQuantity}
            </div>
            <button 
              onClick={() => onUpdateQuantity(product.id, 1)}
              disabled={isOutOfStock}
              aria-label={`Increase quantity of ${product.name}`}
              className={`flex-1 py-2 flex items-center justify-center rounded-xl transition-all shadow-lg ${isOutOfStock ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-primary text-white hover:bg-primary-dark shadow-primary/20'}`}
            >
              <Plus size={14} />
            </button>
          </div>
        ) : (
          <Button
            onClick={handleAddToCart}
            isLoading={isAdding}
            variant="dark"
            className="w-full"
            disabled={isOutOfStock}
            leftIcon={isAdding ? undefined : <ShoppingCart size={12} />}
          >
            {isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
          </Button>
        )}
      </div>
    </motion.div>
  );
};

export default ProductCard;
