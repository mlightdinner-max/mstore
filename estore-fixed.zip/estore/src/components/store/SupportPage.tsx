import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, CheckCircle2, Mail, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react';

interface SupportPageProps {
  config: any;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

const SupportPage = ({ config, onShowNotification }: SupportPageProps) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  const faqs = config.faqs || [];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate that either email or phone is provided
    if (!formData.email && !formData.phone) {
      onShowNotification('Either an email address or a phone number is mandatory.', 'error');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const response = await fetch('/api/v1/support/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerName: formData.name,
          email: formData.email || formData.phone, // using phone as fallback for identifying field
          subject: formData.subject,
          message: formData.message
        })
      });

      if (response.ok) {
        onShowNotification('Message sent successfully! We will get back to you soon.', 'success');
        setIsSuccess(true);
        setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
      } else {
        const error = await response.json();
        onShowNotification(error.error || 'Failed to send message. Please try again.', 'error');
      }
    } catch {
      onShowNotification('Network error. Please check your connection.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row gap-20">
          {/* Contact Info */}
          <div className="lg:w-1/3 space-y-12">
            <div className="space-y-4">
              <h1 className="text-3xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
                {config.supportHeading?.split(' ').map((word: string, i: number) => (
                  i === config.supportHeading?.split(' ').length - 1 
                  ? <span key={i} className="text-primary">{word} </span> 
                  : word + ' '
                )) || <>{'Get in '}<span className="text-primary">Touch</span></>}
              </h1>
              <p className="text-slate-500 font-medium text-base leading-relaxed">
                {config.supportSubheading}
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start space-x-4 group">
                <div className="w-12 h-12 bg-primary/5 text-primary rounded-2xl flex items-center justify-center border border-primary/10 group-hover:bg-primary group-hover:text-white transition-all">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-900 uppercase tracking-wider mb-1">Email Support</p>
                  <p className="text-slate-500 font-medium text-sm">{config.supportEmail || config.contactEmail}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="flex-1">
            <div className="bg-white rounded-[3rem] p-8 md:p-12 shadow-2xl shadow-slate-900/5 border border-slate-200/60 relative overflow-hidden">
              <AnimatePresence mode="wait">
                {isSuccess ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-20 space-y-8"
                  >
                    <div className="w-24 h-24 bg-primary/5 text-primary rounded-[2.5rem] flex items-center justify-center mx-auto border border-primary/10 shadow-sm">
                      <CheckCircle2 size={48} />
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-3xl font-black text-slate-900 uppercase italic tracking-tighter">Message Received</h2>
                      <p className="text-slate-500 font-medium text-sm max-w-xs mx-auto">Our support team will get back to you via email within 24 hours.</p>
                    </div>
                    <button 
                      onClick={() => setIsSuccess(false)}
                      className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all"
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                ) : (
                  <motion.form 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onSubmit={handleSubmit} 
                    className="space-y-8"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="p-2.5 bg-primary/5 text-primary rounded-xl">
                        <MessageSquare size={20} />
                      </div>
                      <div>
                        <h2 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">Help Center</h2>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Email or Phone is mandatory for a response</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Full Name</label>
                        <input
                          required
                          type="text"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                          placeholder="Your full name"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Email Address</label>
                          <input
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                            placeholder="email@example.com"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Phone Number</label>
                          <input
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                            placeholder="+91 00000 00000"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">How can we help?</label>
                        <input
                          required
                          type="text"
                          value={formData.subject}
                          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                          className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                          placeholder="Subject of your inquiry"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Detailed Message</label>
                        <textarea
                          required
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          rows={6}
                          className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all resize-none"
                          placeholder="Please provide as much detail as possible so we can help you efficiently..."
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black disabled:opacity-50 transition-all flex items-center justify-center space-x-3 shadow-xl shadow-slate-900/10"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Sending Inquiry...</span>
                        </>
                      ) : (
                        <>
                          <span>Send Inquiry</span>
                          <Send size={14} />
                        </>
                      )}
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* FAQs Section */}
          {faqs.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-3xl mx-auto space-y-12"
            >
              <div className="text-center space-y-4">
                <h2 className="text-3xl md:text-4xl font-black text-slate-900 uppercase tracking-tighter">Frequently Asked Questions</h2>
                <p className="text-xs md:text-xs text-slate-400 font-black uppercase tracking-[0.2em]">Quick answers to common questions about our service.</p>
              </div>

              <div className="space-y-4">
                {faqs.map((faq: any) => (
                  <div 
                    key={faq.id}
                    className="bg-white rounded-[2rem] border border-slate-100 overflow-hidden transition-all hover:border-slate-200 shadow-sm"
                  >
                    <button 
                      onClick={() => setOpenFaq(openFaq === faq.id ? null : faq.id)}
                      className="w-full px-8 py-6 flex items-center justify-between text-left group"
                    >
                      <span className="text-xs md:text-sm font-black text-slate-900 uppercase tracking-tight group-hover:text-primary transition-colors">
                        {faq.question}
                      </span>
                      <div className={`p-2 rounded-xl transition-all ${openFaq === faq.id ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-400'}`}>
                        {openFaq === faq.id ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </div>
                    </button>
                    
                    <AnimatePresence>
                      {openFaq === faq.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3, ease: 'easeInOut' }}
                        >
                          <div className="px-8 pb-8 pt-0">
                            <div className="h-px w-full bg-slate-50 mb-6" />
                            <p className="text-xs md:text-sm text-slate-500 leading-relaxed font-medium">
                              {faq.answer}
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SupportPage;
