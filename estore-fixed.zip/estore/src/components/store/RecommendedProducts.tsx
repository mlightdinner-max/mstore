import React, { useState, useEffect } from 'react';
import { Product, CartItem } from '../../types';
import { aiService } from '../../services/aiService';
import ProductCard from './ProductCard';

interface RecommendedProductsProps {
  products: Product[];
  config: any;
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  cart: CartItem[];
  token: string | null;
}

const RecommendedProducts = ({ products, config, onAddToCart, onUpdateQuantity, onRemoveItem, cart, token }: RecommendedProductsProps) => {
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const getRecommendations = async () => {
      // Get browser history
      const historyIds = JSON.parse(localStorage.getItem('browsing_history') || '[]');
      const recentProducts = products.filter(p => historyIds.includes(p.id));

      const isAiEnabled = config.aiSettings?.enabled && config.aiSettings?.useRecommendations;
      const hasKey = !!config.geminiApiKey;

      if (!isAiEnabled || !hasKey || products.length === 0) {
        // Fallback: Show browsing history first, then others
        setRecommendations([...recentProducts, ...products.filter(p => !historyIds.includes(p.id))].slice(0, 3));
        return;
      }
      
      setLoading(true);
      try {
        const historyNames = recentProducts.map(p => p.name);
        const recommendedNames = await aiService.getRecommendations(products, historyNames);

        if (recommendedNames && recommendedNames.length > 0) {
          const recommended = products.filter(p => recommendedNames.includes(p.name));
          // Mix AI recommendations with browsing history if not enough
          const combined = [...new Set([...recommended, ...recentProducts])].slice(0, 3);
          setRecommendations(combined.length > 0 ? combined : products.slice(0, 3));
        } else {
          setRecommendations([...recentProducts, ...products.filter(p => !historyIds.includes(p.id))].slice(0, 3));
        }
      } catch (error) {
        console.error("Recommendation Error:", error);
        setRecommendations([...recentProducts, ...products.filter(p => !historyIds.includes(p.id))].slice(0, 3));
      } finally {
        setLoading(false);
      }
    };

    getRecommendations();
  }, [products, config.aiSettings, config.geminiApiKey, token]);

  const getCartQuantity = (id: string) => cart.find(item => item.id === id)?.quantity || 0;

  if (loading) return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-6">
      {[1, 2, 3].map(i => (
        <div key={i} className="aspect-square bg-slate-100 animate-pulse rounded-xl" />
      ))}
    </div>
  );

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-6">
      {recommendations.map((product, idx) => (
        <ProductCard key={`recommended-${product.id}-${idx}`} product={product} onAddToCart={onAddToCart} onUpdateQuantity={onUpdateQuantity} onRemoveItem={onRemoveItem} cartQuantity={getCartQuantity(product.id)} />
      ))}
    </div>
  );
};

export default RecommendedProducts;
