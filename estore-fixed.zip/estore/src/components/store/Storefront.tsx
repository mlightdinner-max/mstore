import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, ShoppingBag, ShoppingCart, Star, Heart, ArrowRight, 
  Menu, X, Filter, 
  ChevronDown, Sparkles, LayoutGrid, List, 
  ShieldCheck, Eye, Trash
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product, CartItem } from '../../types';
import { LOCALIZATION } from '../../constants';
import StoreFooter from './StoreFooter';

interface StorefrontProps {
  products: Product[];
  cart: CartItem[];
  onAddToCart: (p: Product) => void;
  onRemoveFromCart: (id: string) => void;
  onUpdateCartQuantity: (id: string, q: number) => void;
  onCheckout: (formData: any) => void;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  user: any;
  onLogout: () => void;
  onShowAdmin: () => void;
  config: any;
}

const Storefront = ({
  products,
  cart,
  onAddToCart,
  onRemoveFromCart,
  onUpdateCartQuantity,
  onCheckout: _onCheckout,
  user,
  onShowAdmin,
  config
}: StorefrontProps) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const categories = useMemo(() => {
    const cats = new Set(products.map(p => p.category));
    return ['All', ...Array.from(cats)];
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const isVisible = p.status === 'active' || (p.status !== 'deactivated' && p.isActive !== false);
      return matchesCategory && matchesSearch && isVisible;
    });
  }, [products, activeCategory, searchQuery]);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <div className="min-h-screen bg-white selection:bg-slate-900 selection:text-white">
      {/* Navigation Header */}
      <header className="h-24 bg-white/80 backdrop-blur-xl border-b border-slate-100 sticky top-0 z-40 px-6 lg:px-12 flex items-center justify-between">
        <div className="flex items-center gap-12">
          <div className="flex items-center gap-3 group cursor-pointer">
            <div className="w-12 h-12 bg-slate-950 text-white rounded-2xl flex items-center justify-center shadow-2xl shadow-slate-950/20 group-hover:scale-105 transition-transform">
              <ShoppingBag size={24} />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter leading-none">{config.storeName}</h1>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">{config.storeTagline || 'Curated Excellence'}</p>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-8">
            <Link to="/" className="text-xs font-medium text-slate-400 uppercase tracking-wider hover:text-slate-950 transition-colors">Shop</Link>
            <Link to="/contact" className="text-xs font-medium text-slate-400 uppercase tracking-wider hover:text-slate-950 transition-colors">Support</Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 group focus-within:bg-white focus-within:ring-4 focus-within:ring-slate-900/5 transition-all">
            <Search size={16} className="text-slate-400 group-focus-within:text-slate-950 transition-colors" />
            <input 
              type="text" 
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border-none outline-none ml-3 text-xs font-bold text-slate-900 placeholder:text-slate-400 w-48"
            />
          </div>

          <div className="flex items-center gap-2">
            {user && (user.role === 'Admin' || user.role === 'Super Admin') && (
              <button 
                onClick={onShowAdmin}
                className="p-3 bg-slate-950 text-white rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-950/20"
              >
                <ShieldCheck size={20} />
              </button>
            )}
            <button 
              onClick={() => setIsCartOpen(true)}
              className="p-3 bg-white border border-slate-200 text-slate-950 rounded-2xl hover:bg-slate-50 transition-all shadow-sm relative group"
            >
              <ShoppingCart size={20} className="group-hover:scale-110 transition-transform" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-slate-950 text-white text-xs font-black rounded-full flex items-center justify-center border-2 border-white shadow-lg">
                  {cart.reduce((sum, i) => sum + i.quantity, 0)}
                </span>
              )}
            </button>
            <button className="p-3 bg-white border border-slate-200 text-slate-950 rounded-2xl hover:bg-slate-50 transition-all shadow-sm lg:hidden">
              <Menu size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[70vh] bg-slate-950 overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://picsum.photos/seed/luxury/1920/1080?blur=4" 
            alt="Hero Background" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
        
        <div className="relative h-full container mx-auto px-6 flex flex-col justify-center items-center text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-xs font-black text-white uppercase tracking-[0.2em]">
              <Sparkles size={14} className="text-amber-400" />
              Spring Collection 2026
            </div>
            <h2 className="text-6xl md:text-8xl font-black text-white uppercase italic tracking-tighter leading-[0.9]">
              Redefining<br />Modern Luxury
            </h2>
            <p className="text-slate-400 text-lg font-medium max-w-2xl mx-auto">
              Experience the perfect blend of craftsmanship and contemporary design. Our new collection is here to elevate your lifestyle.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-4"
          >
            <button className="px-10 py-5 bg-white text-slate-950 rounded-2xl font-black text-[12px] uppercase tracking-widest hover:bg-slate-100 transition-all shadow-2xl shadow-white/10 flex items-center gap-3 group">
              Shop Collection
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-10 py-5 bg-transparent border border-white/20 text-white rounded-2xl font-black text-[12px] uppercase tracking-widest hover:bg-white/5 transition-all">
              View Lookbook
            </button>
          </motion.div>
        </div>
      </section>

      {/* Main Store Content */}
      <main className="container mx-auto px-6 py-24 space-y-16">
        {/* Category Navigation */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="flex flex-wrap gap-3">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-3 rounded-2xl text-xs font-medium uppercase tracking-wider transition-all border ${
                  activeCategory === cat 
                    ? 'bg-slate-950 text-white border-slate-950 shadow-xl shadow-slate-950/20' 
                    : 'bg-white text-slate-400 border-slate-100 hover:border-slate-200 hover:text-slate-950'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <div className="flex bg-slate-50 border border-slate-200 rounded-2xl p-1">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <LayoutGrid size={18} />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-xl transition-all ${viewMode === 'list' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <List size={18} />
              </button>
            </div>
            <button className="px-5 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-950 flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
              <Filter size={14} />
              Sort By
              <ChevronDown size={14} />
            </button>
          </div>
        </div>

        {/* Product Grid */}
        <div className={`grid gap-8 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`group bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden hover:shadow-2xl hover:shadow-slate-950/5 transition-all duration-500 ${
                  viewMode === 'list' ? 'flex flex-col md:flex-row' : ''
                }`}
              >
                <div className={`relative overflow-hidden ${viewMode === 'list' ? 'md:w-72 flex-shrink-0' : 'aspect-[4/5]'}`}>
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  <div className="absolute top-4 right-4 flex flex-col gap-2 translate-x-12 group-hover:translate-x-0 transition-transform duration-500">
                    <button className="p-3 bg-white text-slate-950 rounded-2xl shadow-xl hover:bg-slate-950 hover:text-white transition-all">
                      <Heart size={18} />
                    </button>
                    <button className="p-3 bg-white text-slate-950 rounded-2xl shadow-xl hover:bg-slate-950 hover:text-white transition-all">
                      <Eye size={18} />
                    </button>
                  </div>

                  <div className="absolute bottom-4 left-4 right-4 translate-y-12 group-hover:translate-y-0 transition-transform duration-500">
                    <button 
                      onClick={() => onAddToCart(product)}
                      className="w-full py-4 bg-white text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 hover:bg-slate-950 hover:text-white transition-all"
                    >
                      <ShoppingCart size={16} />
                      Add to Cart
                    </button>
                  </div>
                </div>

                <div className="p-8 space-y-4 flex-1">
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{product.category}</p>
                    <h3 className="text-lg font-black text-slate-950 uppercase italic tracking-tighter leading-none group-hover:text-slate-600 transition-colors">{product.name}</h3>
                  </div>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed line-clamp-2">{product.description}</p>
                  <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                    <div className="flex items-baseline gap-2">
                      <p className="text-xl font-black text-slate-950 tracking-tighter">{LOCALIZATION.CURRENCY}{product.price.toLocaleString()}</p>
                      {product.mrp > 0 && product.mrp > product.price && (
                        <p className="text-xs text-slate-400 font-bold line-through">{LOCALIZATION.CURRENCY}{product.mrp.toLocaleString()}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-amber-400">
                      <Star size={14} fill="currentColor" />
                      <span className="text-xs font-black text-slate-950">{product.rating}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredProducts.length === 0 && (
          <div className="py-32 text-center space-y-4">
            <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center mx-auto text-slate-200">
              <ShoppingBag size={40} />
            </div>
            <div className="space-y-1">
              <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">No products found</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your search or filters</p>
            </div>
          </div>
        )}
      </main>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-[100] flex justify-end">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-slate-950 text-white rounded-xl">
                    <ShoppingCart size={20} />
                  </div>
                  <h2 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Your Cart</h2>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40">
                    <ShoppingBag size={64} />
                    <p className="text-xs font-medium uppercase tracking-wider">Your cart is empty</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div key={item.id} className="flex gap-4 group">
                      <div className="w-24 h-24 bg-slate-100 rounded-2xl overflow-hidden border border-slate-100 flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-start">
                          <h3 className="text-xs font-black text-slate-950 uppercase tracking-tight line-clamp-1">{item.name}</h3>
                          <button 
                            onClick={() => onRemoveFromCart(item.id)}
                            className="text-slate-300 hover:text-rose-500 transition-colors"
                          >
                            <Trash size={14} />
                          </button>
                        </div>
                        <p className="text-sm font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{item.price.toLocaleString()}</p>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-1">
                            <button 
                              onClick={() => onUpdateCartQuantity(item.id, Math.max(1, item.quantity - 1))}
                              className="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-slate-950 transition-colors"
                            >
                              -
                            </button>
                            <span className="w-8 text-center text-xs font-black">{item.quantity}</span>
                            <button 
                              onClick={() => onUpdateCartQuantity(item.id, item.quantity + 1)}
                              className="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-slate-950 transition-colors"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-8 border-t border-slate-100 bg-slate-50/50 space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-medium text-slate-400 uppercase tracking-wider">
                      <span>Subtotal</span>
                      <span>{LOCALIZATION.CURRENCY}{cartTotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-xs font-medium text-slate-400 uppercase tracking-wider">
                      <span>Shipping</span>
                      <span className="text-primary/80">Free</span>
                    </div>
                    <div className="pt-4 border-t border-slate-200 flex justify-between items-end">
                      <p className="text-xs font-medium uppercase tracking-wider">Total Amount</p>
                      <p className="text-2xl font-black text-slate-950 tracking-tighter">{LOCALIZATION.CURRENCY}{cartTotal.toLocaleString()}</p>
                    </div>
                  </div>
                  <Link 
                    to="/checkout"
                    className="w-full py-5 bg-slate-950 text-white rounded-2xl font-black text-[12px] uppercase tracking-widest hover:bg-slate-800 transition-all shadow-2xl shadow-slate-950/20 active:scale-95 flex items-center justify-center gap-3"
                  >
                    Checkout Now
                    <ArrowRight size={18} />
                  </Link>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <StoreFooter config={config} />
    </div>
  );
};

export default Storefront;

