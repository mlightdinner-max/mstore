import React from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingCart, Minus, Plus, Trash2, ArrowRight } from 'lucide-react';
import { LOCALIZATION } from '../../constants';
import { CartItem } from '../../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number, variants?: Record<string, string>) => void;
  onRemoveItem: (id: string, variants?: Record<string, string>) => void;
}

const CartDrawer = ({ isOpen, onClose, cart, onUpdateQuantity, onRemoveItem }: CartDrawerProps) => {
  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[150]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-full sm:max-w-md bg-white shadow-2xl z-[160] flex flex-col"
          >
            <div className="p-5 sm:p-8 flex items-center justify-between border-b border-slate-100">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-primary/5 text-primary rounded-xl">
                  <ShoppingCart size={20} />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">Your Cart</h2>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{cart.length} items</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                aria-label="Close cart"
                className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-900 transition-all"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6 sm:space-y-8 custom-scrollbar">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                  <div className="w-20 h-20 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-200 border border-slate-100">
                    <ShoppingCart size={40} />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-black text-slate-900 uppercase tracking-widest">Your cart is empty</p>
                    <p className="text-xs text-slate-500 font-bold uppercase tracking-widest leading-relaxed">Start adding some premium items to your collection.</p>
                  </div>
                  <button 
                    onClick={onClose}
                    className="px-8 py-3.5 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                cart.map((item, idx) => (
                  <motion.div 
                    key={`cart-item-${item.id}-${idx}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center space-x-6 group"
                  >
                    <div className="w-24 h-24 rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 flex-shrink-0 relative">
                      <img 
                        src={item.image || 'https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=2029&auto=format&fit=crop'} 
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="space-y-1">
                        <p className="text-xs font-black text-slate-900 uppercase tracking-tight truncate">{item.name}</p>
                        {item.selectedVariants && Object.entries(item.selectedVariants).length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                             {Object.entries(item.selectedVariants).map(([name, val]) => (
                                <span key={name} className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-xs font-medium uppercase tracking-wider rounded">
                                   {name}: {val}
                                </span>
                             ))}
                          </div>
                        )}
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs text-slate-900 font-bold tracking-widest">{LOCALIZATION.CURRENCY}{item.price.toLocaleString()}</p>
                          {item.mrp && item.mrp > 0 && (
                             <p className="text-xs text-slate-400 font-bold line-through">{LOCALIZATION.CURRENCY}{item.mrp.toLocaleString()}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center bg-slate-50 rounded-xl p-0.5 border border-slate-100">
                          <button 
                            onClick={() => item.quantity === 1 ? onRemoveItem(item.id, item.selectedVariants) : onUpdateQuantity(item.id, -1, item.selectedVariants)}
                            aria-label={item.quantity === 1 ? `Remove ${item.name} from cart` : `Decrease quantity of ${item.name}`}
                            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-900 transition-colors"
                          >
                            {item.quantity === 1 ? <Trash2 size={14} className="text-rose-500" /> : <Minus size={14} />}
                          </button>
                          <span className="w-8 text-center font-black text-slate-900 text-xs">{item.quantity}</span>
                          <button 
                            onClick={() => onUpdateQuantity(item.id, 1, item.selectedVariants)}
                            aria-label={`Increase quantity of ${item.name}`}
                            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-900 transition-colors"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        <p className="text-xs font-black text-slate-900">{LOCALIZATION.CURRENCY}{(item.price * item.quantity).toLocaleString()}</p>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-5 sm:p-8 bg-slate-50 border-t border-slate-200 space-y-6">
                <div className="flex justify-between items-end">
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Subtotal</p>
                    <p className="text-2xl font-black text-slate-900 tracking-tighter leading-none">{LOCALIZATION.CURRENCY}{subtotal.toLocaleString()}</p>
                  </div>
                  <p className="text-xs text-emerald-600 font-medium uppercase tracking-wider">Free Delivery Nationwide</p>
                </div>
                <Link 
                  to="/checkout"
                  onClick={onClose}
                  className="w-full py-5 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-primary/80 transition-all flex items-center justify-center space-x-3 shadow-xl shadow-primary/20 group"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;
