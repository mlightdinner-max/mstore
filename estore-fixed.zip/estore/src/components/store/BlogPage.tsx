import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar, User, Tag, ChevronRight } from 'lucide-react';

interface BlogPageProps {
  config: any;
}

const BlogPage = ({ config }: BlogPageProps) => {
  const posts = (config.blogPosts || []).filter((p: any) => p.status === 'published');
  const [selectedPost, setSelectedPost] = useState<any>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (selectedPost) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20">
        <button 
          onClick={() => setSelectedPost(null)}
          className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors mb-12 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-medium uppercase tracking-wider">Back to Blog</span>
        </button>

        <article className="space-y-12">
          <div className="space-y-6 text-center">
            <div className="flex items-center justify-center space-x-4">
              <span className="px-3 py-1 bg-primary/5 text-primary text-xs font-medium uppercase tracking-wider rounded-full border border-primary/10">
                {selectedPost.category}
              </span>
              <div className="flex items-center space-x-2 text-slate-400">
                <Calendar size={12} />
                <span className="text-xs font-medium uppercase tracking-wider">{selectedPost.date}</span>
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
              {selectedPost.title}
            </h1>
            <div className="flex items-center justify-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center border border-slate-200">
                <User size={16} className="text-slate-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-black text-slate-900 uppercase tracking-tight">{selectedPost.author}</p>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Author</p>
              </div>
            </div>
          </div>

          <div className="aspect-video rounded-[2.5rem] overflow-hidden bg-slate-100 border border-slate-200 shadow-2xl shadow-slate-950/5">
            {selectedPost.image ? (
              <img 
                src={selectedPost.image} 
                alt={selectedPost.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : null}
          </div>

          <div className="prose prose-slate max-w-none">
            <div className="text-slate-600 font-medium text-lg leading-relaxed whitespace-pre-wrap">
              {selectedPost.content}
            </div>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <h1 className="text-3xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
            The <span className="text-primary">Journal</span>
          </h1>
          <p className="text-slate-500 font-medium text-base">Stories, insights, and updates from our premium collection.</p>
        </div>

        {posts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post: any, idx: number) => (
              <motion.button
                key={`blog-post-${post.id}-${idx}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                onClick={() => setSelectedPost(post)}
                aria-label={`Read article: ${post.title}`}
                className="group cursor-pointer space-y-6 text-left w-full"
              >
                <div className="aspect-[4/3] rounded-[2rem] overflow-hidden bg-slate-100 border border-slate-200 shadow-lg shadow-slate-950/5 relative">
                  {post.image ? (
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                  ) : null}
                  <div className="absolute top-6 left-6">
                    <span className="px-3 py-1 bg-white/90 backdrop-blur-md text-slate-900 text-xs font-medium uppercase tracking-wider rounded-full shadow-sm">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="space-y-3 px-2">
                  <div className="flex items-center space-x-3 text-slate-400">
                    <div className="flex items-center space-x-1">
                      <Calendar size={12} />
                      <span className="text-xs font-medium uppercase tracking-wider">{post.date}</span>
                    </div>
                    <div className="w-1 h-1 rounded-full bg-slate-200" />
                    <div className="flex items-center space-x-1">
                      <User size={12} />
                      <span className="text-xs font-medium uppercase tracking-wider">{post.author}</span>
                    </div>
                  </div>
                  <h2 className="text-2xl font-black text-slate-950 tracking-tighter uppercase italic leading-tight group-hover:text-primary transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-slate-500 text-sm font-medium line-clamp-2 leading-relaxed">
                    {post.content}
                  </p>
                  <div className="pt-2 flex items-center space-x-2 text-slate-900 font-black text-xs uppercase tracking-widest group-hover:translate-x-2 transition-transform">
                    <span>Read Article</span>
                    <ChevronRight size={14} className="text-primary/80" />
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        ) : (
          <div className="py-40 text-center bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
            <div className="w-20 h-20 bg-white rounded-[2rem] flex items-center justify-center mx-auto mb-6 text-slate-300 shadow-sm border border-slate-100">
              <Tag size={40} />
            </div>
            <h3 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter">No stories yet</h3>
            <p className="text-slate-500 font-medium text-sm mt-2">Check back soon for fresh updates and insights.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogPage;
