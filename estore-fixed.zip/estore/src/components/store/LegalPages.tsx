import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, FileText, RotateCcw } from 'lucide-react';

interface LegalPageProps {
  config: any;
}

export const ReturnsPolicyPage = ({ config }: LegalPageProps) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="max-w-4xl mx-auto px-6">
        <Link 
          to="/"
          className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors mb-12 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-medium uppercase tracking-wider">Back to Home</span>
        </Link>

        <div className="space-y-12">
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center mx-auto border border-primary/10 shadow-sm">
              <RotateCcw size={32} />
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
              Returns <span className="text-primary">& Refund</span>
            </h1>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-slate max-w-none">
            <div className="text-slate-600 font-medium text-lg leading-relaxed whitespace-pre-wrap">
              {config.returnsPolicy || "Our returns and refund policy is being updated. Please check back soon."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const PrivacyPolicyPage = ({ config }: LegalPageProps) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="max-w-4xl mx-auto px-6">
        <Link 
          to="/"
          className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors mb-12 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-medium uppercase tracking-wider">Back to Home</span>
        </Link>

        <div className="space-y-12">
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center mx-auto border border-primary/10 shadow-sm">
              <Shield size={32} />
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
              Privacy <span className="text-primary">Policy</span>
            </h1>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-slate max-w-none">
            <div className="text-slate-600 font-medium text-lg leading-relaxed whitespace-pre-wrap">
              {config.privacyPolicy || "Our privacy policy is being updated. Please check back soon."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const TermsOfServicePage = ({ config }: LegalPageProps) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="max-w-4xl mx-auto px-6">
        <Link 
          to="/"
          className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors mb-12 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-medium uppercase tracking-wider">Back to Home</span>
        </Link>

        <div className="space-y-12">
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center mx-auto border border-primary/10 shadow-sm">
              <FileText size={32} />
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
              Terms of <span className="text-primary">Service</span>
            </h1>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-slate max-w-none">
            <div className="text-slate-600 font-medium text-lg leading-relaxed whitespace-pre-wrap">
              {config.termsOfService || "Our terms of service are being updated. Please check back soon."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
