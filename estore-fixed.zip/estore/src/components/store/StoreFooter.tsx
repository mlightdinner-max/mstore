import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube, 
  Package, 
  Mail, 
  ShieldCheck,
  Truck,
  RotateCcw
} from 'lucide-react';

interface StoreFooterProps {
  config: any;
}

const StoreFooter = ({ config }: StoreFooterProps) => {
  const storeName = config.storeName || '';
  
  const defaultFooterLinks = [
    { label: 'Shop All', link: '/products' },
    { label: 'Tracking', link: '/tracking' },
    { label: 'About Us', link: '/about' },
    { label: 'Help Desk', link: '/contact' },
    { label: 'Blog', link: '/blog' }
  ];

  const footerLinks = Array.isArray(config.footerLinks) && config.footerLinks.length > 0
    ? config.footerLinks
    : defaultFooterLinks;

  const rawSocialLinks = config.socialLinks || {};
  const socialLinks = Array.isArray(rawSocialLinks) 
    ? rawSocialLinks 
    : Object.entries(rawSocialLinks).map(([platform, url]) => ({
        platform: platform.charAt(0).toUpperCase() + platform.slice(1),
        url: String(url)
      })).filter(s => s.url);

  const supportLinks = [
    { label: 'Track Order', link: '/tracking', icon: Truck },
    { label: 'Help Center', link: '/contact', icon: Mail },
    { label: 'Returns & Refund Policy', link: '/returns', icon: RotateCcw }
  ];

  const legalLinks = [
    { label: 'Privacy Policy', link: '/privacy', icon: ShieldCheck },
    { label: 'Terms of Service', link: '/terms', icon: Package }
  ];

  return (
    <footer className="bg-slate-950 text-white pt-16 pb-12 border-t border-white/5 relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-16 mb-8 lg:mb-12">
          <div className="lg:col-span-4 space-y-8">
            <Link to="/" className="premium-heading text-3xl flex items-center space-x-3 group">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center group-hover:bg-primary transition-all duration-700 shadow-2xl shadow-primary/20 rotate-0 group-hover:rotate-12">
                {config.logoUrl ? (
                  <img src={config.logoUrl} alt="Logo" className="h-7 w-auto object-contain" referrerPolicy="no-referrer" />
                ) : (
                  <Package size={24} className="text-slate-950 group-hover:text-white transition-colors" />
                )}
              </div>
              <span className="group-hover:text-primary transition-colors italic">{storeName}</span>
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm font-medium">
              {config.storeDescription || `Your trusted online shop for quality products. We curate the finest selection for you.`}
            </p>
            <div className="flex items-center space-x-4">
              {socialLinks.map((social: any, idx: number) => {
                const Icon = social.platform === 'Instagram' ? Instagram : 
                             social.platform === 'Facebook' ? Facebook : 
                             social.platform === 'Twitter' ? Twitter : Youtube;
                return (
                  <a 
                    key={idx}
                    href={social.url} 
                    target="_blank" 
                    rel="noreferrer"
                    className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 hover:bg-primary hover:border-primary transition-all duration-500 hover:-translate-y-1"
                  >
                    <Icon size={18} />
                  </a>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-[0.3em] text-primary/80">Navigation</h4>
              <ul className="space-y-4">
                {footerLinks.map((link: any, idx: number) => (
                  <li key={idx}>
                    <Link 
                      to={link.link} 
                      className="text-sm font-bold text-slate-400 hover:text-white transition-colors flex items-center space-x-2 group w-fit"
                    >
                      <span className="w-1 h-1 bg-primary/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                      <span>{link.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-[0.3em] text-primary/80">Support</h4>
              <ul className="space-y-4">
                {supportLinks.map((link, idx) => (
                  <li key={idx}>
                    <Link to={link.link} className="text-sm font-bold text-slate-400 hover:text-white transition-colors flex items-center space-x-2">
                      <link.icon size={14} className="text-slate-600" />
                      <span>{link.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-span-2 md:col-span-1 space-y-6">
              <h4 className="text-xs font-black uppercase tracking-[0.3em] text-primary/80">Legal</h4>
              <ul className="space-y-4">
                {legalLinks.map((link, idx) => (
                  <li key={idx}>
                    <Link to={link.link} className="text-sm font-bold text-slate-400 hover:text-white transition-colors flex items-center space-x-2">
                      <link.icon size={14} className="text-slate-600" />
                      <span>{link.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-8 lg:pt-12 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 md:gap-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <p className="text-xs font-medium uppercase tracking-wider text-slate-500">
              © {new Date().getFullYear()} <span className="text-white">{storeName}</span>. All Rights Reserved.
            </p>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 opacity-60 hover:opacity-100 transition-opacity group">
              <Truck size={14} className="text-primary group-hover:scale-110 transition-transform" />
              <span className="text-xs font-medium uppercase tracking-wider text-white">Cash on Delivery Available</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default StoreFooter;
