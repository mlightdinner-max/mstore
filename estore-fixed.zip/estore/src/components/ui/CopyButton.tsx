import React, { useState } from 'react';
import { ClipboardCheck, Copy } from 'lucide-react';

interface CopyButtonProps {
  text: string;
  label: string;
}

const CopyButton = ({ text, label }: CopyButtonProps) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button 
      onClick={handleCopy}
      className="flex items-center space-x-1 text-xs font-medium text-primary hover:text-primary-dark transition-colors"
    >
      {copied ? <ClipboardCheck size={14} /> : <Copy size={14} />}
      <span>{copied ? 'Copied!' : `Copy ${label}`}</span>
    </button>
  );
};

export default CopyButton;
