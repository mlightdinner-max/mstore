import { useState, useEffect } from 'react';
import { User } from '../types';

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('user_session');
    const savedToken = localStorage.getItem('auth_token');
    if (savedUser && savedToken && savedUser !== "undefined" && savedToken !== "undefined") {
      try {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setCurrentUser(JSON.parse(savedUser));
         
        setToken(savedToken);
      } catch (e) {
        console.error("Failed to parse user session:", e);
        localStorage.removeItem('user_session');
        localStorage.removeItem('auth_token');
      }
    }
  }, []);

  const login = (user: User, authToken: string) => {
    setCurrentUser(user);
    setToken(authToken);
    localStorage.setItem('user_session', JSON.stringify(user));
    localStorage.setItem('auth_token', authToken);
  };

  const logout = () => {
    setCurrentUser(null);
    setToken(null);
    localStorage.removeItem('user_session');
    localStorage.removeItem('auth_token');
    localStorage.removeItem('affiliate_id');
    window.location.href = '/';
  };

  return {
    currentUser,
    setCurrentUser,
    token,
    setToken,
    login,
    logout
  };
};
