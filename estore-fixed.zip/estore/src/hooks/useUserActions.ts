/**
 * useUserActions
 *
 * Encapsulates admin user management mutations (add, update, deactivate) that
 * were previously inline in App.tsx.
 */
import { useCallback } from 'react';

interface UseUserActionsOptions {
  token: string | null;
  fetchData: (token?: string | null) => Promise<void>;
  showNotification: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export function useUserActions({
  token,
  fetchData,
  showNotification,
}: UseUserActionsOptions) {
  const authHeaders = useCallback(
    () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    }),
    [token]
  );

  const addUser = useCallback(
    async (newUser: any) => {
      try {
        const res = await fetch('/api/v1/users', {
          method: 'POST',
          headers: authHeaders(),
          body: JSON.stringify(newUser),
        });
        if (res.ok) {
          await fetchData();
          showNotification('User created successfully', 'success');
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to create user', 'error');
        }
      } catch {
        showNotification('Network error creating user', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  const updateUser = useCallback(
    async (id: string, updatedUser: any) => {
      try {
        const res = await fetch(`/api/v1/users/${id}`, {
          method: 'PUT',
          headers: authHeaders(),
          body: JSON.stringify(updatedUser),
        });
        if (res.ok) {
          await fetchData();
          showNotification('User updated successfully', 'success');
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to update user', 'error');
        }
      } catch {
        showNotification('Network error updating user', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  const deleteUser = useCallback(
    async (id: string) => {
      try {
        const res = await fetch(`/api/v1/users/${id}`, {
          method: 'DELETE',
          headers: authHeaders(),
        });
        if (res.ok) {
          await fetchData();
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to deactivate user', 'error');
        }
      } catch {
        showNotification('Network error deactivating user', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  const updateCustomerStatus = useCallback(
    async (id: string, status: 'Active' | 'Blocked') => {
      try {
        const res = await fetch(`/api/v1/customers/${id}/status`, {
          method: 'PATCH',
          headers: authHeaders(),
          body: JSON.stringify({ status }),
        });
        if (res.ok) {
          await fetchData();
          showNotification(`Customer ${status.toLowerCase()} successfully`, 'success');
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to update customer status', 'error');
        }
      } catch {
        showNotification('Network error updating customer status', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  return { addUser, updateUser, deleteUser, updateCustomerStatus };
}
