/**
 * useMetaPixel
 *
 * Manages the Meta (Facebook) Pixel lifecycle and fires standard e-commerce
 * events at every relevant touchpoint.
 *
 * Events fired:
 *   PageView          — on every route change (automatic)
 *   ViewContent       — when a customer opens a product detail page
 *   AddToCart         — when a product is added to cart
 *   InitiateCheckout  — when the customer reaches the checkout page
 *   Purchase          — when an order is placed successfully
 *   Search            — when the search bar is used
 *
 * How it works:
 *   1. When `pixelId` is provided (from config.metaPixelId), this hook injects
 *      the fbq base script into <head> once and initialises the pixel.
 *   2. All event functions are safe no-ops when no pixelId is configured, so
 *      the rest of the app never needs to guard against missing pixel.
 *   3. The pixel script is removed and re-injected if the pixelId changes
 *      (e.g. admin saves a new ID without reloading).
 *
 * Currency is always INR — this store only serves Indian customers.
 */

import { useEffect, useCallback, useRef } from 'react';
import { CartItem, Product } from '../types';

declare global {
  interface Window {
    fbq: (...args: any[]) => void;
    _fbq: any;
  }
}

const CURRENCY = 'INR';
const PIXEL_SCRIPT_ID = 'meta-pixel-base';

export function useMetaPixel(pixelId: string | undefined) {
  const initializedPixelId = useRef<string | null>(null);

  // ── Inject / remove the base fbq script ────────────────────────────────────
  useEffect(() => {
    // No pixel ID configured — remove any existing script and bail
    if (!pixelId) {
      const existing = document.getElementById(PIXEL_SCRIPT_ID);
      if (existing) existing.remove();
      initializedPixelId.current = null;
      return;
    }

    // Already initialized with this exact ID — nothing to do
    if (initializedPixelId.current === pixelId) return;

    // Remove any previously injected script (ID changed)
    const existing = document.getElementById(PIXEL_SCRIPT_ID);
    if (existing) existing.remove();

    // Inject Meta Pixel base code
    const script = document.createElement('script');
    script.id = PIXEL_SCRIPT_ID;
    script.innerHTML = `
      !function(f,b,e,v,n,t,s){
        if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window,document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '${pixelId}');
      fbq('track', 'PageView');
    `;
    document.head.appendChild(script);
    initializedPixelId.current = pixelId;
  }, [pixelId]);

  // ── Safe fbq caller — no-op when pixel not loaded ─────────────────────────
  const fbq = useCallback((...args: any[]) => {
    if (!pixelId || typeof window.fbq !== 'function') return;
    window.fbq(...args);
  }, [pixelId]);

  // ── PageView ───────────────────────────────────────────────────────────────
  // Call on every route change. Pass the current pathname so Meta's
  // analytics show per-page breakdown.
  const trackPageView = useCallback(() => {
    fbq('track', 'PageView');
  }, [fbq]);

  // ── ViewContent ────────────────────────────────────────────────────────────
  // Fire when a customer opens a product detail page.
  const trackViewContent = useCallback((product: Product) => {
    fbq('track', 'ViewContent', {
      content_ids:  [product.id],
      content_name: product.name,
      content_type: 'product',
      content_category: product.category || '',
      value:        product.price,
      currency:     CURRENCY,
    });
  }, [fbq]);

  // ── AddToCart ──────────────────────────────────────────────────────────────
  // Fire when any product is added to the cart.
  const trackAddToCart = useCallback((product: Product, quantity = 1) => {
    fbq('track', 'AddToCart', {
      content_ids:  [product.id],
      content_name: product.name,
      content_type: 'product',
      value:        product.price * quantity,
      currency:     CURRENCY,
      num_items:    quantity,
    });
  }, [fbq]);

  // ── InitiateCheckout ───────────────────────────────────────────────────────
  // Fire when the customer lands on the checkout page.
  // Pass the full cart so Meta can optimise for high-value carts.
  const trackInitiateCheckout = useCallback((cart: CartItem[]) => {
    const value    = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const numItems = cart.reduce((sum, i) => sum + i.quantity, 0);
    fbq('track', 'InitiateCheckout', {
      content_ids:  cart.map(i => i.id),
      content_type: 'product',
      num_items:    numItems,
      value,
      currency:     CURRENCY,
    });
  }, [fbq]);

  // ── Purchase ───────────────────────────────────────────────────────────────
  // Fire ONCE after the order is placed successfully. This is the most
  // important event — Meta uses it to find lookalike audiences of buyers.
  // orderId is passed as the event_id for deduplication with server events.
  const trackPurchase = useCallback((
    orderId:  string,
    cart:     CartItem[],
    total:    number
  ) => {
    fbq('track', 'Purchase', {
      content_ids:  cart.map(i => i.id),
      content_type: 'product',
      num_items:    cart.reduce((sum, i) => sum + i.quantity, 0),
      value:        total,
      currency:     CURRENCY,
      order_id:     orderId,   // deduplication key
    });
  }, [fbq]);

  // ── Search ─────────────────────────────────────────────────────────────────
  // Fire when the customer submits a search query.
  const trackSearch = useCallback((searchString: string) => {
    if (!searchString.trim()) return;
    fbq('track', 'Search', {
      search_string: searchString.trim(),
      currency:      CURRENCY,
    });
  }, [fbq]);

  return {
    trackPageView,
    trackViewContent,
    trackAddToCart,
    trackInitiateCheckout,
    trackPurchase,
    trackSearch,
  };
}
