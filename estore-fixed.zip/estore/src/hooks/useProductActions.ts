/**
 * useProductActions
 *
 * Encapsulates product CRUD mutations (add, update, delete/toggle) that were
 * previously inline in App.tsx, reducing its length and complexity.
 */
import { useCallback } from 'react';
import { Product } from '../types';

interface UseProductActionsOptions {
  token: string | null;
  fetchData: (token?: string | null) => Promise<void>;
  showNotification: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export function useProductActions({
  token,
  fetchData,
  showNotification,
}: UseProductActionsOptions) {
  const authHeaders = useCallback(
    () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    }),
    [token]
  );

  const addProduct = useCallback(
    async (newProd: Partial<Product>) => {
      try {
        const res = await fetch('/api/v1/products', {
          method: 'POST',
          headers: authHeaders(),
          body: JSON.stringify(newProd),
        });
        if (res.ok) {
          await fetchData();
          showNotification('Product added successfully', 'success');
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to add product', 'error');
        }
      } catch {
        showNotification('Network error adding product', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  const updateProduct = useCallback(
    async (id: string, updatedProd: any) => {
      try {
        const res = await fetch(`/api/v1/products/${id}`, {
          method: 'PUT',
          headers: authHeaders(),
          body: JSON.stringify(updatedProd),
        });
        if (res.ok) {
          await fetchData();
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to update product', 'error');
        }
      } catch {
        showNotification('Network error updating product', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  const deleteProduct = useCallback(
    async (id: string) => {
      try {
        const res = await fetch(`/api/v1/products/${id}`, {
          method: 'DELETE',
          headers: authHeaders(),
        });
        if (res.ok) {
          await fetchData();
        } else {
          const err = await res.json().catch(() => ({}));
          showNotification(err?.error || 'Failed to delete product', 'error');
        }
      } catch {
        showNotification('Network error deleting product', 'error');
      }
    },
    [fetchData, showNotification, authHeaders]
  );

  return { addProduct, updateProduct, deleteProduct };
}
