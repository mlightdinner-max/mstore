import { useState, useEffect, useCallback } from 'react';
import { Product, Order, AIAlert, Customer } from '../types';

/**
 * Safely parses a JSON response. Returns `fallback` on any error or non-OK status.
 */
const safeJson = async (res: Response, fallback: any) => {
  if (!res.ok) return fallback;
  const ct = res.headers.get('content-type');
  if (ct && ct.includes('application/json')) {
    try { return await res.json(); } catch { return fallback; }
  }
  return fallback;
};

/**
 * Unwraps a paginated API response `{ data, total, page, pages }` into a plain array.
 * If the response is already an array (legacy endpoints), returns it directly.
 */
const unwrap = (response: any, fallback: any[] = []): any[] => {
  if (Array.isArray(response)) return response;
  if (response && Array.isArray(response.data)) return response.data;
  return fallback;
};

export const useStoreData = (token: string | null) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [config, setConfig] = useState<any>({
    storeName: '',
    currency: 'USD',
    taxRate: 0,
    shippingRate: 0,
    freeShippingThreshold: 0,
    themeColor: '#0f172a',
    themeSecondary: '#1e293b',
    isLive: false,
    aiSettings: {
      enabled: true,
      useProductDescriptions: true,
      useCheckoutValidation: true,
      useRecommendations: true,
      useBlogGeneration: true
    },
    logoUrl: '',
    faviconUrl: '',
    aboutTitle: '',
    aboutContent: '',
    aboutHeroImage: '',
    heroImage: '',
    heroTitle: '',
    heroSubtitle: '',
    contactEmail: '',
    contactPhone: '',
    contactAddress: '',
    storeTagline: '',
    storeDescription: '',
    seoTitle: '',
    seoDescription: '',
    seoKeywords: '',
    accentColor: '#1e293b',
    banners: [],
    qualityTitle: '',
    qualityDescription: '',
    qualityImage: '',
    whatsappNumber: '',
    whatsappMessage: '',
    homeWelcomeMessage: 'Welcome',
    homeSummaryMessage: 'Overview of your store performance.',
    socialLinks: { facebook: '', instagram: '', twitter: '' },
    notifications: [],
    subscribers: [],
    supportTickets: [],
    coupons: [],
    orderStatuses: [
      { id: 'pending', label: 'Pending', color: '#f59e0b', isTerminal: false, triggersEmail: true, triggersWhatsApp: true, triggersPayout: false },
      { id: 'processing', label: 'Processing', color: '#3b82f6', isTerminal: false, triggersEmail: true, triggersWhatsApp: false, triggersPayout: false },
      { id: 'shipped', label: 'Shipped', color: '#8b5cf6', isTerminal: false, triggersEmail: true, triggersWhatsApp: true, triggersPayout: false },
      { id: 'delivered', label: 'Delivered', color: '#10b981', isTerminal: true, triggersEmail: true, triggersWhatsApp: true, triggersPayout: true },
      { id: 'cancelled', label: 'Cancelled', color: '#ef4444', isTerminal: true, triggersEmail: true, triggersWhatsApp: false, triggersPayout: false, requiresNote: true },
      { id: 'returned', label: 'Returned', color: '#6366f1', isTerminal: true, triggersEmail: true, triggersWhatsApp: false, triggersPayout: false, requiresNote: true },
      { id: 'open', label: 'OPEN', color: '#3b82f6', isTerminal: false, triggersEmail: false, triggersWhatsApp: false, triggersPayout: false },
      { id: 'waiting_close', label: 'WAITING TO CLOSE', color: '#f59e0b', isTerminal: true, triggersEmail: false, triggersWhatsApp: false, triggersPayout: false },
      { id: 'closed', label: 'CLOSED', color: '#000000', isTerminal: true, triggersEmail: false, triggersWhatsApp: false, triggersPayout: true, requiresNote: true }
    ],
    tags: ['Bestseller', 'New Arrival', 'Limited Edition', 'Discounted']
  });
  const [aiAlerts, setAiAlerts] = useState<AIAlert[]>([]);
  const [notificationLogs, setNotificationLogs] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [affiliatePayouts, setAffiliatePayouts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async (authToken?: string | null) => {
    const activeToken = authToken || token;
    const headers: HeadersInit = activeToken ? { Authorization: `Bearer ${activeToken}` } : {};

    try {
      // Pass limit=0 on admin-only endpoints so we always get the full dataset.
      // Storefront-facing endpoints (products, config) are unaffected.
      const [
        prodData, userData, orderData, configData, fullConfigData,
        alertData, notifData, auditData, payoutData, customerData,
        ticketData, subData
      ] = await Promise.all([
        fetch('/api/v1/products?limit=0', { headers }).then(r => safeJson(r, [])),
        fetch('/api/v1/users?limit=0', { headers }).then(r => safeJson(r, [])),
        fetch('/api/v1/orders?limit=0', { headers }).then(r => safeJson(r, [])),
        fetch('/api/v1/config').then(r => safeJson(r, {})),
        activeToken
          ? fetch('/api/v1/config/full', { headers }).then(r => safeJson(r, null))
          : Promise.resolve(null),
        fetch('/api/v1/alerts', { headers }).then(r => safeJson(r, [])),
        activeToken
          ? fetch('/api/v1/notifications/history?limit=0', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
        activeToken
          ? fetch('/api/v1/audit-logs?limit=0', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
        activeToken
          ? fetch('/api/v1/affiliates/payouts', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
        activeToken
          ? fetch('/api/v1/customers?limit=0', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
        activeToken
          ? fetch('/api/v1/support/tickets?limit=0', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
        activeToken
          ? fetch('/api/v1/newsletter?limit=0', { headers }).then(r => safeJson(r, []))
          : Promise.resolve([]),
      ]);

      // Unwrap paginated responses into plain arrays
      setProducts(unwrap(prodData));
      setUsers(unwrap(userData));
      setOrders(unwrap(orderData));
      setConfig((prev: any) => ({
        ...prev,
        ...(fullConfigData || configData),
        supportTickets: unwrap(ticketData),
        subscribers: unwrap(subData),
      }));
      setAiAlerts(unwrap(alertData));
      setNotificationLogs(unwrap(notifData));
      setAuditLogs(unwrap(auditData));
      setAffiliatePayouts(unwrap(payoutData));
      setCustomers(unwrap(customerData));
    } catch (err) {
      console.error('fetchData error:', err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchData();
  }, [fetchData]);

  // Refresh in the background every minute while the admin is logged in
  useEffect(() => {
    if (!token) return;
    const interval = setInterval(() => fetchData(), 60_000);
    return () => clearInterval(interval);
  }, [token, fetchData]);

  return {
    products, setProducts,
    users, setUsers,
    orders, setOrders,
    config, setConfig,
    aiAlerts, setAiAlerts,
    notificationLogs, setNotificationLogs,
    auditLogs, setAuditLogs,
    affiliatePayouts, setAffiliatePayouts,
    customers, setCustomers,
    loading, setLoading,
    fetchData,
  };
};
