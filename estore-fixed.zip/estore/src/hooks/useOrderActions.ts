/**
 * useOrderActions
 *
 * Encapsulates all order-related mutations that were previously inline in App.tsx:
 *   - placeOrder
 *   - updateOrderStatus
 *   - updateOrderItemStatus
 *
 * This hook keeps App.tsx focused on layout and routing rather than business logic.
 */
import { useCallback } from 'react';
import { Order } from '../types';

interface UseOrderActionsOptions {
  orders: Order[];
  token: string | null;
  currentUser: any;
  orderSource: string;
  clearCart: () => void;
  fetchData: (token?: string | null) => Promise<void>;
  showNotification: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export function useOrderActions({
  orders,
  token,
  currentUser,
  orderSource,
  clearCart,
  fetchData,
  showNotification,
}: UseOrderActionsOptions) {
  /** Place a new customer order. Returns the created order or null on failure. */
  const placeOrder = useCallback(async (orderData: any): Promise<any | null> => {
    // Client-side spam guard (server has its own rate limiter too)
    const recentOrders = orders.filter(
      o =>
        (o.email === orderData.email || o.phone === orderData.phone) &&
        new Date(o.createdAt).getTime() > Date.now() - 3_600_000
    );
    if (recentOrders.length >= 50) {
      showNotification(
        'Too many orders placed recently. Please wait an hour before placing another order.',
        'error'
      );
      return null;
    }

    const affiliateId = localStorage.getItem('affiliate_id');
    try {
      const res = await fetch('/api/v1/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...orderData,
          source: affiliateId ? 'Affiliate' : orderSource,
          affiliateId,
        }),
      });

      if (res.ok) {
        const createdOrder = await res.json();
        clearCart();
        localStorage.removeItem('affiliate_id');
        await fetchData();
        return createdOrder;
      }

      const err = await res.json().catch(() => ({}));
      showNotification(err?.error || 'Failed to place order. Please try again.', 'error');
      return null;
    } catch {
      showNotification('Network error. Please check your connection and try again.', 'error');
      return null;
    }
  }, [orders, orderSource, clearCart, fetchData, showNotification]);

  /** Update the top-level status of an order (admin). */
  const updateOrderStatus = useCallback(async (
    id: string,
    status: string,
    statusDate?: string,
    statusChangeReason?: string,
    updatedBy?: string,
    eta?: string
  ) => {
    const order = orders.find(o => o.id === id);
    if (!order) return;

    const history = order.statusHistory || [];
    const newEntry = {
      status,
      date: statusDate || new Date().toISOString(),
      reason: statusChangeReason,
      updatedBy: updatedBy || currentUser?.name || 'Admin',
      ...(eta ? { eta } : {}),
    };

    const isReopening = order.status === 'CLOSED' && status !== 'CLOSED';

    let items: any[] | undefined;
    if (status === 'Cancelled' || status === 'Return') {
      const itemStatus = status === 'Return' ? 'Returned' : 'Cancelled';
      items = (order.items || []).map(item => ({
        ...item,
        status: itemStatus,
        statusHistory: [
          ...(item.statusHistory || []),
          {
            status: itemStatus,
            date: newEntry.date,
            reason: statusChangeReason,
            updatedBy: newEntry.updatedBy,
          },
        ],
        ...(status === 'Cancelled'
          ? { cancelledAt: newEntry.date, cancellationReason: statusChangeReason }
          : {}),
        ...(status === 'Return'
          ? { returnedAt: newEntry.date, returnReason: statusChangeReason }
          : {}),
      }));
    }

    const payload: any = {
      status,
      ...(items ? { items } : {}),
      statusDate,
      statusChangeReason,
      updatedBy: updatedBy || currentUser?.name || 'Admin',
      statusHistory: [...history, newEntry],
      ...(isReopening ? { reopenReason: statusChangeReason } : {}),
    };
    if (eta) payload.eta = eta;

    try {
      const res = await fetch(`/api/v1/orders/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        await fetchData();
      } else {
        const err = await res.json().catch(() => ({}));
        showNotification(err?.error || 'Failed to update order status', 'error');
      }
    } catch {
      showNotification('Network error updating order status', 'error');
    }
  }, [orders, token, currentUser, fetchData, showNotification]);

  /** Update the status of a single item within an order (admin). */
  const updateOrderItemStatus = useCallback(async (
    orderId: string,
    itemId: string,
    status: any,
    reason?: string,
    date?: string,
    eta?: string
  ) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    const effectiveDate = date || new Date().toISOString();
    const updatedItems = (order.items || []).map((item: any) => {
      if (item.id !== itemId) return item;

      const newHistoryEntry = {
        status,
        date: effectiveDate,
        reason: reason || '',
        updatedBy: currentUser?.name || 'Admin',
      };

      return {
        ...item,
        status,
        statusHistory: [...(item.statusHistory || []), newHistoryEntry],
        ...(status === 'Delivered' ? { deliveredAt: effectiveDate } : {}),
        ...(status === 'Cancelled'
          ? { cancelledAt: effectiveDate, cancellationReason: reason }
          : {}),
        ...(status === 'Returned'
          ? { returnedAt: effectiveDate, returnReason: reason }
          : {}),
        ...(status === 'Shipped' && eta ? { eta } : {}),
      };
    });

    try {
      const res = await fetch(`/api/v1/orders/${orderId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          items: updatedItems,
          adminNote: reason,
          effectiveDate,
          updatedBy: currentUser?.name || 'Admin',
        }),
      });
      if (res.ok) {
        await fetchData();
      } else {
        const err = await res.json().catch(() => ({}));
        showNotification(err?.error || 'Failed to update item status', 'error');
      }
    } catch {
      showNotification('Network error updating item status', 'error');
    }
  }, [orders, token, currentUser, fetchData, showNotification]);

  return { placeOrder, updateOrderStatus, updateOrderItemStatus };
}
