/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Routes, Route, useNavigate, useLocation, useSearchParams, useParams, Navigate } from 'react-router-dom';
import { LayoutDashboard, CheckCircle2, ShieldAlert, Save, RefreshCw, AlertTriangle, Package, Brain, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, Order, AIAlert, Visitor } from './types';
import { useOrderActions } from './hooks/useOrderActions';
import { useProductActions } from './hooks/useProductActions';
import { useUserActions } from './hooks/useUserActions';
import { useMetaPixel } from './hooks/useMetaPixel';

// --- Common Components ---
import Modal from './components/common/Modal';
import ConfirmationModal from './components/common/ConfirmationModal';
import NotificationBar from './components/common/NotificationBar';

// --- Admin Components ---
// Always-loaded: shell, auth, navigation, common UI
import AdminSidebar from './components/admin/AdminSidebar';
import { ADMIN_MENU_GROUPS } from './components/admin/AdminMenuSchema';
import Navbar from './components/store/Navbar';
import CartDrawer from './components/store/CartDrawer';
import LoginPage from './components/auth/LoginPage';
import { AppProvider } from './context/AppProvider';
import ScrollToTop from './components/common/ScrollToTop';
import { DEFAULT_PERMISSIONS, CONFIGURABLE_MODULES, CAPTCHA_CHARS } from './constants';
import OfflinePage from './pages/common/OfflinePage';

// Lazy-loaded admin panels — only downloaded when an admin logs in
import { AdminPanel } from './AdminPanel';

// Lazy-loaded store pages
const HomePage          = React.lazy(() => import('./components/store/HomePage'));
const ProductsPage      = React.lazy(() => import('./components/store/ProductsPage'));
const ProductDetailPage = React.lazy(() => import('./components/store/ProductDetailPage'));
const CheckoutPage      = React.lazy(() => import('./components/store/CheckoutPage'));
const BlogPage          = React.lazy(() => import('./components/store/BlogPage'));
const SupportPage       = React.lazy(() => import('./components/store/SupportPage'));
const AboutPage         = React.lazy(() => import('./components/store/AboutPage'));
const StoreFooter       = React.lazy(() => import('./components/store/StoreFooter'));
const TrackingPage      = React.lazy(() => import('./pages/store/TrackingPage').then(m => ({ default: m.TrackingPage })));
const PrivacyPolicyPage    = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.PrivacyPolicyPage })));
const TermsOfServicePage   = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.TermsOfServicePage })));
const ReturnsPolicyPage    = React.lazy(() => import('./components/store/LegalPages').then(m => ({ default: m.ReturnsPolicyPage })));










// --- Main App ---

import { useAuth } from './hooks/useAuth';
import { useStoreData } from './hooks/useStoreData';
import { useCart } from './hooks/useCart';

export default function App() {
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [orderSource] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    const source = params.get('utm_source') || params.get('source');
    if (source) {
      localStorage.setItem('order_source', source);
      return source;
    }
    return localStorage.getItem('order_source') || 'Direct';
  });
  const { currentUser, setCurrentUser, token, setToken, logout } = useAuth();
  const { 
    products, 
    users, 
    orders, 
    config, setConfig, 
    aiAlerts, setAiAlerts, 
    notificationLogs, setNotificationLogs,
    auditLogs, 
    affiliatePayouts, 
    customers,
    loading,
    fetchData 
  } = useStoreData(token);

  const [aiStatus, setAiStatus] = useState<any>(null);
  const lastTestedApiKey = React.useRef<string | undefined>(undefined);

  const fetchAiStatus = useCallback(async (apiKey?: string) => {
    try {
      const queryParams = new URLSearchParams();
      
      // Use the provided apiKey, or fallback to the last tested one if it exists
      const keyToUse = apiKey || lastTestedApiKey.current;
      if (keyToUse) {
        queryParams.append('apiKey', keyToUse);
      }
      
      const queryString = queryParams.toString();
      const url = `/api/v1/ai/status${queryString ? `?${queryString}` : ''}`;
      
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setAiStatus(data);
        
        // If we fetched with a key and it was healthy, remember this key for future refreshes
        // until a new one is provided or global config updates
        if (apiKey) {
          lastTestedApiKey.current = apiKey;
        }
      }
    } catch (err) {
      console.error('Failed to fetch AI status:', err);
    }
  }, []);

  // Reset lastTestedApiKey when config changes (it was either saved or rolled back)
  useEffect(() => {
    lastTestedApiKey.current = undefined;
  }, [config.geminiApiKey]);

  useEffect(() => {
    const initFetch = async () => {
      await fetchAiStatus();
    };
    initFetch();
    const interval = setInterval(fetchAiStatus, 60000); // Check health every minute
    return () => clearInterval(interval);
  }, [fetchAiStatus]);

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setNotification({ message, type });
  };
  
  const { 
    cart, setCart, 
    isCartOpen, setIsCartOpen, 
    isConfirmModalOpen, setIsConfirmModalOpen, 
    addToCart, updateQuantity, removeItem, handleConfirmRemove, clearCart 
  } = useCart(showNotification);

  useEffect(() => {
    const pingVisitor = async () => {
      // Only ping if the tab is active/focused to avoid noise and unnecessary errors
      if (!document.hasFocus()) return;
      
      try {
        const deviceType = /Mobile|Android|iPhone/i.test(navigator.userAgent) ? 'mobile' : 
                          /Tablet|iPad/i.test(navigator.userAgent) ? 'tablet' : 'desktop';

        const pingRes = await fetch('/api/v1/visitors/ping', { 
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache' 
          },
          body: JSON.stringify({
            currentPage: window.location.pathname,
            deviceType,
            locale: navigator.language,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
          })
        });
        
        if (pingRes.ok) {
          const countRes = await fetch('/api/v1/visitors/count');
          if (countRes.ok) {
            const data = await countRes.json();
            setConfig(prev => ({ ...prev, visitorCount: data.count }));
          }
        }
      } catch {
        // Silent fail for background pings to avoid console spam
        // console.debug('Visitor ping skipped or failed');
      }
    };

    pingVisitor();
    const interval = setInterval(pingVisitor, 15000); // Ping every 15 seconds
    
    return () => {
      if (interval) clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const location = useLocation();
  const [searchParams] = useSearchParams();

  const isAdminPage = location.pathname.startsWith('/home');
  const isLoginPage = location.pathname === '/logintosft' || location.pathname === '/affiliate';
  const isAffiliatePage = location.pathname.startsWith('/affiliate') && location.pathname !== '/affiliate';
  const isMaintenanceMode = config.isLive === false && !isAdminPage && !isLoginPage && !location.pathname.startsWith('/affiliate') && currentUser?.role !== 'Admin' && currentUser?.role !== 'Super Admin' && currentUser?.role !== 'Affiliate';

  // ── Meta Pixel ─────────────────────────────────────────────────────────────
  const { trackPageView, trackViewContent, trackAddToCart, trackInitiateCheckout, trackPurchase, trackSearch } =
    useMetaPixel(config.metaPixelId);

  // Fire PageView on every storefront route change (skip admin/login pages)
  useEffect(() => {
    if (!isAdminPage && !isLoginPage && !isAffiliatePage) {
      trackPageView();
    }
  }, [location.pathname, isAdminPage, isLoginPage, isAffiliatePage, trackPageView]);

  // Fire Search event when search query changes (debounced — only when non-empty)
  useEffect(() => {
    if (!searchQuery.trim()) return;
    const t = setTimeout(() => trackSearch(searchQuery), 800);
    return () => clearTimeout(t);
  }, [searchQuery, trackSearch]);
  useEffect(() => {
    const affiliateId = searchParams.get('aff') || searchParams.get('ref');
    if (affiliateId) {
      localStorage.setItem('affiliate_id', affiliateId);
      // Track click on server
      fetch('/api/v1/affiliates/click', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ affiliateId })
      }).catch(err => console.error("Failed to track affiliate click:", err));
    }
  }, [searchParams]);

  useEffect(() => {
    if (config.storeName) {
      document.title = `${config.storeName} | Modern E-commerce`;
    }
  }, [config.storeName]);

  useEffect(() => {
    if (config.faviconUrl) {
      let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.getElementsByTagName('head')[0].appendChild(link);
      }
      link.href = config.faviconUrl;
    }
  }, [config.faviconUrl]);

  useEffect(() => {
    if (config?.themeColor) {
      document.documentElement.style.setProperty('--primary-color', config.themeColor);
    }
    if (config?.themeSecondary) {
      document.documentElement.style.setProperty('--secondary-color', config.themeSecondary);
    }
  }, [config?.themeColor, config?.themeSecondary]);

  const clearAlerts = async () => {
    try {
      const res = await fetch('/api/v1/alerts', { 
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) setAiAlerts([]);
    } catch (error) {
      console.error('Error clearing alerts:', error);
    }
  };

  const deleteAlert = async (id: string) => {
    try {
      const res = await fetch(`/api/v1/alerts/${id}`, { 
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) setAiAlerts(prev => prev.filter(a => a.id !== id));
    } catch (error) {
      console.error('Error deleting alert:', error);
    }
  };

  const updateConfig = async (newConfig: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/v1/config', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newConfig)
      });
      
      if (res.ok) {
        setConfig(newConfig);
        await Promise.all([fetchData(), fetchAiStatus()]);
        return true;
      } else {
        if (res.status === 401) {
          logout();
          showNotification('Session expired. Please login again.', 'error');
          return false;
        }
        const errorData = await res.json().catch(() => ({}));
        console.error('Config update failed:', res.status, errorData);
        return false;
      }
    } catch (error) {
      console.error('Error updating config:', error);
      return false;
    }
  };

  const handleResetApp = async (password: string) => {
    try {
      const res = await fetch('/api/v1/dashboard/metrics/refresh', { 
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ payload: btoa(unescape(encodeURIComponent(password))) })
      });
      if (res.ok) {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = '/';
        return true;
      } else {
        const text = await res.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch {
          console.error("Failed to parse JSON response:", text);
          showNotification('Reset failed: Server returned invalid response', 'error');
          return false;
        }
        showNotification(data.error || 'Reset failed', 'error');
        return false;
      }
    } catch (error) {
      console.error('Reset error:', error);
      return false;
    }
  };

  const handleLogin = async (credentials: any): Promise<boolean | string> => {
    try {
      const res = await fetch('/api/v1/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        setToken(data.token);
        localStorage.setItem('user_session', JSON.stringify(data.user));
        localStorage.setItem('auth_token', data.token);
        fetchData(data.token);
        return true;
      }
      // Surface the server error message (e.g. suspended account)
      const err = await res.json().catch(() => ({ error: 'Login failed' }));
      return err.error || false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  // ── Order / Product / User actions ──────────────────────────────────────────
  // These were previously inlined here. They now live in dedicated hooks which
  // keeps this component focused on layout, routing, and global UI state.
  const { placeOrder: placeOrderBase, updateOrderStatus, updateOrderItemStatus } = useOrderActions({
    orders,
    token,
    currentUser,
    orderSource,
    clearCart,
    fetchData,
    showNotification,
  });

  const { addProduct, updateProduct, deleteProduct } = useProductActions({
    token,
    fetchData,
    showNotification,
  });

  const { addUser, updateUser, deleteUser, updateCustomerStatus } = useUserActions({
    token,
    fetchData,
    showNotification,
  });

  // ── Pixel-instrumented wrappers ────────────────────────────────────────────
  // These sit between the UI and the underlying action so pixel events fire
  // automatically without polluting individual page components.

  const addToCartWithPixel = useCallback((product: any, selectedVariants?: Record<string, string>) => {
    addToCart(product, selectedVariants);
    trackAddToCart(product, 1);
  }, [addToCart, trackAddToCart]);

  const placeOrder = useCallback(async (orderData: any) => {
    const order = await placeOrderBase(orderData);
    if (order?.id) {
      // Purchase fires once, immediately after the order is confirmed
      trackPurchase(order.id, cart, orderData.total ?? 0);
    }
    return order;
  }, [placeOrderBase, trackPurchase, cart]);


  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <AppProvider value={{ 
      config, 
      user: currentUser, 
      cart, 
      token, 
      onAddToCart: addToCartWithPixel,
      onUpdateCart: updateQuantity,
      onRemoveFromCart: removeItem,
      onClearCart: () => setCart([]),
      onLogin: (u, t) => { setCurrentUser(u); setToken(t); },
      onLogout: logout,
      onUpdateConfig: updateConfig,
      onShowNotification: showNotification 
    }}>
      <div className="min-h-screen bg-white font-sans text-slate-900 overflow-x-hidden">
      <a href="#main-content" className="skip-to-content">Skip to main content</a>
      <ScrollToTop />
      <NotificationBar 
        notifications={config.notifications || []} 
        onClose={(id) => {
          const newNotifs = (config.notifications || []).filter((n: any) => n.id !== id);
          updateConfig({ ...config, notifications: newNotifs });
        }} 
      />
      {isMaintenanceMode ? (
        <OfflinePage config={config} />
      ) : (
        <>
          {!(isAdminPage || isAffiliatePage || isLoginPage) && (
            <Navbar 
              cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)} 
              onOpenCart={() => setIsCartOpen(true)} 
              config={config} 
              currentUser={currentUser} 
              onLogout={logout}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
            />
          )}
      
      <main id="main-content" className={(isAdminPage || isAffiliatePage || isLoginPage) ? "" : "pt-14 md:pt-16"}>
        {/* Login routes are static imports — must render outside Suspense so they never show a blank page */}
        <Routes>
          <Route path="/logintosft" element={<LoginPage onLogin={handleLogin} />} />
          <Route path="/affiliate" element={<LoginPage onLogin={handleLogin} />} />
          <Route path="*" element={null} />
        </Routes>
        <React.Suspense fallback={<div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-2 border-slate-200 border-t-slate-900 rounded-full animate-spin" /></div>}>
        <Routes>
          <Route path="/" element={<HomePage onAddToCart={addToCartWithPixel} onUpdateQuantity={updateQuantity} onRemoveItem={removeItem} products={products} config={config} orders={orders} cart={cart} token={token} />} />
          <Route path="/products" element={<ProductsPage onAddToCart={addToCartWithPixel} onUpdateQuantity={updateQuantity} onRemoveItem={removeItem} products={products} config={config} cart={cart} searchQuery={searchQuery} />} />
          <Route path="/product/:id" element={<ProductDetailPage products={products} onAddToCart={addToCartWithPixel} onUpdateQuantity={updateQuantity} onRemoveItem={removeItem} cart={cart} config={config} token={token} onViewContent={trackViewContent} />} />
          <Route path="/blog" element={<BlogPage config={config} />} />
          <Route path="/contact" element={<SupportPage config={config} onShowNotification={showNotification} />} />
          <Route path="/checkout" element={<CheckoutPage cart={cart} onPlaceOrder={placeOrder} config={config} onClearCart={() => setCart([])} aiStatus={aiStatus} onInitiateCheckout={() => trackInitiateCheckout(cart)} />} />
          <Route path="/tracking" element={
            <TrackingPage 
              config={config} 
              onUpdateItemStatus={updateOrderItemStatus}
              onUpdateOrderStatus={updateOrderStatus}
            />
          } />
          <Route path="/privacy" element={<PrivacyPolicyPage config={config} />} />
          <Route path="/terms" element={<TermsOfServicePage config={config} />} />
          <Route path="/returns" element={<ReturnsPolicyPage config={config} />} />
          <Route path="/about" element={<AboutPage config={config} ordersCount={orders.length} />} />
          <Route path="/home/*" element={
            <AdminPanel 
              products={products} 
              users={users} 
              orders={orders} 
              config={config} 
              aiAlerts={aiAlerts} 
              onClearAlerts={clearAlerts} 
              onDeleteAlert={deleteAlert} 
              onAddProduct={addProduct} 
              onDeleteProduct={deleteProduct} 
              onUpdateProduct={updateProduct} 
              onAddUser={addUser} 
              onDeleteUser={deleteUser} 
              onUpdateUser={updateUser} 
              onUpdateOrderStatus={updateOrderStatus} 
              onUpdateItemStatus={updateOrderItemStatus}
              onUpdateCustomerStatus={updateCustomerStatus}
              onUpdateConfig={updateConfig} 
              onResetApp={handleResetApp} 
              onShowNotification={showNotification} 
              user={currentUser} 
              onLogout={logout} 
              notificationLogs={notificationLogs} 
              setNotificationLogs={setNotificationLogs}
              token={token} 
              auditLogs={auditLogs}
              affiliatePayouts={affiliatePayouts}
              customers={customers}
              fetchData={fetchData}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              aiStatus={aiStatus}
              onRefreshAiStatus={fetchAiStatus}
            />
          } />
          <Route path="/affiliate/*" element={
            <AdminPanel 
              products={products} 
              users={users} 
              orders={orders} 
              config={config} 
              aiAlerts={aiAlerts} 
              onClearAlerts={clearAlerts} 
              onDeleteAlert={deleteAlert} 
              onAddProduct={addProduct} 
              onDeleteProduct={deleteProduct} 
              onUpdateProduct={updateProduct} 
              onAddUser={addUser} 
              onDeleteUser={deleteUser} 
              onUpdateUser={updateUser} 
              onUpdateOrderStatus={updateOrderStatus} 
              onUpdateItemStatus={updateOrderItemStatus}
              onUpdateCustomerStatus={updateCustomerStatus}
              onUpdateConfig={updateConfig} 
              onResetApp={handleResetApp} 
              onShowNotification={showNotification} 
              user={currentUser} 
              onLogout={logout} 
              notificationLogs={notificationLogs} 
              setNotificationLogs={setNotificationLogs}
              token={token} 
              auditLogs={auditLogs}
              affiliatePayouts={affiliatePayouts}
              customers={customers}
              fetchData={fetchData}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              aiStatus={aiStatus}
              onRefreshAiStatus={fetchAiStatus}
            />
          } />
          <Route path="/logintosft" element={null} />
          <Route path="/affiliate" element={null} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        </React.Suspense>
      </main>

      {!(isAdminPage || isAffiliatePage || isLoginPage) && <StoreFooter config={config} />}
        </>
      )}


        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          cart={cart}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeItem}
        />

        <ConfirmationModal 
          isOpen={isConfirmModalOpen}
          onClose={() => setIsConfirmModalOpen(false)}
          onConfirm={handleConfirmRemove}
          title="Remove Item?"
          message="Are you sure you want to remove this item from your cart?"
        />

        {/* Notification Toast */}
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[2000] px-6 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 border ${
                notification.type === 'success' ? 'bg-primary text-white border-primary/80' :
                notification.type === 'error' ? 'bg-red-600 text-white border-red-500' :
                'bg-slate-900 text-white border-slate-800'
              }`}
            >
              {notification.type === 'success' && <CheckCircle2 size={20} />}
              {notification.type === 'error' && <ShieldAlert size={20} />}
              <span className="font-bold text-sm">{notification.message}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppProvider>
  );
}
