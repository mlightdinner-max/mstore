/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PriceHistoryEntry {
  previousPrice: number;
  updatedPrice: number;
  timestamp: string;
  associatedOrders?: string[];
}

export interface ProductVariant {
  id: string;
  name: string;
  options: string[];
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  description: string;
  price: number;
  originalCost: number;
  mrp?: number;
  profitPrice: number;
  category: string;
  image: string;
  images?: string[];
  stock: number;
  lowStockThreshold?: number;
  isApproved?: boolean;
  isActive?: boolean;
  isOutOfStock?: boolean;
  orderLimit?: number;
  sourceUrl?: string;
  tags?: string[];
  status?: 'active' | 'deactivated' | 'draft';
  isDeleted?: boolean;
  folder?: string;
  variants?: ProductVariant[];
  priceHistory?: PriceHistoryEntry[];
  createdAt?: string;
  rating?: number;
}

export interface CartItem extends Product {
  quantity: number;
  selectedVariants?: Record<string, string>;
}

export interface StatusHistoryEntry {
  status: string;
  date: string;
  reason?: string;
  updatedBy?: string;
}

export interface OrderItem extends Omit<CartItem, 'status'> {
  originalCostAtPurchase: number;
  priceAtPurchase: number;
  status?: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Returned' | 'Return Requested' | 'Cancellation Requested' | 'Return Rejected';
  statusHistory?: StatusHistoryEntry[];
  cancellationReason?: string;
  returnReason?: string;
  returnRequestDate?: string;
  returnAdminResponse?: string;
  deliveredAt?: string;
  returnedAt?: string;
  cancelledAt?: string;
}

// Order-level status — always uppercase for the lifecycle statuses.
// The server (orderService.ts, orders.ts) is authoritative and always writes OPEN / CLOSED / WAITING TO CLOSE.
export type OrderStatus =
  | 'Pending'
  | 'Processing'
  | 'Shipped'
  | 'Delivered'
  | 'Completed'
  | 'Cancelled'
  | 'Returned'
  | 'Dummy'
  | 'OPEN'
  | 'CLOSED'
  | 'WAITING TO CLOSE';

export interface Order {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  items: OrderItem[];
  total: number;
  shipping?: number;
  subtotal?: number;
  status: OrderStatus;
  statusHistory?: StatusHistoryEntry[];
  eta?: string;
  reopenReason?: string;
  source?: string;
  paymentMethod?: 'COD' | 'Online';
  createdAt: string;
  shippedAt?: string;
  deliveredAt?: string;
  cancelledAt?: string;
  returnedAt?: string;
  closingDate?: string;
  closingNote?: string;
  affiliateId?: string;
  commissionAmount?: number;
  discountAmount?: number;
  couponCode?: string;
  couponUsed?: string;
  soldPrice?: number;
  discountedPrice?: number;
  discountRatio?: number;
  affiliatePayout?: number;
  netMargin?: number;
  customerId?: string;
  isDummy?: boolean;
  isAiValidated?: boolean;
  isAiFlagged?: boolean;
  affiliatePayoutStatus?: 'None' | 'Requested' | 'Paid' | 'On Hold';
  affiliatePayoutId?: string;
  affiliatePayoutClawbackNeeded?: boolean;
  affiliatePayoutHoldReason?: string;
  latestDeliveredAt?: string;
  customerRequest?: { action: string; note: string; timestamp: string };
  adminNote?: string;
  systemTags?: string[];
  updatedAt?: string;
  customerType?: 'New' | 'Repeat';
  shippingFee?: number;
  discount?: number;
  // ── Fulfilment Agent fields ──────────────────────────────────────────────
  meeshoOrderId?: string;         // Meesho order ID after successful placement
  meeshoOrderUrl?: string;        // Direct link to order on Meesho
  agentStatus?:                   // Current state in the fulfilment pipeline
    | 'pending_confirmation'      // Waiting for admin to tap "Place on Meesho" in Telegram
    | 'placing'                   // Agent is currently placing the order on Meesho
    | 'placed'                    // Successfully placed; meeshoOrderId is set
    | 'failed'                    // Placement failed; see agentError
    | 'manually_placed'           // Admin placed manually and entered Meesho order ID
    | 'cancelling'                // Agent is cancelling on Meesho
    | 'cancelled_on_meesho'       // Cancellation confirmed on Meesho
    | 'cancel_failed'             // Cancellation failed; manual action needed
    | 'returning'                 // Agent is initiating return on Meesho
    | 'return_initiated'          // Return successfully initiated on Meesho
    | 'return_failed';            // Return failed; manual action needed
  agentError?: string;            // Last error message from the agent
  agentAttempts?: number;         // Number of placement attempts made
  agentLastAttemptAt?: string;    // ISO timestamp of last attempt
  telegramMessageId?: number;     // Telegram message ID for editing in-place
}

export interface Affiliate {
  id: string;
  name: string;
  email: string;
  affiliateId?: string;
  /** Referral code — alias for affiliateId in the admin panel view */
  code?: string;
  commissionRate?: number;
  assignedProducts?: string[];
  totalRevenue?: number;
  totalCommission?: number;
  referralClicks?: number;
  paymentInfo?: string;
  isBlocked?: boolean;
  status?: string;
  role?: UserRole;
  joinedAt?: string;
}

export interface AffiliateGroup {
  id: string;
  name: string;
  commissionRate: number;
  description?: string;
  memberCount: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  emails?: string[];
  phones?: string[];
  addresses?: Array<{
    address: string;
    city: string;
    state: string;
    zip: string;
  }>;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
  joinedDate: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  status?: string;
}

export interface AffiliatePayout {
  id: string;
  affiliateId: string;
  orderIds: string[];
  amount: number;
  status: 'pending' | 'paid';
  requestedAt: string;
  paidAt?: string;
  paymentMethod?: string;
  transactionId?: string;
}

export interface OrderStatusBlueprint {
  id: string;
  label: string;
  color: string;
  isTerminal: boolean;
  triggersEmail: boolean;
  triggersWhatsApp: boolean;
  triggersPayout: boolean;
  requiresNote?: boolean;
}

export interface Config {
  storeName: string;
  storeTagline?: string;
  storeDescription: string;
  isLive: boolean;
  themeColor?: string;
  themeSecondary?: string;
  accentColor?: string;
  aboutTitle?: string;
  aboutContent?: string;
  aboutMission?: string;
  aboutVision?: string;
  aboutHeroImage?: string;
  contactEmail?: string;
  contactPhone?: string;
  contactAddress?: string;
  supportEmail?: string;
  supportHeading?: string;
  supportSubheading?: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  affiliates?: any[];
  affiliatePayouts?: any[];
  socialLinks?: {
    instagram?: string;
    twitter?: string;
    facebook?: string;
  };
  resetPassword?: string;
  categories: { id: string; name: string; icon?: string }[] | any[];
  // orderStatuses is the active field — replaces the old 'statuses: string[]'
  orderStatuses: OrderStatusBlueprint[];
  tags: string[];
  banners: { image: string; link: string; title?: string; subtitle?: string }[];
  footerLinks?: {
    shop?: { label: string; link: string }[];
    company?: { label: string; link: string }[];
  };
  heroTag?: string;
  qualityTitle?: string;
  qualityDescription?: string;
  qualityImage?: string;
  logoUrl?: string;
  faviconUrl?: string;
  visitorCount?: number;
  homeWelcomeMessage?: string;
  homeSummaryMessage?: string;
  privacyPolicy?: string;
  termsOfService?: string;
  returnsPolicy?: string;
  geminiApiKey?: string;
  metaPixelId?: string;         // Meta (Facebook) Pixel ID — e.g. "1234567890123456"
  // ── Fulfilment Agent ──────────────────────────────────────────────────────
  // Credentials are stored server-side only (scrubbed from all client responses).
  // The agent reads them from process.env or config on the server.
  agentSettings?: {
    enabled: boolean;            // Master switch for the fulfilment agent
    autoPlace: boolean;          // true = place immediately; false = wait for Telegram confirmation
    maxAttempts: number;         // How many times to retry a failed placement (default 3)
    retryDelayMinutes: number;   // Minutes between retry attempts (default 15)
  };
  telegramSettings?: {
    botToken?: string;           // Bot token from @BotFather — stored masked
    chatId?: string;             // Your personal Telegram chat ID
  };
  meeshoSettings?: {
    email?: string;              // Meesho account email — stored masked
    password?: string;           // Meesho account password — stored masked
  };
  aiSettings?: {
    enabled: boolean;
    useProductDescriptions: boolean;
    useCheckoutValidation: boolean;
    useRecommendations: boolean;
    useBlogGeneration: boolean;
  };
  aiPrompts?: {
    monitor?: string;
    validation?: string;
  };
  supportHoursWorkingDays?: string;
  supportHoursWorkingTime?: string;
  supportHoursWeekendDays?: string;
  supportHoursWeekendTime?: string;
  customTopReorderedIds?: string[];
  aiMonitoringEnabled?: boolean;
  profilePermissions?: Record<string, string[]>;
  primaryColor?: string;
  navigation?: any;
  showSearch?: boolean;
  stickyHeader?: boolean;
  notifications?: any[];
  orderEmails?: boolean;
  adminAlerts?: boolean;
  aiMonitoring?: boolean;
  returnWindowDays?: number;
  integrations?: {
    orderEmail?: {
      enabled: boolean;
      host?: string;
      port?: number;
      user?: string;
      pass?: string;
      from?: string;
    };
  };
  affiliateSettings?: {
    defaultCommissionRate: number;
    allowNonAssignedCommissions: boolean;
    nonAssignedCommissionRate: number;
    enabledProducts?: string[];
    excludedProducts?: string[];
    minPayoutAmount?: number;
    cookieDuration?: number;
  };
  notificationSettings?: {
    disabledStatuses?: string[];
    email: {
      enabled: boolean;
      smtpHost?: string;
      smtpPort?: number;
      smtpUser?: string;
      smtpPass?: string;
      senderEmail?: string;
      templates: { [status: string]: string };
    };
    whatsapp: {
      enabled: boolean;
      apiKey?: string;
      accountSid?: string;
      fromNumber?: string;
      templates: { [status: string]: string };
    };
    webhook: {
      enabled: boolean;
      url?: string;
      secret?: string;
      templates: { [status: string]: string };
    };
  };
  campaigns?: any[];
  faqs?: { id: string; question: string; answer: string }[];
  supportPhone?: string;
  storeAddress?: string;
  team?: { name: string; role: string; image: string }[];
  adminAccessCode?: string;
  blogPosts?: any[];
}

export interface NotificationLog {
  id: string;
  orderId: string;
  type: 'email' | 'whatsapp' | 'webhook';
  recipient: string;
  status: 'sent' | 'failed';
  message: string;
  timestamp: string;
  error?: string;
}

// 'Customer' removed — customer accounts are storefront-only, not admin panel users
export type UserRole = 'Super Admin' | 'Admin' | 'Affiliate' | 'Customer Support';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  joined: string;
  password?: string;
  affiliateId?: string;
  commissionRate?: number;
  assignedProducts?: string[];
  totalRevenue?: number;
  totalCommission?: number;
  referralClicks?: number;
  paymentInfo?: string;
  isBlocked?: boolean;
  status?: string;
}

export interface AIAlert {
  id: string;
  type: 'security' | 'inventory' | 'sales' | 'system' | 'fraud' | 'stock' | 'order' | 'action_required';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  isRead: boolean;
  details?: any;
  source?: string;
}

export interface Visitor {
  ip: string;
  lastSeen: number;
  sessionStart: number;
  currentPage: string;
  deviceType: string;
  userAgent: string;
  locale?: string;
  timezone?: string;
}

export type Category = string;
